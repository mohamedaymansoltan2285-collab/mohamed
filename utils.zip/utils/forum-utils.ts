// utils/forum-utils.ts
import { Timestamp } from "firebase/firestore"

/**
 * دالة لاستخراج الأحرف الأولى من الاسم الكامل.
 * @param fullName الاسم الكامل للموظف.
 * @returns الأحرف الأولى (مثل: محمد علي -> م ع).
 */
export function getInitials(fullName: string): string {
  if (!fullName) return ""
  const parts = fullName.trim().split(/\s+/)
  if (parts.length === 1) {
    return parts[0][0].toUpperCase()
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

/**
 * دالة لتنسيق التاريخ سواء كان كائن Timestamp أو تاريخ JS.
 * @param date التاريخ (Timestamp أو Date أو null).
 * @returns سلسلة نصية منسقة للتاريخ.
 */
export function formatDate(date: Timestamp | Date | null | undefined): string {
  if (!date) return "N/A"

  const dateObj = date instanceof Timestamp ? date.toDate() : date
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - dateObj.getTime()) / 1000)

  if (diffInSeconds < 60) {
    return "الآن"
  }
  if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60)
    return `${minutes} دقيقة مضت`
  }
  if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600)
    return `${hours} ساعة مضت`
  }
  
  if (dateObj.getFullYear() === now.getFullYear()) {
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }
    return dateObj.toLocaleDateString('ar-EG', options)
  }

  return dateObj.toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

/**
 * دالة لنسخ النص إلى الحافظة.
 * @param text النص المراد نسخه.
 * @returns وعد (Promise) ينفذ بـ true إذا نجح النسخ.
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  if (typeof window === "undefined" || !navigator.clipboard) {
    console.error("Clipboard API not available.")
    return false
  }
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch (err) {
    console.error("Failed to copy text: ", err)
    return false
  }
}

/**
 * دالة لتوليد معرف فريد للتعليقات.
 * @returns معرف تعليق فريد.
 */
export function generateCommentId(): string {
  // توليد معرف فريد يعتمد على الوقت والجزء العشوائي
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 5)
}