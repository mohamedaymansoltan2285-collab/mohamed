"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, onSnapshot } from "firebase/firestore"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import AddCriterionModal from "@/components/add-criterion-modal"
import CriteriaList from "@/components/criteria-list"
import { useAuth } from "@/components/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Award } from "lucide-react"
import type { Criterion } from "@/types/criteria"

export default function CriteriaManagement() {
  const { user, logout } = useAuth()
  const [criteria, setCriteria] = useState<Criterion[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)

  useEffect(() => {
    setLoading(true)

    const unsubscribe = onSnapshot(
      collection(db, "criteria"),
      (snapshot) => {
        const criteriaList: Criterion[] = []
        snapshot.forEach((doc) => {
          criteriaList.push({
            id: doc.id,
            ...doc.data(),
          } as Criterion)
        })
        setCriteria(criteriaList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching criteria:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-8 h-8 text-indigo-600" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent">
                المعايير
              </h1>
            </div>
            <p className="text-muted-foreground mt-2">إدارة معايير تقييم الموظفين</p>
          </div>
          <Button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 w-full md:w-auto bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4" />
            إضافة معيار جديد
          </Button>
        </div>

        <Card className="border-0 shadow-lg mb-8 bg-gradient-to-br from-indigo-50 to-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-2xl">ℹ️</span>
              معلومات مهمة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-foreground/80">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 font-bold mt-1">•</span>
                <span>أضف معايير جديدة واختر الأقسام المطبقة عليها</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 font-bold mt-1">•</span>
                <span>كل معيار سيظهر تلقائياً في صفحة قسمه الخاص</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 font-bold mt-1">•</span>
                <span>قيّم الموظفين يومياً من خلال جداول التقييم في كل قسم</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 font-bold mt-1">•</span>
                <span>جميع التقييمات تُحفظ تلقائياً ويتم تحديثها فوراً</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>المعايير المضافة</CardTitle>
            <CardDescription>
              {criteria.length} معايير
              {criteria.length > 0 &&
                ` - ${criteria.reduce((sum, c) => sum + c.departments.length, 0)} تطبيق على أقسام`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              </div>
            ) : (
              <CriteriaList criteria={criteria} onCriteriaChange={() => {}} />
            )}
          </CardContent>
        </Card>
      </main>

      {showAddModal && <AddCriterionModal onClose={() => setShowAddModal(false)} onCriterionAdded={() => {}} />}
    </div>
  )
}
