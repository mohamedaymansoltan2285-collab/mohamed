"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore"
import { useAuth } from "@/components/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import AddEmployeeModal from "@/components/add-employee-modal"
import { UserPlus, Search, Users, Eye, ChevronLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import type { Employee } from "@/types/employee"

export default function EmployeesPage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [refreshKey, setRefreshKey] = useState(0)
  const [departmentFilter, setDepartmentFilter] = useState("")
  const [statusFilter, setStatusFilter] = useState("")
  const [sortBy, setSortBy] = useState<"name" | "joinDate" | "status">("name")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")

  const DEPARTMENTS = [
    "تكنولوجيا المعلومات - الفرقة الأولى",
    "تكنولوجيا المعلومات - الفرقة الثانية",
    "تكنولوجيا المعلومات - الفرقة الثالثة",
    "تكنولوجيا المعلومات - الفرقة الرابعة",
    "ميكاترونيكس - الفرقة الأولى",
    "ميكاترونيكس - الفرقة الثانية",
    "ميكاترونيكس - الفرقة الثالثة",
    "ميكاترونيكس - الفرقة الرابعة",
    "أوتوترونيكس - الفرقة الأولى",
    "أوتوترونيكس - الفرقة الثانية",
    "أوتوترونيكس - الفرقة الثالثة",
    "أوتوترونيكس - الفرقة الرابعة",
    "الطاقة المتجددة - الفرقة الأولى",
    "الطاقة المتجددة - الفرقة الثانية",
    "الطاقة المتجددة - الفرقة الثالثة",
    "الطاقة المتجددة - الفرقة الرابعة",
    "التحكم في الآلات الصناعية - الفرقة الأولى",
    "التحكم في الآلات الصناعية - الفرقة الثانية",
    "التحكم في الآلات الصناعية - الفرقة الثالثة",
    "التحكم في الآلات الصناعية - الفرقة الرابعة",
    "التبريد والتكييف - الفرقة الأولى",
    "التبريد والتكييف - الفرقة الثانية",
    "التبريد والتكييف - الفرقة الثالثة",
    "التبريد والتكييف - الفرقة الرابعة",
    "السكة الحديد - الفرقة الأولى",
    "السكة الحديد - الفرقة الثانية",
    "السكة الحديد - الفرقة الثالثة",
    "السكة الحديد - الفرقة الرابعة",
  ]

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "employees"))
        const employeeList: Employee[] = []
        querySnapshot.forEach((doc) => {
          employeeList.push({
            id: doc.id,
            ...doc.data(),
          } as Employee)
        })
        setEmployees(employeeList)
      } catch (error) {
        console.error("Error fetching employees:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchEmployees()
  }, [refreshKey])

  useEffect(() => {
    const filtered = employees.filter((emp) => {
      const matchesSearch =
        emp.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.phone?.includes(searchTerm)

      const matchesDepartment = !departmentFilter || emp.department === departmentFilter
      const matchesStatus = !statusFilter || emp.status === statusFilter

      return matchesSearch && matchesDepartment && matchesStatus
    })

    filtered.sort((a, b) => {
      let compareValue = 0

      if (sortBy === "name") {
        compareValue = a.fullName.localeCompare(b.fullName, "ar")
      } else if (sortBy === "joinDate") {
        compareValue = new Date(a.joinDate).getTime() - new Date(b.joinDate).getTime()
      } else if (sortBy === "status") {
        compareValue = a.status.localeCompare(b.status)
      }

      return sortOrder === "asc" ? compareValue : -compareValue
    })

    setFilteredEmployees(filtered)
  }, [searchTerm, employees, departmentFilter, statusFilter, sortBy, sortOrder])

  const handleDeleteEmployee = async (id: string) => {
    if (confirm("هل تريد حقاً حذف هذا الطالب؟")) {
      try {
        await deleteDoc(doc(db, "employees", id))
        setRefreshKey((prev) => prev + 1)
      } catch (error) {
        console.error("Error deleting employee:", error)
      }
    }
  }

  const handleViewProfile = (employee: Employee) => {
    router.push(`/employee/profile?code=${employee.employeeCode}&admin=true`)
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Link
                href="/admin/dashboard"
                className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition-all transform hover:scale-110"
              >
                <ChevronLeft className="w-5 h-5" />
              </Link>
              <Users className="w-8 h-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-foreground">إدارة الطلاب</h1>
            </div>
            <p className="text-muted-foreground">
              إجمالي الطلاب: {filteredEmployees.length} من {employees.length}
            </p>
          </div>
          <Button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all"
          >
            <UserPlus className="w-4 h-4" />
            إضافة طالب جديد
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {/* Search Bar */}
          <div className="md:col-span-2">
            <Card className="border-0 shadow-md">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
                  <Search className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  <Input
                    placeholder="ابحث بالاسم أو البريد أو الهاتف..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border-0 bg-transparent focus-visible:ring-0 placeholder:text-muted-foreground"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Department Filter */}
          <div>
            <Card className="border-0 shadow-md">
              <CardContent className="pt-4">
                <select
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">جميع الأقسام</option>
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </CardContent>
            </Card>
          </div>

          {/* Status Filter */}
          <div>
            <Card className="border-0 shadow-md">
              <CardContent className="pt-4">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">جميع الحالات</option>
                  <option value="active">نشيط</option>
                  <option value="inactive">غير نشيط</option>
                </select>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Employees Table */}
        <Card className="border-0 shadow-lg overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>قائمة الطلاب</CardTitle>
                <CardDescription>جميع بيانات الطلاب الموجودة في النظام</CardDescription>
              </div>
              <div className="text-3xl font-bold text-blue-600">{filteredEmployees.length}</div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-4 border-muted-background border-t-blue-600 rounded-full animate-spin"></div>
              </div>
            ) : filteredEmployees.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground text-lg">لا توجد بيانات طلاب</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/50">
                      <th className="text-right py-4 px-6 font-semibold text-foreground">الصورة</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">الاسم</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">البريد الإلكتروني</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">القسم</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">الهاتف</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">تاريخ الالتحاق</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">الحالة</th>
                      <th className="text-right py-4 px-6 font-semibold text-foreground">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEmployees.map((employee, index) => {
                      const initials = employee.fullName
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase()
                        .slice(0, 2)

                      return (
                        <tr
                          key={employee.id}
                          className="border-b border-border hover:bg-muted/30 transition-colors duration-150 animate-fade-in"
                          style={{ animationDelay: `${index * 50}ms` }}
                        >
                          <td className="py-4 px-6">
                            <Avatar className="w-10 h-10 border-2 border-blue-200 shadow-sm">
                              <AvatarImage src={employee.profileImage || "/placeholder.svg"} alt={employee.fullName} />
                              <AvatarFallback className="bg-gradient-to-br from-blue-400 to-indigo-500 text-white text-xs font-bold">
                                {initials}
                              </AvatarFallback>
                            </Avatar>
                          </td>
                          <td className="py-4 px-6">
                            <span className="font-semibold text-foreground">{employee.fullName}</span>
                          </td>
                          <td className="py-4 px-6 text-muted-foreground">{employee.email}</td>
                          <td className="py-4 px-6">
                            <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold">
                              {employee.department}
                            </span>
                          </td>
                          <td className="py-4 px-6 text-muted-foreground font-mono">{employee.phone}</td>
                          <td className="py-4 px-6 text-muted-foreground">
                            {new Date(employee.joinDate).toLocaleDateString("ar-SA")}
                          </td>
                          <td className="py-4 px-6">
                            <span
                              className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${
                                employee.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                              }`}
                            >
                              <span className="w-2 h-2 rounded-full bg-current mr-2"></span>
                              {employee.status === "active" ? "نشيط" : "غير نشيط"}
                            </span>
                          </td>
                          <td className="py-4 px-6">
                            <Button
                              onClick={() => handleViewProfile(employee)}
                              variant="ghost"
                              size="sm"
                              className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 transition-all duration-200"
                              title="عرض البروفايل"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {showAddModal && (
        <AddEmployeeModal
          onClose={() => setShowAddModal(false)}
          onEmployeeAdded={() => {
            setShowAddModal(false)
            setRefreshKey((prev) => prev + 1)
          }}
        />
      )}
    </div>
  )
}
