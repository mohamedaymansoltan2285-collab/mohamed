"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, getDocs, onSnapshot } from "firebase/firestore"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChartContainer } from "@/components/ui/chart"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import { useAuth } from "@/components/auth-context"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { Download, TrendingUp, Award, Users, BookOpen, FileText, Trophy } from 'lucide-react'
import type { Employee } from "@/types/employee"
import type { EmployeeRating, Criterion } from "@/types/criteria"

interface DepartmentStats {
  name: string
  count: number
  avgRating: number
}

interface EmployeePerformance {
  id: string
  fullName: string
  department: string
  avgRating: number
  totalRatings: number
}

interface JoinDateStats {
  month: string
  count: number
}

export default function AnalyticsPage() {
  const { user, logout } = useAuth()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [ratings, setRatings] = useState<EmployeeRating[]>([])
  const [criteria, setCriteria] = useState<Criterion[]>([])
  const [loading, setLoading] = useState(true)
  const [departmentData, setDepartmentData] = useState<DepartmentStats[]>([])
  const [employeePerformance, setEmployeePerformance] = useState<EmployeePerformance[]>([])
  const [joinDateData, setJoinDateData] = useState<JoinDateStats[]>([])
  const [statusData, setStatusData] = useState<any[]>([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const employeesSnapshot = await getDocs(collection(db, "employees"))
        const employeeList: Employee[] = []
        employeesSnapshot.forEach((doc) => {
          employeeList.push({ id: doc.id, ...doc.data() } as Employee)
        })
        setEmployees(employeeList)

        const criteriaSnapshot = await getDocs(collection(db, "criteria"))
        const criteriaList: Criterion[] = []
        criteriaSnapshot.forEach((doc) => {
          criteriaList.push({ id: doc.id, ...doc.data() } as Criterion)
        })
        setCriteria(criteriaList)

        const unsubscribe = onSnapshot(collection(db, "employeeRatings"), (snapshot) => {
          const ratingsList: EmployeeRating[] = []
          snapshot.forEach((doc) => {
            ratingsList.push({ id: doc.id, ...doc.data() } as EmployeeRating)
          })
          setRatings(ratingsList)
          processAnalytics(employeeList, ratingsList, criteriaList)
        })

        return () => unsubscribe()
      } catch (error) {
        console.error("[v0] Error fetching analytics data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const processAnalytics = (empList: Employee[], ratingsList: EmployeeRating[], criteriaList: Criterion[]) => {
    // معالجة إحصائيات الأقسام
    const deptMap = new Map<string, { employees: string[]; totalRating: number }>()
    empList.forEach((emp) => {
      const dept = emp.department || "بدون قسم"
      if (!deptMap.has(dept)) {
        deptMap.set(dept, { employees: [], totalRating: 0 })
      }
      deptMap.get(dept)!.employees.push(emp.id)
    })

    // حساب متوسط التقييمات لكل قسم
    const deptStatsArray: DepartmentStats[] = Array.from(deptMap.entries()).map(([dept, data]) => {
      const deptRatings = ratingsList.filter((r) => r.departmentId === dept)
      const avgRating =
        deptRatings.length > 0 ? deptRatings.reduce((sum, r) => sum + (r.rating || 0), 0) / deptRatings.length : 0
      return { name: dept, count: data.employees.length, avgRating }
    })
    setDepartmentData(deptStatsArray)

    // معالجة أداء الطلاب - Now considers timeSlot
    const empPerformance: EmployeePerformance[] = empList.map((emp) => {
      // Get all ratings for this employee regardless of timeSlot
      const empRatings = ratingsList.filter((r) => r.employeeId === emp.id)
      const avgRating =
        empRatings.length > 0 ? empRatings.reduce((sum, r) => sum + (r.rating || 0), 0) / empRatings.length : 0
      return {
        id: emp.id,
        fullName: emp.fullName,
        department: emp.department,
        avgRating,
        totalRatings: empRatings.length,
      }
    })
    setEmployeePerformance(empPerformance)

    // معالجة حالات الطلاب
    const statusMap = new Map<string, number>()
    empList.forEach((emp) => {
      const status = emp.status === "active" ? "نشيط" : "غير نشيط"
      statusMap.set(status, (statusMap.get(status) || 0) + 1)
    })
    setStatusData(Array.from(statusMap.entries()).map(([name, value]) => ({ name, value })))

    // معالجة تاريخ الالتحاق
    const monthMap = new Map<string, number>()
    empList.forEach((emp) => {
      const date = new Date(emp.joinDate)
      const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`
      monthMap.set(monthYear, (monthMap.get(monthYear) || 0) + 1)
    })
    setJoinDateData(
      Array.from(monthMap.entries())
        .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
        .map(([month, count]) => ({ month, count })),
    )
  }

  const exportToCSV = () => {
    const headers = ["الاسم", "القسم", "متوسط التقييم", "عدد التقييمات", "الحالة"]
    const rows = employeePerformance.map((emp) => {
      const employee = employees.find((e) => e.id === emp.id)
      return [emp.fullName, emp.department, emp.avgRating.toFixed(2), emp.totalRatings, employee?.status || ""]
    })

    const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n")
    downloadFile(csvContent, "تقرير_الطلاب.csv", "text/csv")
  }

  const exportToExcel = () => {
    const headers = ["الاسم", "القسم", "متوسط التقييم", "عدد التقييمات", "الحالة"]
    const rows = employeePerformance.map((emp) => {
      const employee = employees.find((e) => e.id === emp.id)
      return [emp.fullName, emp.department, emp.avgRating.toFixed(2), emp.totalRatings, employee?.status || ""]
    })

    let xmlContent = `<?xml version="1.0" encoding="UTF-8"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="البيانات"><Table>`

    // إضافة الرؤوس
    xmlContent += "<Row>"
    headers.forEach((header) => {
      xmlContent += `<Cell><Data ss:Type="String">${header}</Data></Cell>`
    })
    xmlContent += "</Row>"

    // إضافة الصفوف
    rows.forEach((row) => {
      xmlContent += "<Row>"
      row.forEach((cell) => {
        xmlContent += `<Cell><Data ss:Type="String">${cell}</Data></Cell>`
      })
      xmlContent += "</Row>"
    })

    xmlContent += "</Table></Worksheet></Workbook>"
    downloadFile(xmlContent, "تقرير_الطلاب.xls", "application/vnd.ms-excel")
  }

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const element = document.createElement("a")
    element.setAttribute("href", `data:${mimeType};charset=utf-8,${encodeURIComponent(content)}`)
    element.setAttribute("download", filename)
    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const topEmployee =
    employeePerformance.length > 0
      ? employeePerformance.reduce((prev, current) => (prev.avgRating > current.avgRating ? prev : current))
      : { fullName: "—", avgRating: 0 }

  const bottomEmployee =
    employeePerformance.length > 0
      ? employeePerformance.reduce((prev, current) => (prev.avgRating < current.avgRating ? prev : current))
      : { fullName: "—", avgRating: 0 }

  const topDepartment =
    departmentData.length > 0
      ? departmentData.reduce((prev, current) => (prev.avgRating > current.avgRating ? prev : current))
      : { name: "—", avgRating: 0 }

  const bottomDepartment =
    departmentData.length > 0
      ? departmentData.reduce((prev, current) => (prev.avgRating < current.avgRating ? prev : current))
      : { name: "—", avgRating: 0 }

  const colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#14b8a6"]

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل التحليلات...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        {/* الرأس */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent">
                التحليلات والإحصائيات
              </h1>
              <p className="text-muted-foreground mt-2">معلومات شاملة عن أداء الطلاب والأقسام</p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button
                onClick={exportToCSV}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <FileText className="w-4 h-4" />
                تحميل CSV
              </Button>
              <Button
                onClick={exportToExcel}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
              >
                <Download className="w-4 h-4" />
                تحميل Excel
              </Button>
            </div>
          </div>
        </div>

        {/* بطاقات الملخص */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                إجمالي الطلاب
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{employees.length}</div>
              <p className="text-xs text-muted-foreground mt-2">طالب مسجل</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-600" />
                الطلاب النشيطون
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {employees.filter((e) => e.status === "active").length}
              </div>
              <p className="text-xs text-muted-foreground mt-2">في الجامعة حالياً</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-600" />
                عدد الأقسام
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{departmentData.length}</div>
              <p className="text-xs text-muted-foreground mt-2">قسم مختلف</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-orange-100 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-orange-600" />
                إجمالي التقييمات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{ratings.length}</div>
              <p className="text-xs text-muted-foreground mt-2">تقييم مسجل</p>
            </CardContent>
          </Card>
        </div>

        {/* أفضل وأقل طالب وقسم */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-50 to-teal-50 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Trophy className="w-4 h-4 text-emerald-600" />
                أفضل طالب
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-semibold text-foreground line-clamp-1">{topEmployee.fullName}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="text-2xl font-bold text-emerald-600">{topEmployee.avgRating.toFixed(1)}</div>
                <span className="text-xs text-muted-foreground">من 5</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-red-50 to-pink-50 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Trophy className="w-4 h-4 text-red-600" />
                أقل طالب
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-semibold text-foreground line-clamp-1">{bottomEmployee.fullName}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="text-2xl font-bold text-red-600">{bottomEmployee.avgRating.toFixed(1)}</div>
                <span className="text-xs text-muted-foreground">من 5</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-cyan-50 to-blue-50 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Trophy className="w-4 h-4 text-cyan-600" />
                أفضل قسم
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-semibold text-foreground line-clamp-1">{topDepartment.name}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="text-2xl font-bold text-cyan-600">{topDepartment.avgRating.toFixed(1)}</div>
                <span className="text-xs text-muted-foreground">متوسط</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-violet-50 to-purple-50 hover:shadow-xl transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Trophy className="w-4 h-4 text-violet-600" />
                أدنى قسم
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-semibold text-foreground line-clamp-1">{bottomDepartment.name}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="text-2xl font-bold text-violet-600">{bottomDepartment.avgRating.toFixed(1)}</div>
                <span className="text-xs text-muted-foreground">متوسط</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* الرسوم البيانية */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* توزيع الطلاب حسب القسم مع التقييمات */}
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-600" />
                أداء الأقسام
              </CardTitle>
              <CardDescription>عدد الطلاب ومتوسط التقييم لكل قسم</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "عدد الطلاب", color: "#3b82f6" },
                  avgRating: { label: "متوسط التقييم", color: "#10b981" },
                }}
                className="h-[350px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={departmentData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="count" fill="#3b82f6" name="عدد الطلاب" />
                    <Bar yAxisId="right" dataKey="avgRating" fill="#10b981" name="متوسط التقييم" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* توزيع حالات الطلاب */}
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                توزيع حالات الطلاب
              </CardTitle>
              <CardDescription>نسبة الطلاب النشيطين وغير النشيطين</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  value: { label: "العدد", color: "#3b82f6" },
                }}
                className="h-[350px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* اتجاه الالتحاق الشهري */}
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                اتجاه الالتحاق الشهري
              </CardTitle>
              <CardDescription>عدد الطلاب الجدد حسب الشهر</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "عدد الطلاب", color: "#3b82f6" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={joinDateData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={{ fill: "#3b82f6" }}
                      name="عدد الطلاب الجدد"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* جدول أداء الطلاب */}
        <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-indigo-600" />
              أداء جميع الطلاب
            </CardTitle>
            <CardDescription>ترتيب الطلاب حسب متوسط التقييم</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-indigo-500 to-blue-500 text-white">
                    <th className="px-6 py-3 text-right font-semibold">الاسم</th>
                    <th className="px-6 py-3 text-right font-semibold">القسم</th>
                    <th className="px-6 py-3 text-center font-semibold">متوسط التقييم</th>
                    <th className="px-6 py-3 text-center font-semibold">عدد التقييمات</th>
                    <th className="px-6 py-3 text-center font-semibold">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {employeePerformance
                    .sort((a, b) => b.avgRating - a.avgRating)
                    .map((emp, idx) => {
                      const employee = employees.find((e) => e.id === emp.id)
                      return (
                        <tr
                          key={emp.id}
                          className={`border-b border-border transition-colors hover:bg-indigo-50 ${
                            idx % 2 === 0 ? "bg-white" : "bg-slate-50"
                          }`}
                        >
                          <td className="px-6 py-4 font-medium text-foreground">{emp.fullName}</td>
                          <td className="px-6 py-4 text-foreground">{emp.department}</td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <span className="font-bold text-lg text-indigo-600">{emp.avgRating.toFixed(1)}</span>
                              <span className="text-xs text-muted-foreground">من 5</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center font-semibold text-blue-600">{emp.totalRatings}</td>
                          <td className="px-6 py-4 text-center">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                employee?.status === "active"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-red-100 text-red-700"
                              }`}
                            >
                              {employee?.status === "active" ? "نشيط" : "غير نشيط"}
                            </span>
                          </td>
                        </tr>
                      )
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
