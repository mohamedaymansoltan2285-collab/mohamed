"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, onSnapshot, deleteDoc, doc, updateDoc } from "firebase/firestore"
import { useAuth } from "@/components/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import { FileText, Trash2, CheckCircle, Clock, AlertCircle } from "lucide-react"
import type { StudentRequest } from "@/types/request"

export default function RequestsPage() {
  const { user, logout } = useAuth()
  const [requests, setRequests] = useState<StudentRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "reviewed" | "resolved">("all")

  useEffect(() => {
    setLoading(true)

    const unsubscribe = onSnapshot(
      collection(db, "student_requests"),
      (snapshot) => {
        const requestList: StudentRequest[] = []
        snapshot.forEach((doc) => {
          const data = doc.data()
          requestList.push({
            id: doc.id,
            studentId: data.studentId,
            studentName: data.studentName,
            studentCode: data.studentCode,
            studentDepartment: data.studentDepartment,
            studentImage: data.studentImage,
            description: data.description,
            imageUrl: data.imageUrl,
            status: data.status || "pending",
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          } as StudentRequest)
        })
        // Sort by newest first
        requestList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        setRequests(requestList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching requests:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  const handleDeleteRequest = async (id: string) => {
    if (confirm("هل تريد حقاً حذف هذا الطلب؟")) {
      try {
        await deleteDoc(doc(db, "student_requests", id))
      } catch (error) {
        console.error("[v0] Error deleting request:", error)
      }
    }
  }

  const handleUpdateStatus = async (id: string, newStatus: "pending" | "reviewed" | "resolved") => {
    try {
      await updateDoc(doc(db, "student_requests", id), {
        status: newStatus,
        updatedAt: new Date().toISOString(),
      })
    } catch (error) {
      console.error("[v0] Error updating request:", error)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { label: "قيد الانتظار", color: "bg-yellow-100 text-yellow-800", icon: Clock },
      reviewed: { label: "تم المراجعة", color: "bg-blue-100 text-blue-800", icon: AlertCircle },
      resolved: { label: "تم الحل", color: "bg-green-100 text-green-800", icon: CheckCircle },
    }
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending
    const Icon = config.icon
    return (
      <Badge className={config.color}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    )
  }

  const filteredRequests = filterStatus === "all" ? requests : requests.filter((r) => r.status === filterStatus)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
            الطلبات المرسلة
          </h1>
          <p className="text-muted-foreground mt-2">إدارة طلبات وشكاوى الطلاب</p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap gap-2 mb-6">
          {["all", "pending", "reviewed", "resolved"].map((status) => (
            <Button
              key={status}
              variant={filterStatus === status ? "default" : "outline"}
              onClick={() => setFilterStatus(status as any)}
              className={
                filterStatus === status
                  ? "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  : ""
              }
            >
              {status === "all" && "الكل"}
              {status === "pending" && "قيد الانتظار"}
              {status === "reviewed" && "تم المراجعة"}
              {status === "resolved" && "تم الحل"}
            </Button>
          ))}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">قيد الانتظار</CardTitle>
              <Clock className="w-5 h-5 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-600">
                {requests.filter((r) => r.status === "pending").length}
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">تم المراجعة</CardTitle>
              <AlertCircle className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                {requests.filter((r) => r.status === "reviewed").length}
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">تم الحل</CardTitle>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {requests.filter((r) => r.status === "resolved").length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Requests List */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-6 h-6" />
              قائمة الطلبات
            </CardTitle>
            <CardDescription>تحديث فوري - البيانات تتحدث تلقائياً</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
              </div>
            ) : filteredRequests.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
                <p className="text-muted-foreground">لم يتم استلام أي طلبات حتى الآن</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredRequests.map((request) => (
                  <Card key={request.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-4">
                        {/* Student Info */}
                        <div className="lg:col-span-3">
                          <div className="flex gap-4 mb-4">
                            {request.studentImage && (
                              <img
                                src={request.studentImage || "/placeholder.svg"}
                                alt={request.studentName}
                                className="w-16 h-16 rounded-full object-cover"
                              />
                            )}
                            <div className="flex-1">
                              <h3 className="text-lg font-semibold">{request.studentName}</h3>
                              <p className="text-sm text-gray-600">
                                الرقم الكودي: <span className="font-mono font-semibold">{request.studentCode}</span>
                              </p>
                              <p className="text-sm text-gray-600">{request.studentDepartment}</p>
                            </div>
                          </div>

                          {/* Description */}
                          <div className="bg-gray-50 p-4 rounded-lg mb-4">
                            <h4 className="font-semibold mb-2">وصف الطلب:</h4>
                            <p className="text-gray-700">{request.description}</p>
                          </div>

                          {/* Attached Image */}
                          {request.imageUrl && (
                            <div className="mb-4">
                              <h4 className="font-semibold mb-2">الصورة المرفقة:</h4>
                              <img
                                src={request.imageUrl || "/placeholder.svg"}
                                alt="الصورة المرفقة"
                                className="max-w-xs h-auto rounded-lg border border-gray-200"
                              />
                            </div>
                          )}

                          {/* Timestamp */}
                          <p className="text-xs text-gray-500">
                            تاريخ الإرسال: {new Date(request.createdAt).toLocaleDateString("ar-SA")} الساعة{" "}
                            {new Date(request.createdAt).toLocaleTimeString("ar-SA")}
                          </p>
                        </div>

                        {/* Status and Actions */}
                        <div className="lg:col-span-1 flex flex-col gap-3">
                          <div>
                            <p className="text-xs text-gray-600 mb-2">الحالة</p>
                            {getStatusBadge(request.status)}
                          </div>

                          {/* Status Change Buttons */}
                          <div className="space-y-2">
                            {request.status !== "pending" && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleUpdateStatus(request.id, "pending")}
                                className="w-full text-xs"
                              >
                                قيد الانتظار
                              </Button>
                            )}
                            {request.status !== "reviewed" && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleUpdateStatus(request.id, "reviewed")}
                                className="w-full text-xs"
                              >
                                تم المراجعة
                              </Button>
                            )}
                            {request.status !== "resolved" && (
                              <Button
                                size="sm"
                                className="w-full text-xs bg-green-600 hover:bg-green-700"
                                onClick={() => handleUpdateStatus(request.id, "resolved")}
                              >
                                تم الحل
                              </Button>
                            )}
                          </div>

                          {/* Delete Button */}
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeleteRequest(request.id)}
                            className="w-full text-xs"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            حذف
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
