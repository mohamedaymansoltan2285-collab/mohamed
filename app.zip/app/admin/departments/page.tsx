"use client"

import { useEffect, useState } from "react"
import { collection, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent } from "@/components/ui/card"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import { useAuth } from "@/components/auth-context"
import { DEPARTMENTS } from "@/types/employee"
import type { Employee } from "@/types/employee"
import Link from "next/link"
import { ChevronLeft, Users } from "lucide-react"

export default function DepartmentsPage() {
  const { user, logout } = useAuth()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, "employees"),
      (snapshot) => {
        const empList: Employee[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Employee
          empList.push({
             ...data,
            id: doc.id,
           
          } as Employee)
        })
        setEmployees(empList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching employees:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  const getDepartmentEmployees = (deptValue: string) => {
    return employees.filter((e) => e.department === deptValue)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center gap-3">
          <Link
            href="/admin/dashboard"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white shadow-md hover:shadow-lg hover:bg-blue-50 text-blue-600 font-semibold transition-all transform hover:scale-105"
          >
            <ChevronLeft className="w-5 h-5" />
            <span className="hidden sm:inline">العودة</span>
          </Link>
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              الأقسام
            </h1>
            <p className="text-muted-foreground mt-1 text-sm">عرض وإدارة طلاب كل قسم</p>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {DEPARTMENTS.map((dept) => {
              const deptEmployees = getDepartmentEmployees(dept.value)
              const count = deptEmployees.length
              return (
                <Link key={dept.value} href={`/admin/departments/${dept.value}`}>
                  <Card className="border-0 shadow-lg hover:shadow-xl transition-all transform hover:scale-105 cursor-pointer h-full bg-gradient-to-br from-background to-muted-background overflow-hidden group">
                    <div
                      className={`h-24 bg-gradient-to-r ${dept.color} opacity-0 group-hover:opacity-10 transition-opacity`}
                    ></div>
                    <CardContent className="p-6 relative -mt-12 bg-background rounded-t-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-foreground mb-2">
                            <span className="text-3xl">{dept.icon}</span> {dept.label}
                          </h3>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Users className="w-4 h-4" />
                            <span className="text-sm">{count} طالب</span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">اضغط للعرض</span>
                        <ChevronLeft className="w-4 h-4 text-blue-600 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
