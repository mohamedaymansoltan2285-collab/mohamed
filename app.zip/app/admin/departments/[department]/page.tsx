"use client"

import { useEffect, useState, useCallback } from "react"
import { collection, onSnapshot, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent } from "@/components/ui/card"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import { useAuth } from "@/components/auth-context"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { DEPARTMENTS } from "@/types/employee"
import { ArrowRight, BarChart3, Settings, Users } from "lucide-react"
import type { Employee } from "@/types/employee"
import type { Criterion } from "@/types/criteria"
import type { Lecture } from "@/types/lecture"
import DepartmentEvaluationTable from "@/components/department-evaluation-table"
import DepartmentEmployeeCard from "@/components/department-employee-card"
import RatingsSummaryTable from "@/components/ratings-summary-table"
import AddLectureModal from "@/components/add-lecture-modal"
import LectureAttendeesModal from "@/components/lecture-attendees-modal"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DepartmentDetailPage() {
  const { user, logout } = useAuth()
  const params = useParams()
  const router = useRouter()
  const department = params.department as string
  const [employees, setEmployees] = useState<Employee[]>([])
  const [criteria, setCriteria] = useState<Criterion[]>([])
  const [lectures, setLectures] = useState<Lecture[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("evaluation")
  const [selectedLecture, setSelectedLecture] = useState<Lecture | null>(null)

  const decodedDept = decodeURIComponent(department)
  const deptInfo = DEPARTMENTS.find((d) => d.value === decodedDept)

  const departmentColorMap: Record<string, string> = {
    "تكنولوجيا المعلومات ICT": "from-blue-500 to-cyan-500",
    ميكاترونيكس: "from-purple-500 to-pink-500",
    أوتوترونيكس: "from-orange-500 to-red-500",
  }

  const departmentGradient = departmentColorMap[decodedDept] || "from-blue-500 to-cyan-500"

  useEffect(() => {
    const q = query(collection(db, "employees"), where("department", "==", decodedDept))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const empList: Employee[] = []
        snapshot.forEach((doc) => {
          const data = doc.data()
          empList.push({
            id: doc.id,
            fullName: data.fullName || "",
            email: data.email || "",
            department: data.department || "",
            phone: data.phone || "",
            joinDate: data.joinDate || "",
            role: data.role || "employee",
            status: data.status || "active",
            uniqueCode: data.uniqueCode || "",
            employeeCode: data.employeeCode || "",
            profileImage: data.profileImage || "",
            ...data,
          } as Employee)
        })
        setEmployees(empList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching department employees:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [decodedDept])

  useEffect(() => {
    const q = query(collection(db, "criteria"))

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const criteriaList: Criterion[] = []
      snapshot.forEach((doc) => {
        const data = doc.data() as Criterion
        if (data.departments.includes(decodedDept)) {
          criteriaList.push({
            ...data, // <--- هنا غيرت ترتيب الخصائص
            id: doc.id,
          })
        }
      })
      setCriteria(criteriaList)
    })

    return () => unsubscribe()
  }, [decodedDept])

  useEffect(() => {
    const q = query(collection(db, "lectures"), where("departmentId", "==", decodedDept))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const lecturesList: Lecture[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Lecture
          lecturesList.push({
            ...data,
            id: doc.id,
            
          })
        })
        setLectures(lecturesList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()))
      },
      (error) => {
        console.error("[v0] Error fetching lectures:", error)
      },
    )

    return () => unsubscribe()
  }, [decodedDept])

  const handleLectureAdded = useCallback((lecture: Lecture) => {
    console.log("[v0] Lecture added:", lecture)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => router.back()}
          className="mb-6 text-blue-600 hover:text-blue-700"
        >
          <ArrowRight className="w-4 h-4 ml-2" />
          رجوع
        </Button>

        {/* Department Header Banner */}
        <div className={`mb-8 p-8 rounded-lg bg-gradient-to-r ${departmentGradient} text-white shadow-lg`}>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="text-5xl">{deptInfo?.icon}</span>
              <div>
                <h1 className="text-4xl font-bold">قسم {decodedDept}</h1>
                <p className="mt-2 opacity-90">عدد الطلاب: {employees.length}</p>
                {criteria.length > 0 && <p className="mt-1 opacity-90">المعايير المطبقة: {criteria.length}</p>}
              </div>
            </div>
            <AddLectureModal
              departmentId={decodedDept}
              createdBy={user?.email || ""}
              onLectureAdded={handleLectureAdded}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="lectures" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">المحاضرات ({lectures.length})</span>
              </TabsTrigger>
              <TabsTrigger value="evaluation" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">التقييمات</span>
              </TabsTrigger>
              <TabsTrigger value="students" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">الطلاب</span>
              </TabsTrigger>
              <TabsTrigger value="reports" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">التقارير</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="lectures" className="space-y-6">
              {lectures.length === 0 ? (
                <Card className="p-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-0">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-blue-300 mx-auto mb-4" />
                    <p className="text-muted-foreground font-medium text-lg">لا توجد محاضرات لهذا القسم حتى الآن</p>
                    <p className="text-sm text-muted-foreground mt-2">أضف محاضرة باستخدام الزر أعلاه</p>
                  </div>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {lectures.map((lecture) => (
                    <Card key={lecture.id} className="border-0 shadow-lg hover:shadow-xl transition-all">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <h3 className="text-lg font-bold text-foreground">{lecture.title}</h3>
                          <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">
                            {lecture.course}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">{lecture.description}</p>
                        <div className="space-y-2 text-sm mb-4">
                          <p>
                            <strong>التاريخ:</strong> {new Date(lecture.lectureDate).toLocaleDateString("ar-SA")}
                          </p>
                          <p>
                            <strong>كود التحضير:</strong>{" "}
                            <code className="bg-gray-100 px-2 py-1 rounded text-blue-600 font-mono">
                              {lecture.attendanceCode}
                            </code>
                          </p>
                        </div>
                        <Button
                          onClick={() => setSelectedLecture(lecture)}
                          className="w-full bg-blue-50 text-blue-600 hover:bg-blue-100 border-blue-200"
                          variant="outline"
                        >
                          <Users className="w-4 h-4 mr-2" />
                          عرض الحضور
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="evaluation" className="space-y-6">
              {criteria.length === 0 ? (
                <Card className="p-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-0">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-blue-300 mx-auto mb-4" />
                    <p className="text-muted-foreground font-medium text-lg">لا توجد معايير لهذا القسم حتى الآن</p>
                    <p className="text-sm text-muted-foreground mt-2">أضف معايير من صفحة المعايير</p>
                  </div>
                </Card>
              ) : (
                <DepartmentEvaluationTable departmentId={decodedDept} employees={employees} criteria={criteria} />
              )}
            </TabsContent>

            <TabsContent value="students" className="space-y-6">
              {employees.length === 0 ? (
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-12 text-center">
                    <p className="text-muted-foreground text-lg">لا توجد طلاب في هذا القسم حتى الآن</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {employees.map((emp) => (
                    <DepartmentEmployeeCard key={emp.id} employee={emp} departmentColor={departmentGradient} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="reports" className="space-y-6">
              {criteria.length === 0 ? (
                <Card className="p-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-0">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-blue-300 mx-auto mb-4" />
                    <p className="text-muted-foreground font-medium text-lg">لا توجد تقييمات حتى الآن</p>
                    <p className="text-sm text-muted-foreground mt-2">ابدأ بتقييم الطلاب من تبويب التقييمات</p>
                  </div>
                </Card>
              ) : (
                <RatingsSummaryTable departmentId={decodedDept} employees={employees} criteria={criteria} />
              )}
            </TabsContent>
          </Tabs>
        )}

        {selectedLecture && (
          <LectureAttendeesModal lecture={selectedLecture} onClose={() => setSelectedLecture(null)} />
        )}
      </main>
    </div>
  )
}
