"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, onSnapshot, deleteDoc, doc, updateDoc } from "firebase/firestore"
import { useAuth } from "@/components/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import AdminHeader from "@/components/admin-header"
import EmployeeList from "@/components/employee-list"
import AddEmployeeModal from "@/components/add-employee-modal"
import AddGalleryImageModal from "@/components/add-gallery-image-modal"
import AdminNavigation from "@/components/admin-navigation"
import DepartmentNavigationGrid from "@/components/department-navigation-grid"
import AddPostModal from "@/components/add-post-modal"
import { motion } from "framer-motion"
import { FileText } from "lucide-react"
import type { Employee } from "@/types/employee"
import Link from "next/link"
import { DEPARTMENTS } from "@/types/employee"
import {
  ImageIcon,
  UsersIcon,
  AwardIcon,
  ActivityIcon,
  UserPlusIcon,
  ClipboardListIcon,
  StarIcon,
  BarChartIcon,
} from "lucide-react"

const AdminDashboard = () => {
  const { user, logout } = useAuth()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showGalleryModal, setShowGalleryModal] = useState(false)
  const [showPostModals, setShowPostModals] = useState({
    "youth-care": false,
    "student-union": false,
    "women-support": false,
    uccd: false,
    "student-affairs": false,
    "mohamad-aimen": false,
  })

  useEffect(() => {
    setLoading(true)

    const unsubscribe = onSnapshot(
      collection(db, "employees"),
      (snapshot) => {
        const employeeList: Employee[] = []
        snapshot.forEach((doc) => {
          const data = doc.data()
          employeeList.push({
            id: doc.id,
            fullName: data.fullName || "",
            email: data.email || "",
            department: data.department || "تكنولوجيا المعلومات - الفرقة الأولى",
            phone: data.phone || "",
            joinDate: data.joinDate || "",
            role: data.role || "employee",
            status: data.status || "active",
            uniqueCode: data.uniqueCode || "",
            employeeCode: data.employeeCode || "",
            ...data,
          } as Employee)
        })
        setEmployees(employeeList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching employees:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  const handleDeleteEmployee = async (id: string) => {
    if (confirm("هل تريد حقاً حذف هذا الطالب؟")) {
      try {
        await deleteDoc(doc(db, "employees", id))
      } catch (error) {
        console.error("Error deleting employee:", error)
      }
    }
  }

  const handleUpdateEmployee = async (id: string, updatedData: Partial<Employee>) => {
    try {
      await updateDoc(doc(db, "employees", id), updatedData)
    } catch (error) {
      console.error("Error updating employee:", error)
    }
  }

  const activeEmployees = employees.filter((e) => e.status === "active").length
  const departments = new Set(employees.map((e) => e.department)).size

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={user} onLogout={logout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              لوحة التحكم
            </h1>
            <p className="text-muted-foreground mt-2">إدارة الطلاب والبيانات بسهولة</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowGalleryModal(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg"
            >
              <ImageIcon className="w-4 h-4" />
              إضافة صورة للمعرض
            </Button>
            <Button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 w-full md:w-auto bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg"
            >
              <UserPlusIcon className="w-4 h-4" />
              إضافة طالب جديد
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow bg-gradient-to-br from-blue-50 to-blue-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي الطلاب</CardTitle>
              <UsersIcon className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{employees.length}</div>
              <p className="text-xs text-muted-foreground mt-2">طلاب مسجلون</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow bg-gradient-to-br from-green-50 to-green-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الطلاب النشيطون</CardTitle>
              <ActivityIcon className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{activeEmployees}</div>
              <p className="text-xs text-muted-foreground mt-2">في الجامعة حالياً</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow bg-gradient-to-br from-purple-50 to-purple-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">عدد الأقسام</CardTitle>
              <UsersIcon className="w-5 h-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{departments}</div>
              <p className="text-xs text-muted-foreground mt-2">أقسام مختلفة</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-indigo-50 to-indigo-100 hover:shadow-xl transition-all cursor-pointer group mb-8">
          <Link href="/admin/criteria">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2 text-indigo-900">
                  <AwardIcon className="w-5 h-5" />
                  المعايير
                </CardTitle>
                <ClipboardListIcon className="w-6 h-6 text-indigo-600 group-hover:scale-110 transition-transform" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-indigo-700">إدارة معايير تقييم الطلاب والأقسام</p>
            </CardContent>
          </Link>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-50 to-orange-100 hover:shadow-xl transition-all cursor-pointer group mb-8">
          <Link href="/admin/testimonials">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2 text-amber-900">
                  <StarIcon className="w-5 h-5" />
                  التقييمات والآراء
                </CardTitle>
                <BarChartIcon className="w-6 h-6 text-amber-600 group-hover:scale-110 transition-transform" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-amber-700">عرض جميع تقييمات واستعراضات الطلاب</p>
            </CardContent>
          </Link>
        </Card>

        <div className="mt-12 mb-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
              الأقسام
            </h2>
            <p className="text-muted-foreground">اختر قسماً لعرض الطلاب</p>
          </div>
          <DepartmentNavigationGrid
            departments={DEPARTMENTS.map((dept) => ({
              label: dept.label,
              href: `/admin/departments/${dept.value}`,
              icon: dept.icon,
              color: dept.color,
              description: dept.label,
            }))}
          />
        </div>

        <Card className="border-0 shadow-lg mb-8 bg-gradient-to-br from-indigo-50 to-indigo-100">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <FileText className="w-6 h-6" />
              إدارة المنشورات
            </CardTitle>
            <CardDescription>أضف منشورات جديدة للصفحات المختلفة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, "youth-care": true })}
                className="p-4 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - رعاية الشباب
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, "student-union": true })}
                className="p-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - اتحاد الطلاب
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, "women-support": true })}
                className="p-4 bg-gradient-to-br from-rose-500 to-pink-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - تكافؤ الفرص والمرأة
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, uccd: true })}
                className="p-4 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - UCCD
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, "student-affairs": true })}
                className="p-4 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - شؤون الطلاب
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => setShowPostModals({ ...showPostModals, "mohamad-aimen": true })}
                className="p-4 bg-gradient-to-br from-violet-500 to-indigo-500 rounded-lg text-white font-semibold hover:shadow-lg transition-all"
              >
                إضافة منشور - محمد أيمن
              </motion.button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>قائمة الطلاب</CardTitle>
            <CardDescription>تحديث فوري - البيانات تتحدث تلقائياً</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
              </div>
            ) : employees.length === 0 ? (
              <div className="text-center py-12">
                <UsersIcon className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
                <p className="text-muted-foreground">لم يتم إضافة أي طلاب حتى الآن</p>
              </div>
            ) : (
              <EmployeeList employees={employees} onDelete={handleDeleteEmployee} onUpdate={handleUpdateEmployee} />
            )}
          </CardContent>
        </Card>
      </main>

      {showAddModal && (
        <AddEmployeeModal
          onClose={() => setShowAddModal(false)}
          onEmployeeAdded={() => {
            setShowAddModal(false)
          }}
        />
      )}

      {showGalleryModal && <AddGalleryImageModal onClose={() => setShowGalleryModal(false)} />}

      {showPostModals["youth-care"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, "youth-care": false })}
          category="youth-care"
          categoryName="رعاية الشباب"
          categoryColor="blue"
        />
      )}

      {showPostModals["student-union"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, "student-union": false })}
          category="student-union"
          categoryName="اتحاد الطلاب"
          categoryColor="purple"
        />
      )}

      {showPostModals["women-support"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, "women-support": false })}
          category="women-support"
          categoryName="وحدة تكافؤ الفرص ودعم المرأة"
          categoryColor="rose"
        />
      )}

      {showPostModals["uccd"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, uccd: false })}
          category="uccd"
          categoryName="مركز ربط الجامعة بالصناعة"
          categoryColor="amber"
        />
      )}

      {showPostModals["student-affairs"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, "student-affairs": false })}
          category="student-affairs"
          categoryName="شؤون الطلاب"
          categoryColor="green"
        />
      )}

      {showPostModals["mohamad-aimen"] && (
        <AddPostModal
          onClose={() => setShowPostModals({ ...showPostModals, "mohamad-aimen": false })}
          category="mohamad-aimen"
          categoryName="المبرمج محمد أيمن"
          categoryColor="violet"
        />
      )}
    </div>
  )
}

export default AdminDashboard
