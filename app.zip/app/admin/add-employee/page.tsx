"use client"

import EmployeeForm from "@/components/employee-form"

export default function AddEmployeePage() {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">إضافة طالب جديد</h1>
        <p className="text-muted mt-2">أدخل بيانات الطالب الجديد بشكل صحيح</p>
      </div>
      <EmployeeForm />
    </div>
  )
}
