"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, orderBy, onSnapshot } from "firebase/firestore"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import AdminHeader from "@/components/admin-header"
import AdminNavigation from "@/components/admin-navigation"
import { ArrowLeftIcon } from "@/components/icon-replacements"
import { motion } from "framer-motion"
import { TestimonialCard } from "@/components/testimonial-card"
import Link from "next/link"
import type { Testimonial } from "@/types/testimonial"

export default function AdminTestimonialsPage() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const testimonialsRef = collection(db, "testimonials")
    const q = query(testimonialsRef, orderBy("createdAt", "desc"))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const testimonialsData: Testimonial[] = []
        snapshot.forEach((doc) => {
          const data = doc.data()
          testimonialsData.push({
            id: doc.id,
            employeeId: data.employeeId,
            employeeName: data.employeeName,
            profileImage: data.profileImage,
            department: data.department,
            message: data.message,
            rating: data.rating,
            createdAt: data.createdAt,
          })
        })
        setTestimonials(testimonialsData)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error loading testimonials:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [])

  // دالة تسجيل الخروج الآن متوافقة مع Promise<void>
  const handleLogout = async (): Promise<void> => {
    // يمكن وضع أي كود تسجيل خروج هنا
    console.log("تم تسجيل الخروج")
    return
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
        <AdminHeader user={null} onLogout={handleLogout} />
        <AdminNavigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-amber-200 border-t-amber-600 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground font-medium">جاري تحميل التقييمات...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <AdminHeader user={null} onLogout={handleLogout} />
      <AdminNavigation />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
              التقييمات والآراء
            </h1>
            <p className="text-muted-foreground mt-2">جميع تقييمات واستعراضات الطلاب</p>
          </div>
          <Link href="/admin/dashboard">
            <Button variant="outline" className="gap-2 shadow-lg hover:shadow-xl transition-all bg-transparent">
              <ArrowLeftIcon className="w-4 h-4" />
              <span className="hidden sm:inline">العودة لوحة التحكم</span>
            </Button>
          </Link>
        </div>

        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <motion.div className="inline-block mb-6">
            <motion.div
              animate={{ rotate: [0, 8, -8, 0], y: [0, -5, 0] }}
              transition={{ duration: 3.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
              className="text-6xl md:text-7xl drop-shadow-lg"
            >
              ⭐
            </motion.div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold mb-4 px-4"
          >
            <span className="bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 bg-clip-text text-transparent">
              تقييمات واستعراضات الطلاب
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed px-4"
          >
            آراء صادقة وتقييمات حقيقية من طلابنا حول تجربتهم ورحلتهم التعليمية معنا
          </motion.p>
        </motion.div>

        {/* Testimonials Grid */}
        {testimonials.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center py-16"
          >
            <Card className="border-0 shadow-lg bg-white">
              <CardContent className="p-12 text-center">
                <div className="text-5xl mb-4">💭</div>
                <p className="text-lg font-semibold text-foreground mb-2">لا توجد تقييمات حتى الآن</p>
                <p className="text-muted-foreground">سيظهر هنا التقييمات عندما يقوم الطلاب بإضافتها</p>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, staggerChildren: 0.12, delayChildren: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {testimonials.map((testimonial, index) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} index={index} />
            ))}
          </motion.div>
        )}

        {/* Footer Divider */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="mt-20 flex items-center gap-4"
        >
          <motion.div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-300 to-transparent"></motion.div>
          <motion.span
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            className="text-amber-600 font-semibold text-sm whitespace-nowrap"
          >
            تقييمات الطلاب
          </motion.span>
          <motion.div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-300 to-transparent"></motion.div>
        </motion.div>
      </main>
    </div>
  )
}
