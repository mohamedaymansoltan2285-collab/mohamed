"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { useAuth } from "@/components/auth-context"
import LoginPage from "@/app/login/page"

export default function Home() {
  const { user, loading, userRole } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && user && userRole) {
      if (userRole === "admin") {
        router.push("/admin/dashboard")
      } else if (userRole === "employee") {
        router.push("/employee/profile")
      }
    }
  }, [user, loading, userRole, router])

  useEffect(() => {
    if (!loading && !user) {
      const hasVisitedWelcome = localStorage.getItem("hasVisitedWelcome")

      if (hasVisitedWelcome) {
        // Skip welcome and go directly to login
        router.push("/login")
      } else {
        // First visit - show welcome pages
        router.push("/welcome")
      }
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background to-muted-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-muted-background border-t-accent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  // If user is authenticated, routing is handled above
  // Otherwise, redirect to welcome/login page

  return <LoginPage />
}
