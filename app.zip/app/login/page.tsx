"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { db, auth } from "@/lib/firebase"
import { collection, query, where, getDocs } from "firebase/firestore"
import { signInWithEmailAndPassword } from "firebase/auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { AlertCircle, CheckCircle, Briefcase, LogIn, Lock, Mail } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [activeTab, setActiveTab] = useState<"student-code" | "student-email" | "admin">("student-code")

  // Student code login state
  const [employeeCode, setEmployeeCode] = useState("")
  const [employeeError, setEmployeeError] = useState("")
  const [employeeSuccess, setEmployeeSuccess] = useState("")
  const [employeeLoading, setEmployeeLoading] = useState(false)

  // Student email login state
  const [studentEmail, setStudentEmail] = useState("")
  const [studentPassword, setStudentPassword] = useState("")
  const [studentEmailError, setStudentEmailError] = useState("")
  const [studentEmailSuccess, setStudentEmailSuccess] = useState("")
  const [studentEmailLoading, setStudentEmailLoading] = useState(false)

  // Admin login state
  const [adminEmail, setAdminEmail] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [adminError, setAdminError] = useState("")
  const [adminSuccess, setAdminSuccess] = useState("")
  const [adminLoading, setAdminLoading] = useState(false)

  const router = useRouter()

  const handleCodeLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setEmployeeError("")
    setEmployeeSuccess("")

    if (!employeeCode || employeeCode.length !== 8) {
      setEmployeeError("يرجى إدخال رقم كودي صحيح (8 أرقام)")
      return
    }

    setEmployeeLoading(true)

    try {
      // Search for employee with this code
      const q = query(collection(db, "employees"), where("employeeCode", "==", employeeCode))
      const snapshot = await getDocs(q)

      if (snapshot.empty) {
        throw new Error("الرقم الكودي غير صحيح. يرجى التحقق من الرقم")
      }

      const employee = snapshot.docs[0].data()
      setEmployeeSuccess(`مرحباً ${employee.fullName}! جاري فتح ملفك الشخصي...`)

      setTimeout(() => {
        router.push(`/employee/profile-new?code=${employeeCode}`)
      }, 800)
    } catch (err: any) {
      setEmployeeError(err?.message || "حدث خطأ في البحث عن الموظف")
    } finally {
      setEmployeeLoading(false)
    }
  }

  const handleStudentEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setStudentEmailError("")
    setStudentEmailSuccess("")

    if (!studentEmail || !studentPassword) {
      setStudentEmailError("يرجى إدخال البريد الإلكتروني وكلمة المرور")
      return
    }

    setStudentEmailLoading(true)

    try {
      console.log("[v0] Starting student email login for:", studentEmail)
      const result = await signInWithEmailAndPassword(auth, studentEmail, studentPassword)
      if (result.user) {
        console.log("[v0] Firebase auth successful, searching for employee record")
        const q = query(collection(db, "employees"), where("email", "==", studentEmail))
        const snapshot = await getDocs(q)

        if (!snapshot.empty) {
          const employee = snapshot.docs[0].data()
          console.log("[v0] Employee found, redirecting with code:", employee.employeeCode)
          setStudentEmailSuccess(`مرحباً ${employee.fullName}! جاري فتح ملفك الشخصي...`)

          localStorage.setItem("employeeCode", employee.employeeCode)

          setTimeout(() => {
            router.push(`/employee/profile-new?code=${employee.employeeCode}`)
          }, 800)
        } else {
          console.error("[v0] No employee record found for email:", studentEmail)
          throw new Error("لم يتم العثور على بيانات الطالب")
        }
      }
    } catch (err: any) {
      console.error("[v0] Student email login error:", err)
      if (
        err.code === "auth/user-not-found" ||
        err.code === "auth/wrong-password" ||
        err.code === "auth/invalid-credential"
      ) {
        setStudentEmailError("البريد الإلكتروني أو كلمة المرور غير صحيحة")
      } else {
        setStudentEmailError(err?.message || "حدث خطأ في تسجيل الدخول")
      }
    } finally {
      setStudentEmailLoading(false)
    }
  }

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setAdminError("")
    setAdminSuccess("")

    if (!adminEmail || !adminPassword) {
      setAdminError("يرجى إدخال البريد الإلكتروني وكلمة المرور")
      return
    }

    setAdminLoading(true)

    try {
      const result = await signInWithEmailAndPassword(auth, adminEmail, adminPassword)
      if (result.user) {
        setAdminSuccess("مرحباً بك في لوحة التحكم! جاري فتح الصفحة...")
        setTimeout(() => {
          router.push("/admin/dashboard")
        }, 800)
      }
    } catch (err: any) {
      if (
        err.code === "auth/user-not-found" ||
        err.code === "auth/wrong-password" ||
        err.code === "auth/invalid-credential"
      ) {
        setAdminError("البريد الإلكتروني أو كلمة المرور غير صحيحة")
      } else {
        setAdminError("حدث خطأ في تسجيل الدخول. يرجى المحاولة مرة أخرى")
      }
    } finally {
      setAdminLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 p-4 relative overflow-hidden">
      {/* Background animation elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
      </div>

      <Card className="w-full max-w-md shadow-2xl border-0 relative z-10">
        <CardHeader className="space-y-2 bg-gradient-to-r from-blue-50 to-indigo-50 border-b text-center py-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-4 rounded-full">
              <Briefcase className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold">نظام الطلاب</CardTitle>
          <CardDescription className="text-base">دخول آمن للطلاب والإداريين</CardDescription>
        </CardHeader>

        <CardContent className="pt-8 pb-6">
          <div className="flex gap-2 mb-6 bg-gray-100 p-1 rounded-lg overflow-x-auto">
            <button
              onClick={() => setActiveTab("student-code")}
              className={`flex-1 py-2 px-3 rounded-md font-semibold text-sm transition-all whitespace-nowrap ${
                activeTab === "student-code" ? "bg-white text-blue-600 shadow-md" : "text-gray-600 hover:text-gray-800"
              }`}
            >
              <span className="flex items-center justify-center gap-1">
                <Briefcase className="w-4 h-4" />
                طالب (كود)
              </span>
            </button>
            <button
              onClick={() => setActiveTab("student-email")}
              className={`flex-1 py-2 px-3 rounded-md font-semibold text-sm transition-all whitespace-nowrap ${
                activeTab === "student-email" ? "bg-white text-blue-600 shadow-md" : "text-gray-600 hover:text-gray-800"
              }`}
            >
              <span className="flex items-center justify-center gap-1">
                <Mail className="w-4 h-4" />
                طالب (بريد)
              </span>
            </button>
            <button
              onClick={() => setActiveTab("admin")}
              className={`flex-1 py-2 px-3 rounded-md font-semibold text-sm transition-all whitespace-nowrap ${
                activeTab === "admin" ? "bg-white text-indigo-600 shadow-md" : "text-gray-600 hover:text-gray-800"
              }`}
            >
              <span className="flex items-center justify-center gap-1">
                <Lock className="w-4 h-4" />
                دكتور
              </span>
            </button>
          </div>

          {/* STUDENT CODE LOGIN FORM */}
          {activeTab === "student-code" && (
            <form onSubmit={handleCodeLogin} className="space-y-6 animate-in fade-in-50 duration-300">
              {/* Info box */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-700 leading-relaxed">
                  <span className="font-semibold block mb-1">للدخول:</span>
                  أدخل الرقم الكودي من 8 أرقام الذي تلقيته من شؤون الطلاب
                </p>
              </div>

              {/* Error message */}
              {employeeError && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border-2 border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{employeeError}</span>
                </div>
              )}

              {/* Success message */}
              {employeeSuccess && (
                <div className="flex items-center gap-3 p-4 bg-green-50 border-2 border-green-200 rounded-lg text-green-700 text-sm animate-in fade-in">
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="font-semibold">{employeeSuccess}</span>
                </div>
              )}

              {/* Input field */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">الرقم الجامعي</label>
                <Input
                  type="text"
                  placeholder="أدخل 8 أرقام"
                  value={employeeCode}
                  onChange={(e) => setEmployeeCode(e.target.value.replace(/\D/g, "").slice(0, 8))}
                  maxLength={8}
                  disabled={employeeLoading}
                  className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500 text-center text-2xl tracking-widest font-mono font-bold h-14"
                />
                <p className="text-xs text-gray-500 text-center">{employeeCode.length}/8 أرقام</p>
              </div>

              {/* Login button */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 h-12 text-base font-semibold transition-all transform hover:scale-[1.02] active:scale-[0.98]"
                disabled={employeeLoading || employeeCode.length !== 8}
              >
                {employeeLoading ? (
                  <>
                    <span className="inline-block animate-spin mr-2">⟳</span>
                    جاري الدخول...
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5 mr-2" />
                    الدخول
                  </>
                )}
              </Button>
              <div className="text-center text-sm text-muted-foreground border-t pt-4">
  <p>ليس لديك حساب؟</p>
  <Link href="/register" className="text-blue-600 hover:text-blue-700 font-semibold">
    إنشاء حساب جديد
  </Link>
</div>

            </form>
          )}

          {/* STUDENT EMAIL LOGIN FORM */}
          {activeTab === "student-email" && (
            <form onSubmit={handleStudentEmailLogin} className="space-y-6 animate-in fade-in-50 duration-300">
              {/* Info box */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-700 leading-relaxed">
                  <span className="font-semibold block mb-1">للدخول:</span>
                  أدخل البريد الإلكتروني وكلمة المرور التي استخدمتها عند التسجيل
                </p>
              </div>

              {/* Error message */}
              {studentEmailError && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border-2 border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{studentEmailError}</span>
                </div>
              )}

              {/* Success message */}
              {studentEmailSuccess && (
                <div className="flex items-center gap-3 p-4 bg-green-50 border-2 border-green-200 rounded-lg text-green-700 text-sm animate-in fade-in">
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="font-semibold">{studentEmailSuccess}</span>
                </div>
              )}

              {/* Email field */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  value={studentEmail}
                  onChange={(e) => setStudentEmail(e.target.value)}
                  disabled={studentEmailLoading}
                  className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Password field */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="أدخل كلمة المرور"
                  value={studentPassword}
                  onChange={(e) => setStudentPassword(e.target.value)}
                  disabled={studentEmailLoading}
                  className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Login button */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 h-12 text-base font-semibold transition-all transform hover:scale-[1.02] active:scale-[0.98]"
                disabled={studentEmailLoading || !studentEmail || !studentPassword}
              >
                {studentEmailLoading ? (
                  <>
                    <span className="inline-block animate-spin mr-2">⟳</span>
                    جاري الدخول...
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5 mr-2" />
                    الدخول
                  </>
                )}
              </Button>

              {/* Register link */}
              <div className="text-center text-sm text-muted-foreground border-t pt-4">
                <p>ليس لديك حساب؟</p>
                <Link href="/register" className="text-blue-600 hover:text-blue-700 font-semibold">
                  إنشاء حساب جديد
                </Link>
              </div>
            </form>
          )}

          {/* ADMIN LOGIN FORM */}
          {activeTab === "admin" && (
            <form onSubmit={handleAdminLogin} className="space-y-6 animate-in fade-in-50 duration-300">
              {/* Info box */}
              <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                <p className="text-sm text-indigo-700 leading-relaxed">
                  <span className="font-semibold block mb-1">دخول المدير:</span>
                  أدخل بيانات دخول المدير للوصول إلى لوحة التحكم
                </p>
              </div>

              {/* Error message */}
              {adminError && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border-2 border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{adminError}</span>
                </div>
              )}

              {/* Success message */}
              {adminSuccess && (
                <div className="flex items-center gap-3 p-4 bg-green-50 border-2 border-green-200 rounded-lg text-green-700 text-sm animate-in fade-in">
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="font-semibold">{adminSuccess}</span>
                </div>
              )}

              {/* Email field */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  disabled={adminLoading}
                  className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Password field */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="أدخل كلمة المرور"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  disabled={adminLoading}
                  className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Login button */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 h-12 text-base font-semibold transition-all transform hover:scale-[1.02] active:scale-[0.98]"
                disabled={adminLoading || !adminEmail || !adminPassword}
              >
                {adminLoading ? (
                  <>
                    <span className="inline-block animate-spin mr-2">⟳</span>
                    جاري الدخول...
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5 mr-2" />
                    دخول المدير
                  </>
                )}
              </Button>
            </form>
          )}

          {/* Bottom info */}
          <div className="mt-8 text-center border-t pt-6">
            <p className="text-xs text-gray-400">نظام إدارة الطلاب المتقدم • محمي بالتشفير الآمن</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
