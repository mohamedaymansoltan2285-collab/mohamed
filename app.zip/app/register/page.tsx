"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { db, auth } from "@/lib/firebase"
import { createUserWithEmailAndPassword } from "firebase/auth"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle, ArrowLeft, ArrowRight, Users, BookOpen, ClipboardList } from "lucide-react"
import { DEPARTMENTS } from "@/types/employee"

function generateEmployeeCode(): string {
  const min = 10000000
  const max = 99999999
  return Math.floor(Math.random() * (max - min + 1) + min).toString()
}

type RegistrationStep = "basic" | "academic" | "credentials" | "review" | "success"

interface FormData {
  fullName: string
  age: string
  gender: string
  phone: string
  address: string
  email: string
  password: string
  confirmPassword: string
  department: string
  maritalStatus: string
  emergencyPhone: string
}

export default function StudentRegistrationPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState<RegistrationStep>("basic")
  const [formData, setFormData] = useState<FormData>({
    fullName: "",
    age: "",
    gender: "",
    phone: "",
    address: "",
    email: "",
    password: "",
    confirmPassword: "",
    department: "تكنولوجيا المعلومات - الفرقة الأولى",
    maritalStatus: "",
    emergencyPhone: "",
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [generatedCode, setGeneratedCode] = useState("")
  const [studentData, setStudentData] = useState<any>(null)

  const steps: RegistrationStep[] = ["basic", "academic", "credentials", "review", "success"]
  const stepLabels = {
    basic: "البيانات الأساسية",
    academic: "البيانات الأكاديمية",
    credentials: "بيانات الدخول",
    review: "مراجعة البيانات",
    success: "تم التسجيل بنجاح",
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const validateStep = (): boolean => {
    setError("")

    if (currentStep === "basic") {
      if (!formData.fullName || !formData.phone || !formData.gender) {
        setError("يرجى ملء جميع الحقول المطلوبة")
        return false
      }
      if (formData.fullName.length < 3) {
        setError("الاسم يجب أن يكون 3 أحرف على الأقل")
        return false
      }
      if (!/^\d{10,}$/.test(formData.phone.replace(/\D/g, ""))) {
        setError("رقم الهاتف يجب أن يكون صحيحاً")
        return false
      }
    }

    if (currentStep === "academic") {
      if (!formData.department) {
        setError("يرجى اختيار القسم الأكاديمي")
        return false
      }
    }

    if (currentStep === "credentials") {
      if (!formData.email || !formData.password || !formData.confirmPassword) {
        setError("يرجى ملء جميع حقول بيانات الدخول")
        return false
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        setError("البريد الإلكتروني غير صحيح")
        return false
      }
      if (formData.password.length < 6) {
        setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل")
        return false
      }
      if (formData.password !== formData.confirmPassword) {
        setError("كلمة المرور غير متطابقة")
        return false
      }
    }

    return true
  }

  const handleNext = async () => {
    if (!validateStep()) return

    if (currentStep === "review") {
      await handleSubmit()
    } else {
      const nextStepIndex = steps.indexOf(currentStep) + 1
      if (nextStepIndex < steps.length) {
        setCurrentStep(steps[nextStepIndex])
      }
    }
  }

  const handlePrevious = () => {
    const prevStepIndex = steps.indexOf(currentStep) - 1
    if (prevStepIndex >= 0) {
      setCurrentStep(steps[prevStepIndex])
    }
  }

  const handleSubmit = async () => {
    setLoading(true)
    setError("")

    try {
      // Create Auth user
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password)
      const userId = userCredential.user.uid

      // Generate employee code
      const employeeCode = generateEmployeeCode()

      // Create employee document
      const employeeData = {
        uid: userId,
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        emergencyPhone: formData.emergencyPhone,
        address: formData.address,
        age: formData.age ? Number.parseInt(formData.age) : null,
        gender: formData.gender,
        maritalStatus: formData.maritalStatus,
        department: formData.department,
        employeeCode: employeeCode,
        status: "active",
        role: "employee",
        joinDate: new Date().toISOString().split("T")[0],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      await addDoc(collection(db, "employees"), employeeData)

      // Create user document for auth context
      const userDocData = {
        uid: userId,
        email: formData.email,
        role: "employee",
        createdAt: new Date().toISOString(),
      }
      await addDoc(collection(db, "users"), userDocData)

      setGeneratedCode(employeeCode)
      setStudentData(employeeData)
      setCurrentStep("success")
      setSuccess(`تم التسجيل بنجاح! الرقم الكودي: ${employeeCode}`)
    } catch (err: any) {
      if (err.code === "auth/email-already-in-use") {
        setError("هذا البريد الإلكتروني مسجل بالفعل")
      } else if (err.code === "auth/weak-password") {
        setError("كلمة المرور ضعيفة جداً")
      } else {
        setError(err?.message || "حدث خطأ في التسجيل")
      }
    } finally {
      setLoading(false)
    }
  }

  const handleNavigateToLogin = () => {
    router.push("/login")
  }

  const getProgress = (): number => {
    const stepIndex = steps.indexOf(currentStep)
    return ((stepIndex + 1) / steps.length) * 100
  }

  const stepIcons: Record<RegistrationStep, React.ReactNode> = {
    basic: <Users className="w-5 h-5" />,
    academic: <BookOpen className="w-5 h-5" />,
    credentials: <ClipboardList className="w-5 h-5" />,
    review: <CheckCircle className="w-5 h-5" />,
    success: <CheckCircle className="w-5 h-5" />,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4 pt-8">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-2">إنشاء حساب جامعي</h1>
          <p className="text-muted-foreground text-lg">مرحباً بك في جامعة بني سويف التكنولوجية</p>
        </div>

        {/* Progress Bar */}
        {currentStep !== "success" && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-muted-foreground">
                الخطوة {steps.indexOf(currentStep) + 1} من {steps.length}
              </span>
              <span className="text-sm font-semibold text-muted-foreground">{stepLabels[currentStep]}</span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-500"
                style={{ width: `${getProgress()}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Steps Indicator */}
        {currentStep !== "success" && (
          <div className="mb-8 flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step} className="flex items-center flex-1">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 ${
                    steps.indexOf(currentStep) >= index
                      ? "bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-lg"
                      : "bg-slate-200 text-muted-foreground"
                  }`}
                >
                  {steps.indexOf(currentStep) > index ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <span className="text-sm font-bold">{index + 1}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-2 transition-all duration-300 ${
                      steps.indexOf(currentStep) > index ? "bg-blue-500" : "bg-slate-200"
                    }`}
                  ></div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Main Card */}
        <Card className="shadow-2xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
            <CardTitle className="flex items-center gap-2 text-2xl">
              {stepIcons[currentStep]}
              {stepLabels[currentStep]}
            </CardTitle>
            <CardDescription className="text-base">
              {currentStep === "basic" && "أخبرنا عن نفسك"}
              {currentStep === "academic" && "اختر تخصصك الأكاديمي"}
              {currentStep === "credentials" && "إنشاء بيانات الدخول الخاصة بك"}
              {currentStep === "review" && "تحقق من البيانات قبل الحفظ"}
              {currentStep === "success" && "تم إنشاء حسابك بنجاح!"}
            </CardDescription>
          </CardHeader>

          <CardContent className="pt-8 pb-8">
            {/* Error Message */}
            {error && (
              <div className="mb-6 flex items-start gap-3 p-4 bg-red-50 border-2 border-red-300 rounded-lg text-red-700 animate-in fade-in">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span className="font-semibold">{error}</span>
              </div>
            )}

           {/* Success Message */}
{success && (
  <div className="mb-6 flex items-start gap-3 p-4 bg-green-50 border-2 border-green-300 rounded-lg text-green-700 animate-in fade-in">
    <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
    <span className="font-semibold">{success}</span>
  </div>
)}

{/* Step 1: Basic Information */}
{currentStep === "basic" && (
  <div className="space-y-4 animate-fade-in">

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">الاسم الكامل *</label>
        <Input
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          disabled={loading}
          className="transition-all focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">العمر</label>
        <Input
          type="number"
          name="age"
          value={formData.age}
          onChange={handleChange}
          disabled={loading}
          min="18"
          className="transition-all focus:ring-2 focus:ring-blue-500"
        />
      </div>

    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">النوع *</label>
        <select
          name="gender"
          value={formData.gender}
          onChange={handleChange}
          disabled={loading}
          className="px-4 py-2.5 border border-input rounded-md bg-background text-foreground transition-all focus:ring-2 focus:ring-blue-500 font-semibold"
        >
          <option value="">اختر النوع *</option>
          <option value="ذكر">ذكر</option>
          <option value="أنثى">أنثى</option>
        </select>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">الحالة الاجتماعية</label>
        <select
          name="maritalStatus"
          value={formData.maritalStatus}
          onChange={handleChange}
          disabled={loading}
          className="px-4 py-2.5 border border-input rounded-md bg-background text-foreground transition-all focus:ring-2 focus:ring-blue-500 font-semibold"
        >
          <option value="">الحالة الاجتماعية</option>
          <option value="أعزب">أعزب</option>
          <option value="متزوج">متزوج</option>
          <option value="مطلق">مطلق</option>
        </select>
      </div>

    </div>

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">رقم الهاتف *</label>
      <Input
        name="phone"
        value={formData.phone}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">رقم الطوارئ</label>
      <Input
        name="emergencyPhone"
        value={formData.emergencyPhone}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">العنوان</label>
      <Input
        name="address"
        value={formData.address}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

  </div>
)}

{/* Step 2: Academic Information */}
{currentStep === "academic" && (
  <div className="space-y-6 animate-fade-in">
    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">اختر التخصص الأكاديمي *</label>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {DEPARTMENTS.map((dept) => (
          <div
            key={dept.value}
            onClick={() =>
              handleChange({
                target: { name: "department", value: dept.value },
              } as any)
            }
            className={`p-4 border-2 rounded-lg cursor-pointer transition-all duration-300 ${
              formData.department === dept.value
                ? "border-blue-500 bg-blue-50"
                : "border-slate-200 hover:border-slate-300"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">{dept.icon}</span>
              <div>
                <p className="font-semibold text-sm">{dept.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>

    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
      <p className="text-sm text-blue-700">
        <span className="font-semibold block mb-1">التخصص المختار:</span>
        {formData.department}
      </p>
    </div>
  </div>
)}

{/* Step 3: Credentials */}
{currentStep === "credentials" && (
  <div className="space-y-4 animate-fade-in">

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">البريد الإلكتروني *</label>
      <Input
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">كلمة المرور *</label>
      <Input
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">تأكيد كلمة المرور *</label>
      <Input
        type="password"
        name="confirmPassword"
        value={formData.confirmPassword}
        onChange={handleChange}
        disabled={loading}
        className="transition-all focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700">
      <p className="font-semibold mb-2">متطلبات كلمة المرور:</p>
      <ul className="space-y-1 text-xs">
        <li className="flex items-center gap-2">
          <span className={formData.password.length >= 6 ? "text-green-600" : "text-slate-400"}>✓</span>
          6 أحرف على الأقل
        </li>
        <li className="flex items-center gap-2">
          <span className={
            formData.password === formData.confirmPassword && formData.password
              ? "text-green-600"
              : "text-slate-400"
          }>✓</span>
          كلمات المرور متطابقة
        </li>
      </ul>
    </div>

  </div>
)}


            {/* Step 4: Review */}
            {currentStep === "review" && (
              <div className="space-y-6 animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-foreground border-b pb-2">البيانات الأساسية</h3>
                    <div className="space-y-2 text-sm">
                      <p>
                        <span className="font-semibold text-muted-foreground">الاسم:</span>
                        <span className="float-left">{formData.fullName}</span>
                      </p>
                      <p>
                        <span className="font-semibold text-muted-foreground">العمر:</span>
                        <span className="float-left">{formData.age || "لم يتم التحديد"}</span>
                      </p>
                      <p>
                        <span className="font-semibold text-muted-foreground">النوع:</span>
                        <span className="float-left">{formData.gender}</span>
                      </p>
                      <p>
                        <span className="font-semibold text-muted-foreground">الهاتف:</span>
                        <span className="float-left">{formData.phone}</span>
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-foreground border-b pb-2">البيانات الأكاديمية</h3>
                    <div className="space-y-2 text-sm">
                      <p>
                        <span className="font-semibold text-muted-foreground">التخصص:</span>
                        <span className="float-left">{formData.department}</span>
                      </p>
                      <p>
                        <span className="font-semibold text-muted-foreground">البريد:</span>
                        <span className="float-left">{formData.email}</span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg text-yellow-700 text-sm">
                  <p className="font-semibold mb-1">تأكيد بيانات التسجيل</p>
                  <p>تأكد من صحة جميع البيانات المدخلة قبل الضغط على زر التسجيل النهائي</p>
                </div>
              </div>
            )}

            {/* Step 5: Success */}
            {currentStep === "success" && (
              <div className="space-y-6 animate-fade-in text-center py-8">
                <div className="flex justify-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center animate-pulse">
                    <CheckCircle className="w-12 h-12 text-white" />
                  </div>
                </div>

                <div className="space-y-2">
                  <h2 className="text-3xl font-bold text-foreground">مرحباً {formData.fullName}!</h2>
                  <p className="text-lg text-muted-foreground">تم إنشاء حسابك بنجاح في النظام</p>
                </div>

                <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-lg space-y-3">
                  <p className="text-sm text-blue-600 font-semibold">الرقم الكودي الجامعي:</p>
                  <p className="text-4xl font-bold text-blue-900 tracking-widest font-mono">{generatedCode}</p>
                  <p className="text-xs text-blue-600">احفظ هذا الرقم - ستحتاجه لتسجيل الدخول بدون بيانات الدخول</p>
                </div>

                <div className="space-y-2 text-sm text-muted-foreground">
                  <p className="font-semibold text-foreground">البيانات الأساسية:</p>
                  <p>
                    التخصص: <span className="font-semibold text-foreground">{formData.department}</span>
                  </p>
                  <p>
                    البريد: <span className="font-semibold text-foreground">{formData.email}</span>
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex gap-4">
          {currentStep !== "success" && (
            <>
              <Button
                onClick={handlePrevious}
                variant="outline"
                disabled={steps.indexOf(currentStep) === 0 || loading}
                className="flex-1 bg-white hover:bg-slate-50 gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                رجوع
              </Button>

              <Button
                onClick={handleNext}
                disabled={loading || !!error}
                className={`flex-1 gap-2 ${
                  currentStep === "review"
                    ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                    : "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
                }`}
              >
                {loading ? (
                  <>
                    <span className="inline-block animate-spin">⟳</span>
                    جاري المعالجة...
                  </>
                ) : (
                  <>
                    {currentStep === "review" ? "تأكيد التسجيل" : "التالي"}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </Button>
            </>
          )}

          {currentStep === "success" && (
            <Button
              onClick={handleNavigateToLogin}
              className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 gap-2 h-12"
            >
              <span>الآن انتقل لتسجيل الدخول</span>
              <ArrowLeft className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Bottom Info */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>هل لديك حساب بالفعل؟</p>
          <Button
            onClick={handleNavigateToLogin}
            variant="link"
            className="text-blue-600 hover:text-blue-700 font-semibold px-0"
          >
            انتقل لتسجيل الدخول
          </Button>
        </div>
      </div>
    </div>
  )
}
