import type React from "react"
import type { Metadata } from "next"

import "./globals.css"
import { AuthProvider } from "@/components/auth-context"
import { AudioProvider } from "@/components/audio-context"
import { Geist, Geist_Mono } from "next/font/google"

const geist = Geist({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
})

function getMetadataBase() {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.VERCEL_URL
  if (!appUrl) {
    return new URL("https://btu.edu.eg")
  }
  try {
    return new URL(appUrl.startsWith("http") ? appUrl : `https://${appUrl}`)
  } catch (e) {
    return new URL("https://btu.edu.eg")
  }
}

export const metadata: Metadata = {
  metadataBase: getMetadataBase(),
  title: {
    default: "جامعة بني سويف التكنولوجية | نظام إدارة الطلاب",
    template: "%s | جامعة بني سويف التكنولوجية",
  },
  description: "نظام احترافي لإدارة بيانات الطلاب والخدمات الجامعية في جامعة بني سويف التكنولوجية.",
  keywords: ["جامعة بني سويف التكنولوجية", "BTU", "نظام الطلاب", "تعليم تكنولوجي", "مصر"],
  authors: [{ name: "Beni-Suef Technological University" }],
  creator: "Beni-Suef Technological University",
  openGraph: {
    title: "جامعة بني سويف التكنولوجية | نظام إدارة الطلاب",
    description: "نظام احترافي لإدارة بيانات الطلاب والخدمات الجامعية في جامعة بني سويف التكنولوجية.",
    url: "/",
    siteName: "جامعة بني سويف التكنولوجية",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "شعار جامعة بني سويف التكنولوجية",
      },
    ],
    locale: "ar_EG",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "جامعة بني سويف التكنولوجية",
    description: "نظام احترافي لإدارة بيانات الطلاب والخدمات الجامعية.",
    images: ["/og-image.png"],
    creator: "@BTU_Egypt",
  },
  robots: {
    index: true,
    follow: true,
  },
  generator: "mohamed ayman",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className={`${geist.className} bg-background text-foreground antialiased`}>
        <AudioProvider>
          <AuthProvider>{children}</AuthProvider>
        </AudioProvider>
      </body>
    </html>
  )
}
