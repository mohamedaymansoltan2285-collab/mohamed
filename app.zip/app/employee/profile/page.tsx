"use client"

import {
  LogOutIcon,
  MessageCircleIcon,
  MailIcon,
  PhoneIcon,
  BriefcaseIcon,
  CalendarIcon,
  MapPinIcon,
} from "@/components/icon-replacements"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, getDocs, updateDoc, doc } from "firebase/firestore"
import type { Employee } from "@/types/employee"
import ProfileImageUploader from "@/components/profile-image-uploader"
import EmployeeStats from "@/components/employee-stats"
import EmployeeRatingsDisplay from "@/components/employee-ratings-display"
import PersonalDataSection from "@/components/personal-data-section"
import StudentLecturesList from "@/components/student-lectures-list"
import StudentAttendanceStats from "@/components/student-attendance-stats"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, User, Award } from "lucide-react"

const DEPARTMENT_MAP: Record<string, { color: string; icon: string; label: string }> = {
  "تكنولوجيا المعلومات - الفرقة الأولى": {
    color: "from-blue-500 to-cyan-500",
    icon: "💻",
    label: "تكنولوجيا المعلومات - الفرقة الأولى",
  },
  "تكنولوجيا المعلومات - الفرقة الثانية": {
    color: "from-blue-600 to-cyan-600",
    icon: "💻",
    label: "تكنولوجيا المعلومات - الفرقة الثانية",
  },
  "تكنولوجيا المعلومات - الفرقة الثالثة": {
    color: "from-blue-700 to-cyan-700",
    icon: "💻",
    label: "تكنولوجيا المعلومات - الفرقة الثالثة",
  },
  "تكنولوجيا المعلومات - الفرقة الرابعة": {
    color: "from-blue-800 to-cyan-800",
    icon: "💻",
    label: "تكنولوجيا المعلومات - الفرقة الرابعة",
  },
  "ميكاترونيكس - الفرقة الأولى": {
    color: "from-purple-500 to-violet-500",
    icon: "🤖",
    label: "ميكاترونيكس - الفرقة الأولى",
  },
  "ميكاترونيكس - الفرقة الثانية": {
    color: "from-purple-600 to-violet-600",
    icon: "🤖",
    label: "ميكاترونيكس - الفرقة الثانية",
  },
  "ميكاترونيكس - الفرقة الثالثة": {
    color: "from-purple-700 to-violet-700",
    icon: "🤖",
    label: "ميكاترونيكس - الفرقة الثالثة",
  },
  "ميكاترونيكس - الفرقة الرابعة": {
    color: "from-purple-800 to-violet-800",
    icon: "🤖",
    label: "ميكاترونيكس - الفرقة الرابعة",
  },
  "أوتوترونيكس - الفرقة الأولى": {
    color: "from-orange-500 to-red-500",
    icon: "🚗",
    label: "أوتوترونيكس - الفرقة الأولى",
  },
  "أوتوترونيكس - الفرقة الثانية": {
    color: "from-orange-600 to-red-600",
    icon: "🚗",
    label: "أوتوترونيكس - الفرقة الثانية",
  },
  "أوتوترونيكس - الفرقة الثالثة": {
    color: "from-orange-700 to-red-700",
    icon: "🚗",
    label: "أوتوترونيكس - الفرقة الثالثة",
  },
  "أوتوترونيكس - الفرقة الرابعة": {
    color: "from-orange-800 to-red-800",
    icon: "🚗",
    label: "أوتوترونيكس - الفرقة الرابعة",
  },
}

export default function EmployeeProfilePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [employee, setEmployee] = useState<Employee | null>(null)
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [isReadOnly, setIsReadOnly] = useState(false)
  const [employeeId, setEmployeeId] = useState<string>("")
  const [activeTab, setActiveTab] = useState("profile")

  useEffect(() => {
    let mounted = true

    const fetchEmployee = async () => {
      const code = searchParams.get("code") || localStorage.getItem("employeeCode")
      const adminParam = searchParams.get("admin") === "true"
      const readOnlyParam = searchParams.get("readonly") === "true"

      if (!code) {
        if (mounted) router.push("/login")
        return
      }

      try {
        const q = query(collection(db, "employees"), where("employeeCode", "==", code))
        const snapshot = await getDocs(q)

        if (!mounted) return

        if (!snapshot.empty) {
          const docData = snapshot.docs[0]
          const data = docData.data() as Employee

          setEmployee(data)
          setEmployeeId(docData.id)
          setIsAdmin(adminParam)
          setIsReadOnly(readOnlyParam)

          if (!adminParam && !readOnlyParam) {
            localStorage.setItem("employeeCode", code)
          }
        } else {
          router.push("/login")
        }
      } catch (error) {
        console.error("[v0] Error fetching employee:", error)
        if (mounted) router.push("/login")
      } finally {
        if (mounted) setLoading(false)
      }
    }

    fetchEmployee()

    return () => {
      mounted = false
    }
  }, [searchParams, router])

  const handleImageUpload = async (imageUrl: string) => {
    if (!employeeId) return

    try {
      const employeeRef = doc(db, "employees", employeeId)
      await updateDoc(employeeRef, { profileImage: imageUrl })
      setEmployee((prev) => (prev ? { ...prev, profileImage: imageUrl } : null))
    } catch (error) {
      console.error("[v0] Error updating profile image:", error)
      throw error
    }
  }

  const handleNavigateToForum = () => {
    window.location.href = `/employee/forum?code=${employee?.employeeCode}`
  }

  const handleNavigateToTestimonials = () => {
    window.location.href = `/employee/testimonials?code=${employee?.employeeCode}`
  }

  const handleLogout = () => {
    localStorage.removeItem("employeeCode")
    router.push("/login")
  }

  const getDepartmentInfo = () => {
    const dept = employee?.department || ""
    if (DEPARTMENT_MAP[dept]) {
      return DEPARTMENT_MAP[dept]
    }

    let color = "from-blue-500 to-cyan-500"
    let icon = "🎓"

    if (dept.includes("سكة حديد")) {
      color = "from-slate-600 to-zinc-600"
      icon = "🚂"
    } else if (dept.includes("تبريد") || dept.includes("تكييف")) {
      color = "from-cyan-500 to-blue-600"
      icon = "❄️"
    } else if (dept.includes("طاقة") || dept.includes("متجددة")) {
      color = "from-green-500 to-emerald-600"
      icon = "⚡"
    } else if (dept.includes("تحكم") || dept.includes("صناعية")) {
      color = "from-amber-600 to-orange-700"
      icon = "🏭"
    } else if (dept.includes("ميكاترونيكس")) {
      color = "from-purple-600 to-indigo-600"
      icon = "🤖"
    } else if (dept.includes("أوتوترونيكس")) {
      color = "from-orange-500 to-red-600"
      icon = "🚗"
    }

    return {
      color,
      icon,
      label: dept || "الإدارة",
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-muted-background border-t-accent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted">جاري تحميل البيانات...</p>
        </div>
      </div>
    )
  }

  if (!employee) {
    return null
  }

  const deptInfo = getDepartmentInfo()
  const initials = employee.fullName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background">
      <div className="container mx-auto px-4 py-8">
        <div className={`mb-8 rounded-2xl bg-gradient-to-r ${deptInfo.color} text-white shadow-2xl overflow-hidden`}>
          <div className="p-8 md:p-12">
            <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
              <div className="flex-shrink-0">
                <Avatar className="w-32 h-32 md:w-40 md:h-40 border-4 border-white shadow-lg">
                  <AvatarImage src={employee.profileImage || "/placeholder.svg"} alt={employee.fullName} />
                  <AvatarFallback className="bg-white/20 text-white text-4xl font-bold">{initials}</AvatarFallback>
                </Avatar>
              </div>

              <div className="flex-1">
                <div className="text-5xl font-bold mb-2">{deptInfo.icon}</div>
                <h1 className="text-4xl font-bold mb-2">{employee.fullName}</h1>
                <p className="text-lg opacity-90 mb-4">الرقم الكودي: {employee.employeeCode}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <Badge className="bg-white/20 text-white border-white/30 text-sm px-3 py-1.5">{deptInfo.label}</Badge>
                  <Badge
                    className={`text-sm px-3 py-1.5 ${
                      employee.status === "active"
                        ? "bg-green-400/20 text-green-100 border-green-300/30"
                        : "bg-red-400/20 text-red-100 border-red-300/30"
                    }`}
                  >
                    {employee.status === "active" ? "موظف نشط" : "غير نشط"}
                  </Badge>
                  {employee.role === "admin" && (
                    <Badge className="bg-purple-400/20 text-purple-100 border-purple-300/30 text-sm px-3 py-1.5">
                      مسؤول
                    </Badge>
                  )}
                </div>

                <div className="flex gap-3 flex-wrap">
                  <Button
                    onClick={handleNavigateToForum}
                    className="bg-white text-blue-600 hover:bg-white/90 font-semibold gap-2 shadow-lg"
                  >
                    <MessageCircleIcon className="w-5 h-5" />
                    الملتقى الذاتي
                  </Button>
                  <Button
                    onClick={handleNavigateToTestimonials}
                    className="bg-white text-amber-600 hover:bg-white/90 font-semibold gap-2 shadow-lg"
                  >
                    <span className="text-lg">⭐</span>
                    التقييمات
                  </Button>
                  {!isAdmin && !isReadOnly && (
                    <Button
                      onClick={handleLogout}
                      className="bg-white/20 hover:bg-white/30 text-white border border-white/30 gap-2"
                    >
                      <LogOutIcon className="w-4 h-4" />
                      تسجيل الخروج
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 lg:w-[400px] mx-auto mb-8">
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              الملف الشخصي
            </TabsTrigger>
            <TabsTrigger value="lectures" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              المحاضرات والحضور
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-8">
            {!isAdmin && !isReadOnly && (
              <div className="mb-8">
                <ProfileImageUploader
                  employeeName={employee.fullName}
                  currentImageUrl={employee.profileImage}
                  onImageUpload={handleImageUpload}
                  canUpload={true}
                  disabled={false}
                />
              </div>
            )}

            <div className="mb-8">
              <EmployeeStats employee={employee} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              <Card className="lg:col-span-2 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
                  <CardTitle>البيانات الشخصية</CardTitle>
                  <CardDescription>معلومات الموظف الأساسية</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <BriefcaseIcon className="w-4 h-4" />
                        الاسم الكامل
                      </label>
                      <p className="text-lg font-semibold text-foreground">{employee.fullName}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <Badge className="w-4 h-4 bg-blue-600" />
                        الرقم الكودي
                      </label>
                      <p className="text-lg font-semibold text-foreground font-mono">{employee.employeeCode}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <MailIcon className="w-4 h-4" />
                        البريد الإلكتروني
                      </label>
                      <p className="text-lg font-semibold text-foreground">{employee.email}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <PhoneIcon className="w-4 h-4" />
                        رقم الهاتف
                      </label>
                      <p className="text-lg font-semibold text-foreground">{employee.phone}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <BriefcaseIcon className="w-4 h-4" />
                        القسم
                      </label>
                      <div className="inline-block bg-blue-100 text-blue-700 px-4 py-2 rounded-lg font-semibold">
                        {employee.department}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                        <CalendarIcon className="w-4 h-4" />
                        تاريخ الانضمام
                      </label>
                      <p className="text-lg font-semibold text-foreground">
                        {new Date(employee.joinDate).toLocaleDateString("ar-SA")}
                      </p>
                    </div>

                    {employee.age && (
                      <div className="space-y-2">
                        <label className="text-sm font-semibold text-muted-foreground">العمر</label>
                        <p className="text-lg font-semibold text-foreground">{employee.age} سنة</p>
                      </div>
                    )}

                    {employee.gender && (
                      <div className="space-y-2">
                        <label className="text-sm font-semibold text-muted-foreground">النوع</label>
                        <p className="text-lg font-semibold text-foreground">
                          {employee.gender === "ذكر" || employee.gender === "male" ? "ذكر" : "أنثى"}
                        </p>
                      </div>
                    )}

                    {employee.maritalStatus && (
                      <div className="space-y-2">
                        <label className="text-sm font-semibold text-muted-foreground">الحالة الاجتماعية</label>
                        <p className="text-lg font-semibold text-foreground">
                          {["متزوج", "أعزب", "مطلق", "أرمل"].includes(employee.maritalStatus)
                            ? employee.maritalStatus
                            : employee.maritalStatus}
                        </p>
                      </div>
                    )}

                    {employee.address && (
                      <div className="md:col-span-2 space-y-2">
                        <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                          <MapPinIcon className="w-4 h-4" />
                          العنوان
                        </label>
                        <p className="text-lg font-semibold text-foreground">{employee.address}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <Card className="shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b">
                    <CardTitle>الإجراءات السريعة</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-3">
                    <Button
                      onClick={handleNavigateToForum}
                      className="w-full justify-start gap-3 h-auto py-3 px-4 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white shadow-lg"
                      size="lg"
                    >
                      <MessageCircleIcon className="w-5 h-5" />
                      <div className="text-right">
                        <div className="font-semibold">الملتقى الذاتي</div>
                        <div className="text-xs opacity-80">شارك وتواصل مع الزملاء</div>
                      </div>
                    </Button>

                    <Button
                      onClick={handleNavigateToTestimonials}
                      className="w-full justify-start gap-3 h-auto py-3 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-lg"
                      size="lg"
                    >
                      <span className="text-lg">⭐</span>
                      <div className="text-right">
                        <div className="font-semibold">صفحة التقييمات</div>
                        <div className="text-xs opacity-80">اطلع على تقييمات الطلاب</div>
                      </div>
                    </Button>

                    {!isAdmin && !isReadOnly && (
                      <Button
                        onClick={handleLogout}
                        variant="outline"
                        className="w-full justify-start gap-3 h-auto py-3 px-4 border-red-200 text-red-600 hover:bg-red-50 bg-transparent"
                        size="lg"
                      >
                        <LogOutIcon className="w-5 h-5" />
                        <div className="text-right">
                          <div className="font-semibold">تسجيل الخروج</div>
                          <div className="text-xs opacity-80">إنهاء جلسة العمل</div>
                        </div>
                      </Button>
                    )}
                  </CardContent>
                </Card>

                <Card className="shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 border-b">
                    <CardTitle className="text-base">معلومات إضافية</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-4">
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <span className="text-sm font-medium">الحالة</span>
                      <Badge
                        className={
                          employee.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        }
                      >
                        {employee.status === "active" ? "نشط" : "غير نشط"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <span className="text-sm font-medium">الدور</span>
                      <Badge
                        className={
                          employee.role === "admin" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                        }
                      >
                        {employee.role === "admin" ? "مسؤول" : "موظف"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="mb-8">
              <Card className="shadow-lg border-0">
                <CardHeader className="bg-gradient-to-r from-indigo-50 to-blue-50 border-b">
                  <CardTitle>تقييمات الأداء</CardTitle>
                  <CardDescription>معايير التقييم ومستويات الأداء</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <EmployeeRatingsDisplay employeeId={employeeId} departmentId={employee.department} />
                </CardContent>
              </Card>
            </div>

            <div className="mb-8">
              <div className="mb-6">
                <h2 className="text-3xl font-bold text-foreground mb-2">معلومات إضافية</h2>
                <p className="text-muted-foreground">قسم البيانات الشخصية الإضافية</p>
              </div>
              <PersonalDataSection employeeId={employeeId} canEdit={!isAdmin} />
            </div>
          </TabsContent>

          <TabsContent value="lectures" className="space-y-8">
            <div className="grid gap-8">
              <section>
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Award className="w-6 h-6 text-yellow-500" />
                  إحصائيات الحضور
                </h2>
                <StudentAttendanceStats studentId={employeeId} departmentId={employee.department} />
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <BookOpen className="w-6 h-6 text-blue-500" />
                  المحاضرات المتاحة
                </h2>
                <StudentLecturesList studentId={employeeId} departmentId={employee.department} />
              </section>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
