// app/employee/forum/page.tsx
// ✅ لا نستخدم 'use client' هنا. نتركها Server Component افتراضياً.
// ✅ نستخدم dynamic هنا للتأكد من عدم التخزين المؤقت، إذا لزم الأمر.

import { Suspense } from "react";
// يجب التأكد من مسار الاستيراد الصحيح:
import ForumContent from "./ForumContent"; 

// ✅ تأكد من وجود هذا السطر هنا بدلاً من ForumContent
export const dynamic = "force-dynamic"; 

// مكون التحميل الاحتياطي
const ForumLoadingFallback = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
       <div className="text-center">
         <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
         <p className="text-muted-foreground font-medium">جاري تحميل الملتقى...</p>
       </div>
    </div>
);

export default function Page() {
  return (
    <Suspense fallback={<ForumLoadingFallback />}>
      <ForumContent />
    </Suspense>
  );
}