// app/employee/forum/ForumContent.tsx
"use client"

import { useEffect, useState, useMemo, useCallback } from "react"
// ✅ استخدام useSearchParams مباشرة (تمت حمايته بواسطة Suspense في المكون الأب)
import { useSearchParams, useRouter } from "next/navigation" 
import { db } from "@/lib/firebase"
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  addDoc,
  serverTimestamp,
  orderBy,
  getDocs,
  limit,
} from "firebase/firestore"

// استيراد المكونات
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Share2, Search, ArrowLeft, LogOut, Users, X } from "lucide-react" 
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { getInitials } from "@/utils/forum-utils" 

import PostCard from "@/components/PostCard" 

import type { Testimonial } from "@/types/testimonial" 
import { TestimonialsSection } from "@/components/testimonials-section"
import { Employee, Post } from "@/types/forum" 

interface ForumState {
  currentEmployee: Employee | null
  loading: boolean
  error: string | null
  postContent: string
  isSubmitting: boolean
  searchQuery: string
  searchResults: Employee[]
  selectedEmployee: Employee | null
  commentingPostId: string | null
  commentContent: string
  isSubmittingComment: boolean
  copiedPostId: string | null
  showLikers: string | null 
  likersData: Record<string, Employee[]>
}

const initialState: ForumState = {
  currentEmployee: null,
  loading: true,
  error: null,
  postContent: "",
  isSubmitting: false,
  searchQuery: "",
  searchResults: [],
  selectedEmployee: null,
  commentingPostId: null,
  commentContent: "",
  isSubmittingComment: false,
  copiedPostId: null,
  showLikers: null,
  likersData: {},
}

export default function ForumContent() { 
  const router = useRouter()
  
  // ✅ استخدام useSearchParams مباشرة
  const searchParams = useSearchParams() 
  const employeeCodeFromParams = searchParams?.get("code")

  const { toast } = useToast()
  
  const [forumState, setForumState] = useState<ForumState>(initialState)
  const [posts, setPosts] = useState<Post[]>([])
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])

  const updateState = useCallback((updates: Partial<ForumState>) => {
    setForumState((prev) => ({ ...prev, ...updates }))
  }, [])
  
  const { 
    currentEmployee, loading, error, postContent, isSubmitting, 
    searchQuery, searchResults, selectedEmployee, commentingPostId, 
    commentContent, isSubmittingComment, copiedPostId, showLikers, 
    likersData 
  } = forumState
  
  // ✅ استخدام localStorage بعد التحقق من بيئة العميل
  const employeeCode = useMemo(() => {
    if (employeeCodeFromParams) return employeeCodeFromParams
    if (typeof window !== 'undefined') {
        return localStorage.getItem("employeeCode")
    }
    return null
  }, [employeeCodeFromParams])

  // ❌ تم إزالة isMounted

  // useEffect لجلب بيانات الموظف والتحقق من التوثيق
  useEffect(() => {
    if (!employeeCode) {
      updateState({ error: "لم يتم توفير رقم الموظف", loading: false })
      setTimeout(() => router.push("/login"), 1500)
      return
    }

    const q = query(collection(db, "employees"), where("employeeCode", "==", employeeCode), limit(1))
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot.empty) {
          const data = snapshot.docs[0].data()
          updateState({
            currentEmployee: {
              id: snapshot.docs[0].id,
              fullName: data.fullName,
              employeeCode: data.employeeCode,
              profileImage: data.profileImage,
              department: data.department,
            },
            loading: false,
            error: null,
          })
          if (typeof window !== 'undefined') {
            localStorage.setItem("employeeCode", employeeCode)
          }
        } else {
          updateState({ error: "لم يتم العثور على بيانات الموظف", loading: false })
          setTimeout(() => router.push("/login"), 2000)
        }
      },
      (e) => {
        console.error("[Forum] Error loading employee:", e)
        updateState({ error: "خطأ في الاتصال بقاعدة البيانات", loading: false })
      },
    )

    return () => unsubscribe()
  }, [employeeCode, router, updateState])

  // useEffect لجلب الشهادات
  useEffect(() => {
    const testimonialsRef = collection(db, "testimonials")
    const q = query(testimonialsRef, orderBy("createdAt", "desc"))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const testimonialsData: Testimonial[] = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        } as Testimonial))
        setTestimonials(testimonialsData)
      },
      (e) => {
        console.error("[Forum] Error loading testimonials:", e)
      },
    )

    return () => unsubscribe()
  }, [])

  // useEffect لجلب المنشورات
  useEffect(() => {
    const postsRef = collection(db, "forumPosts")
    const q = query(postsRef, orderBy("createdAt", "desc"))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const postsData: Post[] = snapshot.docs.map((doc) => {
          const data = doc.data()
          return {
            id: doc.id,
            employeeId: data.employeeId,
            employeeCode: data.employeeCode,
            employeeName: data.employeeName,
            profileImage: data.profileImage,
            department: data.department,
            content: data.content,
            likes: data.likes || [],
            likeCount: (data.likes || []).length,
            comments: data.comments || [],
            commentCount: (data.comments || []).length,
            shares: data.shares || 0,
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          } as Post
        })
        setPosts(postsData)
      },
      (e) => {
        console.error("[Forum] Error loading posts:", e)
        toast({
          title: "خطأ",
          description: "فشل تحميل المنشورات",
          variant: "destructive",
        })
      },
    )

    return () => unsubscribe()
  }, [toast])

  // منطق تصفية المنشورات
  const filteredPosts = useMemo(() => {
    if (selectedEmployee) {
      return posts.filter((p) => p.employeeId === selectedEmployee.id)
    }
    return posts
  }, [posts, selectedEmployee])

  // جلب بيانات المعجبين (Lazy Load)
  const fetchLikersData = useCallback(async (postId: string, likerIds: string[]) => {
    if (likersData[postId] || likerIds.length === 0) return

    try {
      const employeesRef = collection(db, "employees")
      const q = query(employeesRef, where("__name__", "in", likerIds))
      const snapshot = await getDocs(q)
      
      const fetchedLikers: Employee[] = snapshot.docs.map((doc) => {
          const data = doc.data()
          return {
            id: doc.id,
            fullName: data.fullName,
            employeeCode: data.employeeCode,
            profileImage: data.profileImage,
            department: data.department,
          } as Employee
      })

      updateState({ likersData: { ...likersData, [postId]: fetchedLikers } })
    } catch (error) {
      console.error("[Forum] Error fetching likers:", error)
      toast({
        title: "خطأ",
        description: "فشل جلب بيانات المعجبين",
        variant: "destructive",
      })
    }
  }, [likersData, updateState, toast])

  // useEffect لجلب بيانات المعجبين عند فتح النافذة فقط
  useEffect(() => {
    if (showLikers) {
        const post = posts.find(p => p.id === showLikers)
        if (post && post.likes.length > 0) {
          fetchLikersData(post.id, post.likes)
        }
    }
  }, [showLikers, posts, fetchLikersData])

  // دالة التعامل مع إنشاء منشور
  const handleCreatePost = useCallback(async () => {
    if (!postContent.trim() || !currentEmployee) {
      toast({ title: "تنبيه", description: "يرجى إدخال محتوى المنشور", variant: "destructive" })
      return
    }

    try {
      updateState({ isSubmitting: true })
      await addDoc(collection(db, "forumPosts"), {
        employeeId: currentEmployee.id,
        employeeCode: currentEmployee.employeeCode, 
        employeeName: currentEmployee.fullName,
        profileImage: currentEmployee.profileImage,
        department: currentEmployee.department,
        content: postContent,
        likes: [],
        comments: [],
        shares: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      })

      updateState({ postContent: "" })
      toast({ title: "نجاح", description: "تم نشر المنشور بنجاح" })
    } catch (error) {
      console.error("[Forum] Error creating post:", error)
      toast({ title: "خطأ", description: "فشل نشر المنشور", variant: "destructive" })
    } finally {
      updateState({ isSubmitting: false })
    }
  }, [postContent, currentEmployee, updateState, toast])
  
  // دالة مساعدة لعرض بروفايل موظف
  const viewEmployeeProfile = useCallback((employee: Employee) => {
    router.push(`/employee/view?code=${employee.employeeCode}`)
    updateState({ searchQuery: "", searchResults: [] })
  }, [router, updateState])
  
  // دالة البحث
  const handleSearch = useCallback(async (query: string) => {
    updateState({ searchQuery: query })
    if (!query.trim()) {
      updateState({ searchResults: [] })
      return
    }

    try {
      const employeesRef = collection(db, "employees")
      const snapshot = await getDocs(employeesRef)
      const results: Employee[] = []
      const lowerCaseQuery = query.toLowerCase();

      snapshot.forEach((doc) => {
        const data = doc.data()
        if (
          data.fullName.toLowerCase().includes(lowerCaseQuery) || 
          data.employeeCode.includes(query)
        ) {
          results.push({
            id: doc.id,
            fullName: data.fullName,
            employeeCode: data.employeeCode,
            profileImage: data.profileImage,
            department: data.department,
          } as Employee)
        }
      })
      updateState({ searchResults: results })
    } catch (error) {
      console.error("[Forum] Error searching employees:", error)
    }
  }, [updateState])


  // ************************************************************
  // ************* الدوال المخصصة لتمريرها إلى PostCard *************
  // ************************************************************

  // ✅ استخدام useCallback لتجنب إعادة العرض غير الضرورية
  const handleSetCommentingPostId = useCallback((id: string | null) => {
    updateState({ commentingPostId: id, commentContent: "" })
  }, [updateState])

  const handleSetCommentContent = useCallback((content: string) => {
    updateState({ commentContent: content })
  }, [updateState])

  const handleSetIsSubmittingComment = useCallback((isSubmitting: boolean) => {
    updateState({ isSubmittingComment: isSubmitting })
  }, [updateState])

  const handleSetCopiedPostId = useCallback((id: string | null) => {
    updateState({ copiedPostId: id })
  }, [updateState])

  const handleSetShowLikers = useCallback((id: string | null) => {
    updateState({ showLikers: id })
  }, [updateState])


  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground font-medium">جاري تحميل الملتقى...</p>
        </div>
      </div>
    )
  }

  if (error || !currentEmployee) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-xl bg-white">
          <CardContent className="p-8 text-center">
            <p className="text-red-600 font-semibold mb-2 text-lg">خطأ في الدخول</p>
            <p className="text-xs text-muted-foreground">{error}</p>
            <Button onClick={() => router.push("/login")} className="w-full bg-blue-600 hover:bg-blue-700 mt-4">
              العودة لصفحة الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }
  
  const likersList = showLikers ? likersData[showLikers] || [] : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-12">
      {/* نافذة المعجبين */}
      <Dialog open={!!showLikers} onOpenChange={(open) => !open && updateState({ showLikers: null })}>
        {/* ... (بقية كود نافذة المعجبين) ... */}
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              المعجبون بالمنشور
            </DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto pr-1 custom-scrollbar">
            {likersList.length > 0 ? (
              <div className="space-y-3 mt-2">
                {likersList.map((liker) => (
                  <button
                    key={liker.id}
                    onClick={() => {
                      updateState({ showLikers: null })
                      viewEmployeeProfile(liker)
                    }}
                    className="w-full flex items-center gap-3 p-2 hover:bg-muted/50 rounded-lg transition-colors text-right"
                  >
                    <Avatar className="h-10 w-10 border-2 border-blue-200">
                      <AvatarImage src={liker.profileImage || "/placeholder.svg"} />
                      <AvatarFallback className="bg-blue-100 text-blue-700 text-xs font-bold">
                        {getInitials(liker.fullName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{liker.fullName}</p>
                      <p className="text-xs text-muted-foreground truncate">{liker.department}</p>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">لا يوجد إعجابات حتى الآن</div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* شريط التنقل العلوي (Header) */}
      <div className="sticky top-0 z-50 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        {/* ... (بقية كود شريط التنقل) ... */}
        <div className="container mx-auto max-w-4xl px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border-2 border-blue-400 shadow-md">
                <AvatarImage src={currentEmployee.profileImage || "/placeholder.svg"} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white font-bold">
                  {getInitials(currentEmployee.fullName)}
                </AvatarFallback>
              </Avatar>
              <div className="hidden sm:block">
                <p className="font-semibold text-foreground text-sm">{currentEmployee.fullName}</p>
                <p className="text-xs text-muted-foreground">{currentEmployee.department}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                onClick={() => {
                  if (typeof window !== 'undefined') localStorage.removeItem("employeeCode")
                  router.push("/login")
                }}
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-red-600 transition-colors gap-1"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-xs hidden sm:inline">خروج</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* محتوى الملتقى */}
      <div className="container mx-auto max-w-4xl px-4 py-8">
        
        {/* عنوان الصفحة والعودة للبروفايل */}
        {/* ... (بقية كود العنوان) ... */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
                الملتقى الذاتي
              </h1>
              <p className="text-muted-foreground text-lg">تواصل وشارك أفكارك وخبراتك مع زملائك في العمل</p>
            </div>
            <Button
              variant="outline"
              onClick={() => router.push(`/employee/profile?code=${employeeCode}`)}
              className="gap-2 shadow-lg hover:shadow-xl transition-all hover:bg-blue-50 hidden md:flex"
            >
              <ArrowLeft className="w-4 h-4" />
              العودة للبروفايل
            </Button>
          </div>
        </div>
        
        {/* شريط البحث عن موظف */}
        {/* ... (بقية كود البحث) ... */}
        <div className="mb-8 animate-fade-in">
          <div className="relative z-[100]">
            <Search className="absolute right-4 top-4 w-5 h-5 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="ابحث عن موظف..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-4 pr-12 bg-white shadow-lg border-0 focus:shadow-xl transition-all h-12 rounded-lg text-base"
            />

            {searchResults.length > 0 && (
              <div className="absolute top-full right-0 left-0 mt-2 bg-white/95 backdrop-blur-lg border border-white/20 rounded-xl shadow-2xl z-[100] max-h-80 overflow-y-auto">
                {searchResults.map((emp) => (
                  <button
                    key={emp.id}
                    onClick={() => {
                      viewEmployeeProfile(emp)
                      updateState({ searchQuery: "", searchResults: [], selectedEmployee: emp })
                    }}
                    className="w-full px-4 py-3 text-right hover:bg-gradient-to-r hover:from-blue-50 to-purple-50 flex items-center gap-4 border-b border-white/10 last:border-b-0 transition-all"
                  >
                    <Avatar className="h-12 w-12 border-2 border-blue-200 shadow-md flex-shrink-0">
                      <AvatarImage src={emp.profileImage || "/placeholder.svg"} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-xl font-bold">
                        {getInitials(emp.fullName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-right">
                      <p className="font-semibold text-foreground">{emp.fullName}</p>
                      <p className="text-muted-foreground text-sm">{emp.department}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* عرض الموظف المختار للتصفية */}
        {/* ... (بقية كود تصفية الموظف) ... */}
        {selectedEmployee && (
          <Card className="mb-8 border-0 shadow-xl bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 animate-slide-in">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12 border-2 border-white shadow-md flex-shrink-0">
                    <AvatarImage src={selectedEmployee.profileImage || "/placeholder.svg"} />
                    <AvatarFallback className="bg-white/20 text-white text-xl font-bold">
                      {getInitials(selectedEmployee.fullName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-white">
                    <p className="font-semibold text-lg">منشورات {selectedEmployee.fullName}</p>
                    <p className="text-sm opacity-90">{selectedEmployee.department}</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => updateState({ selectedEmployee: null, searchResults: [] })}
                  className="bg-white text-blue-600 hover:bg-gray-100 transition-colors gap-2"
                >
                  <X className="w-4 h-4" />
                  إلغاء التصفية
                </Button>
            </CardContent>
          </Card>
        )}

        {/* قسم إنشاء منشور جديد */}
        {/* ... (بقية كود إنشاء منشور) ... */}
        {!selectedEmployee && (
          <Card className="mb-8 border-0 shadow-xl animate-fade-in bg-white/90 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <Avatar className="h-10 w-10 border-2 border-gray-200 shadow-sm flex-shrink-0">
                  <AvatarImage src={currentEmployee.profileImage || "/placeholder.svg"} />
                  <AvatarFallback className="bg-gray-200 text-gray-700 font-bold text-sm">
                    {getInitials(currentEmployee.fullName)}
                  </AvatarFallback>
                </Avatar>
                <Textarea
                  placeholder={`ما الذي تفكر فيه يا ${currentEmployee.fullName.split(' ')[0]}؟`}
                  value={postContent}
                  onChange={(e) => updateState({ postContent: e.target.value })}
                  className="min-h-[80px] resize-none flex-1 border-gray-200 focus:ring-blue-500"
                  disabled={isSubmitting}
                />
              </div>
              <div className="flex justify-end">
                <Button
                  onClick={handleCreatePost}
                  disabled={isSubmitting || !postContent.trim()}
                  className="bg-blue-600 hover:bg-blue-700 transition-colors gap-2"
                >
                  {isSubmitting ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <Share2 className="w-4 h-4" />
                  )}
                  نشر المنشور
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* قسم الشهادات */}
        <TestimonialsSection testimonials={testimonials} />
        
        {/* قائمة المنشورات */}
        <div className="space-y-8 mt-8">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post) => (
              <PostCard 
                key={post.id}
                post={post}
                currentEmployee={currentEmployee!}
                
                // ✅ استخدام الدوال المصححة بـ useCallback
                setCommentingPostId={handleSetCommentingPostId}
                commentingPostId={commentingPostId}
                commentContent={commentContent}
                setCommentContent={handleSetCommentContent}
                isSubmittingComment={isSubmittingComment}
                setIsSubmittingComment={handleSetIsSubmittingComment}
                copiedPostId={copiedPostId}
                setCopiedPostId={handleSetCopiedPostId}
                setShowLikers={handleSetShowLikers}
              />
            ))
          ) : (
            <Card className="shadow-lg p-12 text-center text-muted-foreground bg-white/80">
              {selectedEmployee ? (
                <p>لم يقم {selectedEmployee.fullName} بنشر أي شيء حتى الآن.</p>
              ) : (
                <p>لا يوجد منشورات في الملتقى حتى الآن. كن أول من ينشر!</p>
              )}
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}