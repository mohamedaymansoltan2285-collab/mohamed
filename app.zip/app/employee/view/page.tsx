"use client"

import { useEffect, useState, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
// الافتراض: هذه المكونات/الخدمات متاحة في بيئة Next.js الخاصة بك
import { useAuth } from "@/components/auth-context" 
import { db } from "@/lib/firebase" 
import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore"
// المكونات الافتراضية للواجهة (Shadcn/ui أو ما شابه)
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card" 
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Briefcase, Mail, Phone, Calendar, MapPin, User, ArrowLeft, Heart, Layers, Loader2 } from "lucide-react"

// ==================================================================
// **الإصلاح الجذري للأنواع المفقودة**
// بما أن النوع المستورد 'Employee' كان يفتقد 'averageRating'، نقوم بتعريفه بالكامل هنا.
// يرجى نقل هذا التعريف لاحقاً إلى ملف '@/types/employee' وتعديل الاستيراد لجعله حلاً دائماً.

interface Employee {
    employeeCode: string;
    fullName: string;
    jobTitle: string;
    department: string;
    status: 'active' | 'inactive' | string;
    joinDate: string; // صيغة تاريخ ISO
    email: string;
    phone: string;
    address?: string | null;
    age?: number | null;
    gender?: string | null;
    maritalStatus?: string | null;
    role: 'admin' | 'user' | string;
    profileImage?: string | null;
    // **الإصلاح 1: إضافة الخاصية المفقودة التي تسببت في الخطأ**
    averageRating?: number; // يفترض أن تكون بين 0 و 1
}

// تعريف واجهة البيانات الشخصية الموسعة
interface PersonalData {
    vacationPreferences?: string
    colleagues?: string
    suggestions?: string
    skills?: string
    interests?: string
    specialization?: string
    favoriteVacationDay?: string
    favoritePerson?: string
    favoriteFriends?: string
    personalNotes?: string
    preferredDepartment?: string
    favoriteChallengeType?: string
    educationLevel?: string
    favoriteQuote?: string
}

// **الإصلاح 2: تعريف واجهة سياق المصادقة بشكل واضح**
interface AuthContextType {
    currentUser?: { employeeCode?: string } | null;
}
// ==================================================================


// تعريف مخطط الألوان والرموز للبيانات الشخصية الإضافية
const PERSONAL_DATA_MAPPING: Record<
    string,
    { label: string; icon: string; bgColor: string; textColor: string; borderColor: string }
> = {
    skills: {
        label: "المهارات",
        icon: "🎯",
        bgColor: "bg-blue-50",
        textColor: "text-blue-900",
        borderColor: "border-blue-200",
    },
    specialization: {
        label: "التخصص",
        icon: "📚",
        bgColor: "bg-purple-50",
        textColor: "text-purple-900",
        borderColor: "border-purple-200",
    },
    interests: {
        label: "الاهتمامات",
        icon: "💡",
        bgColor: "bg-amber-50",
        textColor: "text-amber-900",
        borderColor: "border-amber-200",
    },
    vacationPreferences: {
        label: "تفضيلات الإجازة",
        icon: "🏖️",
        bgColor: "bg-orange-50",
        textColor: "text-orange-900",
        borderColor: "border-orange-200",
    },
    colleagues: {
        label: "الزملاء المفضلين",
        icon: "👥",
        bgColor: "bg-red-50",
        textColor: "text-red-900",
        borderColor: "border-red-200",
    },
    suggestions: {
        label: "الملاحظات والاقتراحات",
        icon: "💭",
        bgColor: "bg-teal-50",
        textColor: "text-teal-900",
        borderColor: "border-teal-200",
    },
    favoriteVacationDay: {
        label: "اليوم المفضل للأجازة",
        icon: "📅",
        bgColor: "bg-indigo-50",
        textColor: "text-indigo-900",
        borderColor: "border-indigo-200",
    },
    favoritePerson: {
        label: "الشخص المفضل في العمل",
        icon: "😊",
        bgColor: "bg-pink-50",
        textColor: "text-pink-900",
        borderColor: "border-pink-200",
    },
    favoriteFriends: {
        label: "الأصدقاء المفضلين",
        icon: "🤝",
        bgColor: "bg-green-50",
        textColor: "text-green-900",
        borderColor: "border-green-200",
    },
    personalNotes: {
        label: "الملاحظات الشخصية",
        icon: "📝",
        bgColor: "bg-cyan-50",
        textColor: "text-cyan-900",
        borderColor: "border-cyan-200",
    },
    preferredDepartment: {
        label: "القسم المفضل",
        icon: "🏢",
        bgColor: "bg-slate-50",
        textColor: "text-slate-900",
        borderColor: "border-slate-200",
    },
    favoriteChallengeType: {
        label: "نوع التحدي المفضل",
        icon: "🎯",
        bgColor: "bg-orange-50",
        textColor: "text-orange-900",
        borderColor: "border-orange-200",
    },
    educationLevel: {
        label: "المستوى التعليمي",
        icon: "🎓",
        bgColor: "bg-indigo-50",
        textColor: "text-indigo-900",
        borderColor: "border-indigo-200",
    },
    favoriteQuote: {
        label: "عبارة مفضلة",
        icon: "✨",
        bgColor: "bg-rose-50",
        textColor: "text-rose-900",
        borderColor: "border-rose-200",
    },
}


function EmployeeViewContent() {
    const searchParams = useSearchParams()
    const router = useRouter()
    
    // استخدام تأكيد النوع الجديد
    const { currentUser } = useAuth() as AuthContextType
    
    const [employee, setEmployee] = useState<Employee | null>(null)
    const [personalData, setPersonalData] = useState<PersonalData | null>(null)
    const [loading, setLoading] = useState(true)

    // دالة لحساب عدد الأيام بين تاريخ الانضمام والتاريخ الحالي
    const calculateWorkDays = (joinDateString: string) => {
        try {
            const joinDate = new Date(joinDateString);
            const today = new Date();
            if (isNaN(joinDate.getTime())) return 0;
            return Math.floor((today.getTime() - joinDate.getTime()) / (1000 * 60 * 60 * 24));
        } catch {
            return 0;
        }
    }

    // دالة لحساب عدد الأشهر بين تاريخ الانضمام والتاريخ الحالي
    const calculateWorkMonths = (joinDateString: string) => {
        try {
            const joinDate = new Date(joinDateString);
            const today = new Date();
            if (isNaN(joinDate.getTime())) return 0;
            // حساب فرق الأشهر بدقة
            const years = today.getFullYear() - joinDate.getFullYear();
            const months = today.getMonth() - joinDate.getMonth();
            const totalMonths = years * 12 + months;
            return totalMonths >= 0 ? totalMonths : 0;
        } catch {
            return 0;
        }
    }

    // تأثير لجلب بيانات الموظف والبيانات الشخصية
    useEffect(() => {
        // يجب أن يتم التحقق من وجود db قبل الاستدعاء
        if (!db) {
            console.error("Firebase db is not initialized. Cannot fetch data.");
            setLoading(false);
            return;
        }

        const fetchEmployee = async () => {
            setLoading(true); // إعادة تعيين حالة التحميل
            
            try {
                let code = searchParams.get("code")

                // محاولة استخدام الكود من سياق المصادقة إذا لم يكن موجوداً في الـ URL
                if (!code && currentUser?.employeeCode) {
                    code = currentUser.employeeCode
                    console.log("[v1] Using code from auth context:", code)
                }

                if (!code) {
                    console.log("[v1] No code found, redirecting to forum")
                    router.push("/employee/forum")
                    return
                }

                console.log("[v1] Fetching employee with code:", code)
                // البحث عن الموظف باستخدام رمز الموظف
                const q = query(collection(db, "employees"), where("employeeCode", "==", code))
                const snapshot = await getDocs(q)

                if (!snapshot.empty) {
                    const docData = snapshot.docs[0]
                    // التأكد من أن البيانات متوافقة مع النوع Employee
                    // تم التأكيد على النوع هنا لاستخدام التعريف المحلي الجديد
                    const data = docData.data() as Employee 
                    
                    // تأكيد وجود employeeCode للحالات التي قد تكون فيها البيانات غير مكتملة
                    if (!data.employeeCode) {
                        data.employeeCode = code;
                    }
                    
                    setEmployee(data)

                    // جلب البيانات الشخصية باستخدام معرف المستند (Employee Document ID)
                    try {
                        const personalDataRef = doc(db, "personalData", docData.id)
                        const personalDataSnap = await getDoc(personalDataRef)
                        if (personalDataSnap.exists()) {
                            setPersonalData(personalDataSnap.data() as PersonalData)
                        } else {
                            setPersonalData({}); // تعيين كائن فارغ إذا لم يتم العثور على بيانات شخصية
                        }
                    } catch (error) {
                        console.error("[v1] Error fetching personal data:", error)
                        setPersonalData({}); // تعيين كائن فارغ في حالة حدوث خطأ
                    }
                } else {
                    console.log("[v1] No employee found with code:", code)
                    router.push("/employee/forum")
                }
            } catch (error) {
                console.error("[v1] Critical Error fetching employee or data:", error)
            } finally {
                setLoading(false)
            }
        }

        fetchEmployee()
    }, [searchParams, router, currentUser]) // الحفاظ على التبعيات

    // دالة للحصول على معلومات القسم والألوان المرتبطة به
    const getDepartmentInfo = () => {
        // تم تحديث مخطط الألوان لاستخدام تدرجات Tailwind أكثر حيوية
        const deptMap: Record<string, { color: string; icon: string; label: string }> = {
            "تكنولوجيا المعلومات - الفرقة الأولى": { color: "from-blue-500 to-cyan-500", icon: "💻", label: "تكنولوجيا المعلومات - الفرقة الأولى" },
            "تكنولوجيا المعلومات - الفرقة الثانية": { color: "from-blue-600 to-cyan-600", icon: "💻", label: "تكنولوجيا المعلومات - الفرقة الثانية" },
            "تكنولوجيا المعلومات - الفرقة الثالثة": { color: "from-blue-700 to-cyan-700", icon: "💻", label: "تكنولوجيا المعلومات - الفرقة الثالثة" },
            "تكنولوجيا المعلومات - الفرقة الرابعة": { color: "from-blue-800 to-cyan-800", icon: "💻", label: "تكنولوجيا المعلومات - الفرقة الرابعة" },
            "ميكاترونيكس - الفرقة الأولى": { color: "from-purple-500 to-violet-500", icon: "🤖", label: "ميكاترونيكس - الفرقة الأولى" },
            "ميكاترونيكس - الفرقة الثانية": { color: "from-purple-600 to-violet-600", icon: "🤖", label: "ميكاترونيكس - الفرقة الثانية" },
            "ميكاترونيكس - الفرقة الثالثة": { color: "from-purple-700 to-violet-700", icon: "🤖", label: "ميكاترونيكس - الفرقة الثالثة" },
            "ميكاترونيكس - الفرقة الرابعة": { color: "from-purple-800 to-violet-800", icon: "🤖", label: "ميكاترونيكس - الفرقة الرابعة" },
            "أوتوترونيكس - الفرقة الأولى": { color: "from-orange-500 to-red-500", icon: "🚗", label: "أوتوترونيكس - الفرقة الأولى" },
            "أوتوترونيكس - الفرقة الثانية": { color: "from-orange-600 to-red-600", icon: "🚗", label: "أوتوترونيكس - الفرقة الثانية" },
            "أوتوترونيكس - الفرقة الثالثة": { color: "from-orange-700 to-red-700", icon: "🚗", label: "أوتوترونيكس - الفرقة الثالثة" },
            "أوتوترونيكس - الفرقة الرابعة": { color: "from-orange-800 to-red-800", icon: "🚗", label: "أوتوترونيكس - الفرقة الرابعة" },
        }
        return deptMap[employee?.department || ""] || { color: "from-gray-400 to-gray-500", icon: "🎓", label: "إدارة غير محددة" }
    }

    // دالة للحصول على حقول البيانات الشخصية التي تم ملؤها فقط
    const getFilledPersonalData = () => {
        if (!personalData) return {}
        const filled: Record<string, string> = {}

        Object.entries(personalData).forEach(([key, value]) => {
            // التحقق من أن القيمة موجودة، وهي سلسلة نصية، وليست فارغة بعد إزالة المسافات، ولها تعيين في الخريطة
            if (
                value && 
                typeof value === "string" && 
                value.trim() && 
                PERSONAL_DATA_MAPPING[key as keyof PersonalData]
            ) {
                filled[key] = value
            }
        })

        return filled
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-muted/40" dir="rtl">
                <div className="text-center p-8 rounded-xl bg-card shadow-2xl">
                    {/* أيقونة تحميل دوارة محسنة */}
                    <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
                    <p className="text-lg font-semibold text-foreground">جاري تحميل البيانات...</p>
                    <p className="text-sm text-muted-foreground mt-1">يُرجى الانتظار قليلاً</p>
                </div>
            </div>
        )
    }

    if (!employee) {
        // في حالة فشل التحميل وعدم وجود بيانات للموظف
        return (
            <div className="flex items-center justify-center min-h-screen bg-red-50" dir="rtl">
                <div className="text-center p-8 rounded-xl bg-card shadow-2xl border border-red-300">
                    <h2 className="text-xl font-bold text-red-600 mb-4">خطأ في جلب البيانات</h2>
                    <p className="text-muted-foreground mb-6">لم يتم العثور على بيانات الموظف أو حدث خطأ أثناء التحميل.</p>
                    <Button onClick={() => router.push("/employee/forum")} className="bg-red-500 hover:bg-red-600 text-white">
                        العودة إلى الملتقى
                    </Button>
                </div>
            </div>
        )
    }

    const deptInfo = getDepartmentInfo()
    // حساب الأحرف الأولى من اسم الموظف
    const initials = employee.fullName
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)

    const filledData = getFilledPersonalData()
    const fieldMapping = PERSONAL_DATA_MAPPING

    // حساب التقييم المقرب للنجوم
    // **الإصلاح 3: تم إصلاح خطأ Type Script الآن بعد تعديل واجهة Employee**
    const rating = employee.averageRating ?? 0;
    // تحويل التقييم (0-1) إلى مقياس من 5 نجوم وتقريبه
    const roundedStars = Math.round(rating * 5);


    return (
        <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 pb-16" dir="rtl">
            {/* رأس الصفحة اللاصق (Sticky Header) */}
            <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 shadow-lg">
                <div className="container mx-auto px-4 py-4 max-w-4xl">
                    <div className="flex items-center justify-between">
                        {/* زر العودة للخلف */}
                        <Button onClick={() => router.back()} variant="ghost" size="sm" className="gap-2 text-foreground/80 hover:text-foreground">
                            <ArrowLeft className="w-4 h-4" />
                            عودة
                        </Button>
                        <h1 className="text-xl font-bold text-foreground truncate">ملف الموظف: {employee.fullName}</h1>
                        <div className="w-16" /> {/* للحفاظ على التوازن في التخطيط */}
                    </div>
                </div>
            </header>

            {/* المحتوى الرئيسي */}
            <main className="container mx-auto px-4 py-8 max-w-4xl">
                {/* قسم البطل (Hero Section) */}
                <div
                    className={`rounded-3xl bg-gradient-to-r ${deptInfo.color} text-white shadow-3xl overflow-hidden mb-10 transform transition-all duration-500 hover:scale-[1.01]`}
                >
                    <div className="p-8 md:p-12">
                        <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
                            {/* صورة الملف الشخصي / الأحرف الأولى */}
                            <div className="flex-shrink-0">
                                <div className="relative">
                                    <div className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white/40 bg-white/10 flex items-center justify-center shadow-2xl ring-4 ring-white/20">
                                        {employee.profileImage ? (
                                            <img
                                                src={employee.profileImage || "/placeholder.svg"}
                                                alt={employee.fullName}
                                                className="w-full h-full rounded-full object-cover"
                                            />
                                        ) : (
                                            <span className="text-5xl md:text-6xl font-extrabold text-white/90">{initials}</span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* معلومات البطل */}
                            <div className="flex-1">
                                <div className="text-4xl md:text-5xl font-bold mb-3">{deptInfo.icon}</div>
                                <h1 className="text-3xl md:text-4xl font-bold mb-2 text-balance">{employee.fullName}</h1>
                                <p className="text-white/90 mb-4 font-semibold text-lg">{employee.jobTitle || 'منصب غير محدد'}</p>
                                <div className="flex flex-wrap gap-3">
                                    {/* شارة القسم */}
                                    <Badge className="bg-white/20 text-white border-white/30 text-sm py-1 px-3 shadow-md backdrop-blur-sm">{deptInfo.label}</Badge>
                                    {/* شارة الحالة */}
                                    <Badge
                                        className={
                                            employee.status === "active"
                                                ? "bg-green-400/20 text-white border-green-300/30 text-sm py-1 px-3 shadow-md backdrop-blur-sm"
                                                : "bg-red-400/20 text-white border-red-300/30 text-sm py-1 px-3 shadow-md backdrop-blur-sm"
                                        }
                                    >
                                        {employee.status === "active" ? "نشط حالياً" : "غير نشط"}
                                    </Badge>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* بطاقات الإحصائيات (Statistics Cards) */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                    {/* أيام العمل */}
                    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white rounded-xl transform hover:-translate-y-1">
                        <CardContent className="p-6 text-center">
                            <div className="text-3xl font-extrabold text-blue-600 mb-2">
                                {calculateWorkDays(employee.joinDate)}
                            </div>
                            <p className="text-xs md:text-sm text-muted-foreground font-medium">يوم عمل</p>
                        </CardContent>
                    </Card>

                    {/* الأشهر */}
                    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white rounded-xl transform hover:-translate-y-1">
                        <CardContent className="p-6 text-center">
                            <div className="text-3xl font-extrabold text-purple-600 mb-2">
                                {calculateWorkMonths(employee.joinDate)}
                            </div>
                            <p className="text-xs md:text-sm text-muted-foreground font-medium">شهر في العمل</p>
                        </CardContent>
                    </Card>

                    {/* العمر */}
                    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white rounded-xl transform hover:-translate-y-1">
                        <CardContent className="p-6 text-center">
                            <div className="text-3xl font-extrabold text-pink-600 mb-2">{employee.age || "-"}</div>
                            <p className="text-xs md:text-sm text-muted-foreground font-medium">سنة عمر</p>
                        </CardContent>
                    </Card>

                    {/* التقييم */}
                    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white rounded-xl transform hover:-translate-y-1">
                        <CardContent className="p-6 text-center">
                            <div className="text-3xl font-extrabold text-amber-600 mb-2">
                                {rating !== undefined ? `${(rating * 100).toFixed(0)}%` : 'N/A'}
                            </div>
                            <p className="text-xs md:text-sm text-muted-foreground font-medium">تقييم الأداء</p>
                        </CardContent>
                    </Card>
                </div>

                {/* الشبكة الرئيسية للمعلومات */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                    {/* العمود الأيمن - المعلومات الرئيسية والإضافية */}
                    <div className="lg:col-span-2 space-y-6">

                        {/* بطاقة معلومات الاتصال */}
                        <Card className="shadow-xl border-0 rounded-xl">
                            <CardHeader className="bg-gradient-to-r from-teal-50 to-green-50 border-b rounded-t-xl">
                                <CardTitle className="flex items-center gap-2 text-lg text-teal-700 font-bold">
                                    <Phone className="w-5 h-5" />
                                    بيانات الاتصال
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {/* البريد الإلكتروني */}
                                    <div className="p-2 border rounded-lg bg-gray-50">
                                        <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1 mb-1">
                                            <Mail className="w-3 h-3 text-teal-500" />
                                            البريد الإلكتروني
                                        </label>
                                        <p className="text-sm font-medium text-foreground break-all">{employee.email}</p>
                                    </div>

                                    {/* رقم الهاتف */}
                                    <div className="p-2 border rounded-lg bg-gray-50">
                                        <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1 mb-1">
                                            <Phone className="w-3 h-3 text-teal-500" />
                                            رقم الهاتف
                                        </label>
                                        <p className="text-sm font-medium text-foreground">{employee.phone}</p>
                                    </div>

                                    {/* العنوان */}
                                    {employee.address && (
                                        <div className="md:col-span-2 p-2 border rounded-lg bg-gray-50">
                                            <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1 mb-1">
                                                <MapPin className="w-3 h-3 text-teal-500" />
                                                العنوان
                                            </label>
                                            <p className="text-sm text-foreground">{employee.address}</p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>


                        {/* بطاقة البيانات الوظيفية والشخصية الأساسية */}
                        <Card className="shadow-xl border-0 rounded-xl">
                            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b rounded-t-xl">
                                <CardTitle className="flex items-center gap-2 text-lg text-blue-700 font-bold">
                                    <Briefcase className="w-5 h-5" />
                                    البيانات الوظيفية والشخصية
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {/* القسم */}
                                    <div className="p-2 border rounded-lg bg-gray-50">
                                        <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1 mb-1">
                                            <Layers className="w-3 h-3 text-blue-500" />
                                            القسم
                                        </label>
                                        <p className="text-sm font-medium text-foreground">{employee.department}</p>
                                    </div>

                                    {/* تاريخ الانضمام */}
                                    <div className="p-2 border rounded-lg bg-gray-50">
                                        <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1 mb-1">
                                            <Calendar className="w-3 h-3 text-blue-500" />
                                            تاريخ الانضمام
                                        </label>
                                        <p className="text-sm font-medium text-foreground">
                                            {new Date(employee.joinDate).toLocaleDateString("ar-SA", { year: 'numeric', month: 'long', day: 'numeric' })}
                                        </p>
                                    </div>

                                    {/* العمر */}
                                    {employee.age && (
                                        <div className="p-2 border rounded-lg bg-gray-50">
                                            <label className="text-xs font-semibold text-muted-foreground uppercase block mb-1">
                                                العمر
                                            </label>
                                            <p className="text-sm font-medium text-foreground">{employee.age} سنة</p>
                                        </div>
                                    )}

                                    {/* النوع (الجنس) */}
                                    {employee.gender && (
                                        <div className="p-2 border rounded-lg bg-gray-50">
                                            <label className="text-xs font-semibold text-muted-foreground uppercase block mb-1">
                                                النوع
                                            </label>
                                            <p className="text-sm font-medium text-foreground">
                                                {employee.gender === "ذكر" || employee.gender === "male" ? "ذكر" : "أنثى"}
                                            </p>
                                        </div>
                                    )}

                                    {/* الحالة الاجتماعية */}
                                    {employee.maritalStatus && (
                                        <div className="p-2 border rounded-lg bg-gray-50">
                                            <label className="text-xs font-semibold text-muted-foreground uppercase block mb-1">
                                                الحالة الاجتماعية
                                            </label>
                                            <p className="text-sm font-medium text-foreground">{employee.maritalStatus}</p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* بطاقة البيانات الشخصية الإضافية (هوايات وتفضيلات) */}
                        {Object.keys(filledData).length > 0 && (
                            <div className="space-y-4 pt-4">
                                <h2 className="text-xl font-bold flex items-center gap-2 border-b pb-2 text-pink-700">
                                    <Heart className="w-5 h-5" />
                                    اهتمامات وتفضيلات شخصية
                                </h2>

                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {Object.entries(filledData).map(([key, value]) => {
                                        const field = fieldMapping[key as keyof PersonalData]
                                        if (!field) return null

                                        return (
                                            <Card
                                                key={key}
                                                className="border-l-4 shadow-lg transition-all duration-300 overflow-hidden hover:scale-[1.03] rounded-xl"
                                            >
                                                <CardContent className={`p-4 ${field.bgColor} border-l-4 ${field.borderColor} h-full flex flex-col justify-start`}>
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <span className="text-xl">{field.icon}</span>
                                                        <h3 className={`font-bold text-sm ${field.textColor}`}>{field.label}</h3>
                                                    </div>
                                                    <p className={`text-sm leading-relaxed ${field.textColor}/90 font-medium`}>{value}</p>
                                                </CardContent>
                                            </Card>
                                        )
                                    })}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* العمود الأيسر - الإحصائيات والحالة (Sticky) */}
                    <div className="space-y-6">
                        {/* تقييم الأداء */}
                        <Card className="shadow-xl border-0 rounded-xl sticky top-[5.5rem]">
                            <CardHeader className="bg-gradient-to-r from-amber-50 to-orange-50 border-b rounded-t-xl">
                                <CardTitle className="text-lg text-amber-700 font-bold">التقييم الإجمالي</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6 text-center">
                                {/* دائرة التقييم */}
                                <div className="inline-flex items-center justify-center w-28 h-28 rounded-full bg-gradient-to-br from-amber-100 to-orange-100 mb-4 shadow-inner border-4 border-amber-300/50">
                                    <div className="text-4xl font-extrabold text-amber-700">
                                        {rating !== undefined ? `${(rating * 100).toFixed(0)}%` : 'N/A'}
                                    </div>
                                </div>
                                {/* النجوم */}
                                <div className="flex items-center justify-center gap-1 mb-4">
                                    {[...Array(5)].map((_, i) => (
                                        <span
                                            key={i}
                                            className={
                                                i < roundedStars ? "text-yellow-500 text-3xl transition-transform duration-200 hover:scale-110" : "text-gray-200 text-3xl"
                                            }
                                        >
                                            ★
                                        </span>
                                    ))}
                                </div>
                                {/* وصف التقييم (يمكن جعله ديناميكيًا بناءً على roundedStars) */}
                                <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200 w-full justify-center py-2 font-semibold text-base">
                                    {roundedStars >= 4 ? "أداء ممتاز ومتميز" : roundedStars >= 3 ? "أداء جيد جدًا" : "يحتاج إلى تطوير"}
                                </Badge>
                            </CardContent>
                        </Card>

                        {/* حالة الحساب */}
                        <Card className="shadow-xl border-0 rounded-xl">
                            <CardHeader className="bg-gradient-to-r from-indigo-50 to-blue-50 border-b rounded-t-xl">
                                <CardTitle className="text-lg text-indigo-700 font-bold">حالة الحساب والصلاحيات</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6 space-y-4">
                                {/* حالة الموظف */}
                                <div className="p-3 bg-muted rounded-lg border border-gray-200">
                                    <p className="text-xs text-muted-foreground mb-2 font-semibold">الحالة الوظيفية</p>
                                    <Badge
                                        className={
                                            employee.status === "active"
                                                ? "bg-green-100 text-green-700 hover:bg-green-200 w-full justify-center font-bold text-sm"
                                                : "bg-red-100 text-red-700 hover:bg-red-200 w-full justify-center font-bold text-sm"
                                        }
                                    >
                                        {employee.status === "active" ? "موظف نشط حالياً" : "غير نشط أو مغادر"}
                                    </Badge>
                                </div>

                                {/* نوع الحساب */}
                                <div className="p-3 bg-muted rounded-lg border border-gray-200">
                                    <p className="text-xs text-muted-foreground mb-2 font-semibold">نوع الحساب (الصلاحية)</p>
                                    <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 w-full justify-center font-bold text-sm">
                                        {employee.role === "admin" ? "مسؤول (Admin) - وصول كامل" : "موظف عادي - وصول محدود"}
                                    </Badge>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* زر العودة في الأسفل */}
                <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12 mb-8">
                    <Button onClick={() => router.back()} variant="outline" size="lg" className="gap-2 text-lg px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all border-blue-500 text-blue-600 hover:bg-blue-50">
                        <ArrowLeft className="w-5 h-5" />
                        عودة إلى الملتقى
                    </Button>
                </div>
            </main>
        </div>
    )
}

// المكون الرئيسي مع معالجة Suspense
export default function EmployeeViewPage() {
    return (
        // Suspense هو ميزة Next.js رائعة للتعامل مع التحميل
        <Suspense
            fallback={
                <div className="flex items-center justify-center min-h-screen bg-muted/40" dir="rtl">
                    <div className="text-center p-8 rounded-xl bg-card shadow-2xl">
                        <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
                        <p className="text-lg font-semibold text-foreground">جاري تهيئة العرض...</p>
                    </div>
                </div>
            }
        >
            <EmployeeViewContent />
        </Suspense>
    )
}