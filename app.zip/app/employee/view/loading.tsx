export default function EmployeeViewLoading() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-border border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground">جاري تحميل البيانات...</p>
      </div>
    </div>
  )
}
