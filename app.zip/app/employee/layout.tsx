import type React from "react"
import EmployeeLayoutContent from "./layout-content"

export default function EmployeeLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <EmployeeLayoutContent>{children}</EmployeeLayoutContent>
}
