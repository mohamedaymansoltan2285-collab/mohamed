"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, getDocs, updateDoc, doc } from "firebase/firestore"
import type { Employee } from "@/types/employee"
import ModernEmployeeHeader from "@/components/modern-employee-header"
import ProfileImageUploader from "@/components/profile-image-uploader"
import EmployeeRatingsDisplay from "@/components/employee-ratings-display"
import PersonalDataSection from "@/components/personal-data-section"
import ModernStatsCards from "@/components/modern-stats-cards"
import StudentLecturesList from "@/components/student-lectures-list"
import StudentAttendanceStats from "@/components/student-attendance-stats"
import SendRequestModal from "@/components/send-request-modal"
import StudentRequestsSection from "@/components/student-requests-section"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText } from "lucide-react"
import { Briefcase, Mail, Phone, Calendar, MapPin, User, Shield, BookOpen } from "lucide-react"

export default function NewEmployeeProfilePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [employee, setEmployee] = useState<Employee | null>(null)
  const [loading, setLoading] = useState(true)
  const [employeeId, setEmployeeId] = useState<string>("")
  const [showRequestModal, setShowRequestModal] = useState(false)

  useEffect(() => {
    const fetchEmployee = async () => {
      const code = searchParams.get("code") || localStorage.getItem("employeeCode")

      if (!code) {
        router.push("/login")
        return
      }

      try {
        const q = query(collection(db, "employees"), where("employeeCode", "==", code))
        const snapshot = await getDocs(q)

        if (!snapshot.empty) {
          const docData = snapshot.docs[0]
          const data = docData.data() as Employee
          setEmployee(data)
          setEmployeeId(docData.id)
          localStorage.setItem("employeeCode", code)
        } else {
          router.push("/login")
        }
      } catch (error) {
        console.error("[v0] Error fetching employee:", error)
        router.push("/login")
      } finally {
        setLoading(false)
      }
    }

    fetchEmployee()
  }, [searchParams, router])

  const handleImageUpload = async (imageUrl: string) => {
    if (!employeeId) return

    try {
      const employeeRef = doc(db, "employees", employeeId)
      await updateDoc(employeeRef, { profileImage: imageUrl })
      setEmployee((prev) => (prev ? { ...prev, profileImage: imageUrl } : null))
    } catch (error) {
      console.error("[v0] Error updating profile image:", error)
      throw error
    }
  }

  const handleNavigateToForum = () => {
    window.location.href = `/employee/forum?code=${employee?.employeeCode}`
  }

  const handleNavigateToView = () => {
    window.location.href = `/employee/view?code=${employee?.employeeCode}`
  }

  const handleLogout = () => {
    localStorage.removeItem("employeeCode")
    router.push("/login")
  }

  const getDepartmentInfo = () => {
    const deptMap: Record<string, { color: string; icon: string; label: string }> = {
      "تكنولوجيا المعلومات - الفرقة الأولى": {
        color: "from-blue-500 to-cyan-500",
        icon: "💻",
        label: "تكنولوجيا المعلومات - الفرقة الأولى",
      },
      "تكنولوجيا المعلومات - الفرقة الثانية": {
        color: "from-blue-600 to-cyan-600",
        icon: "💻",
        label: "تكنولوجيا المعلومات - الفرقة الثانية",
      },
      "تكنولوجيا المعلومات - الفرقة الثالثة": {
        color: "from-blue-700 to-cyan-700",
        icon: "💻",
        label: "تكنولوجيا المعلومات - الفرقة الثالثة",
      },
      "تكنولوجيا المعلومات - الفرقة الرابعة": {
        color: "from-blue-800 to-cyan-800",
        icon: "💻",
        label: "تكنولوجيا المعلومات - الفرقة الرابعة",
      },
      "ميكاترونيكس - الفرقة الأولى": {
        color: "from-purple-500 to-violet-500",
        icon: "🤖",
        label: "ميكاترونيكس - الفرقة الأولى",
      },
      "ميكاترونيكس - الفرقة الثانية": {
        color: "from-purple-600 to-violet-600",
        icon: "🤖",
        label: "ميكاترونيكس - الفرقة الثانية",
      },
      "ميكاترونيكس - الفرقة الثالثة": {
        color: "from-purple-700 to-violet-700",
        icon: "🤖",
        label: "ميكاترونيكس - الفرقة الثالثة",
      },
      "ميكاترونيكس - الفرقة الرابعة": {
        color: "from-purple-800 to-violet-800",
        icon: "🤖",
        label: "ميكاترونيكس - الفرقة الرابعة",
      },
      "أوتوترونيكس - الفرقة الأولى": {
        color: "from-orange-500 to-red-500",
        icon: "🚗",
        label: "أوتوترونيكس - الفرقة الأولى",
      },
      "أوتوترونيكس - الفرقة الثانية": {
        color: "from-orange-600 to-red-600",
        icon: "🚗",
        label: "أوتوترونيكس - الفرقة الثانية",
      },
      "أوتوترونيكس - الفرقة الثالثة": {
        color: "from-orange-700 to-red-700",
        icon: "🚗",
        label: "أوتوترونيكس - الفرقة الثالثة",
      },
      "أوتوترونيكس - الفرقة الرابعة": {
        color: "from-orange-800 to-red-800",
        icon: "🚗",
        label: "أوتوترونيكس - الفرقة الرابعة",
      },
    }
    return deptMap[employee?.department || ""] || { color: "from-blue-500 to-cyan-500", icon: "🎓", label: "الإدارة" }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-border border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل البيانات...</p>
        </div>
      </div>
    )
  }

  if (!employee) {
    return null
  }

  const deptInfo = getDepartmentInfo()
  const initials = employee.fullName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  return (
    <div className="min-h-screen bg-background">
      {/* New Modern Header */}
      <ModernEmployeeHeader
        employee={employee}
        onLogout={handleLogout}
        onNavigateToForum={handleNavigateToForum}
        onNavigateToView={handleNavigateToView}
      />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-8">
          <div className={`rounded-xl bg-gradient-to-r ${deptInfo.color} text-white shadow-lg overflow-hidden`}>
            <div className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
                {/* Profile Image */}
                <div className="flex-shrink-0">
                  <div className="relative">
                    <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-white/20 bg-white/10 flex items-center justify-center">
                      {employee.profileImage ? (
                        <img
                          src={employee.profileImage || "/placeholder.svg"}
                          alt={employee.fullName}
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        <span className="text-3xl md:text-4xl font-bold text-white/80">{initials}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Hero Info */}
                <div className="flex-1">
                  <div className="text-3xl md:text-4xl font-bold mb-2">{deptInfo.icon}</div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-1">{employee.fullName}</h1>
                  <p className="text-white/90 mb-4 font-mono">{employee.employeeCode}</p>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-white/20 text-white border-white/30">{deptInfo.label}</Badge>
                    <Badge
                      className={
                        employee.status === "active"
                          ? "bg-green-400/20 text-green-100 border-green-300/30"
                          : "bg-red-400/20 text-red-100 border-red-300/30"
                      }
                    >
                      {employee.status === "active" ? "نشط" : "غير نشط"}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Image Upload Section */}
        <div className="mb-8">
          <ProfileImageUploader
            employeeName={employee.fullName}
            currentImageUrl={employee.profileImage}
            onImageUpload={handleImageUpload}
            canUpload={true}
            disabled={false}
          />
        </div>

       <ModernStatsCards
  employee={{
    joinDate: employee.joinDate,
    age: employee.age,
  }}
  ratings={{
    averageRating: (employee as any).averageRating || 0,
  }}
/>


        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Left Column - Main Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information Card */}
            <Card className="shadow-sm border-border/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-600" />
                  البيانات الشخصية
                </CardTitle>
                <CardDescription>معلومات الموظف الأساسية</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">الاسم الكامل</label>
                    <p className="text-lg font-semibold mt-1">{employee.fullName}</p>
                  </div>

                  {/* Employee Code */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase">الرقم الكودي</label>
                    <p className="text-lg font-mono font-bold text-blue-600 mt-1">{employee.employeeCode}</p>
                  </div>

                  {/* Email */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      البريد الإلكتروني
                    </label>
                    <p className="text-sm mt-1 break-all">{employee.email}</p>
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      رقم الهاتف
                    </label>
                    <p className="text-lg font-semibold mt-1">{employee.phone}</p>
                  </div>

                  {/* Department */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                      <Briefcase className="w-3 h-3" />
                      القسم
                    </label>
                    <p className="text-lg font-semibold mt-1">{employee.department}</p>
                  </div>

                  {/* Join Date */}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      تاريخ الانضمام
                    </label>
                    <p className="text-lg font-semibold mt-1">
                      {new Date(employee.joinDate).toLocaleDateString("ar-SA")}
                    </p>
                  </div>

                  {/* Age */}
                  {employee.age && (
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase">العمر</label>
                      <p className="text-lg font-semibold mt-1">{employee.age} سنة</p>
                    </div>
                  )}

                  {/* Gender */}
                  {employee.gender && (
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase">النوع</label>
                      <p className="text-lg font-semibold mt-1">
                        {employee.gender === "ذكر" || employee.gender === "male" ? "ذكر" : "أنثى"}
                      </p>
                    </div>
                  )}

                  {/* Marital Status */}
                  {employee.maritalStatus && (
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase">الحالة الاجتماعية</label>
                      <p className="text-lg font-semibold mt-1">{employee.maritalStatus}</p>
                    </div>
                  )}

                  {/* Address */}
                  {employee.address && (
                    <div className="md:col-span-2">
                      <label className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        العنوان
                      </label>
                      <p className="text-sm mt-1">{employee.address}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Status Card */}
          <div>
            <Card className="shadow-sm border-border/40 sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Shield className="w-4 h-4 text-purple-600" />
                  معلومات الحساب
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">حالة الحساب</p>
                  <Badge
                    className={
                      employee.status === "active"
                        ? "bg-green-100 text-green-700 hover:bg-green-100"
                        : "bg-red-100 text-red-700 hover:bg-red-100"
                    }
                  >
                    {employee.status === "active" ? "موظف نشط" : "غير نشط"}
                  </Badge>
                </div>

                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">نوع الحساب</p>
                  <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
                    {employee.role === "admin" ? "مسؤول" : "موظف"}
                  </Badge>
                </div>

                {employee.role === "admin" && (
                  <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="text-xs text-purple-700 font-semibold">لديك صلاحيات مسؤول</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Employee Ratings Section */}
        <div className="mb-8">
          <Card className="shadow-lg border-0">
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-blue-50 border-b">
              <CardTitle>تقييمات الأداء</CardTitle>
              <CardDescription>معايير التقييم ومستويات الأداء</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <EmployeeRatingsDisplay employeeId={employeeId} departmentId={employee.department} />
            </CardContent>
          </Card>
        </div>

        {/* Lectures and Attendance Section */}
        <div className="mb-8 space-y-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-emerald-100 rounded-lg">
              <BookOpen className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">المحاضرات والحضور</h2>
              <p className="text-muted-foreground">تابع محاضراتك وسجل حضورك وإحصائياتك</p>
            </div>
          </div>

          {/* Lectures List */}
          <StudentLecturesList studentId={employeeId} departmentId={employee.department} />

          {/* Attendance Stats */}
          <StudentAttendanceStats studentId={employeeId} departmentId={employee.department} />
        </div>

        {/* Additional Personal Data Information Sections */}
        <div className="mb-8">
          <PersonalDataSection employeeId={employeeId} canEdit={true} />
        </div>

        {/* Student Requests Section */}
        <div className="mb-8">
          <StudentRequestsSection studentId={employeeId} />
        </div>

        {/* Send Request Button */}
        <div className="mb-12">
          <Button
            onClick={() => setShowRequestModal(true)}
            className="w-full md:w-96 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-semibold py-6 text-lg rounded-lg shadow-lg"
          >
            <FileText className="w-5 h-5 mr-2" />
            إرسال طلب لشؤون الطلاب
          </Button>
        </div>
      </main>

      {/* Request Modal */}
      {showRequestModal && (
        <SendRequestModal onClose={() => setShowRequestModal(false)} employee={employee} employeeId={employeeId} />
      )}
    </div>
  )
}
