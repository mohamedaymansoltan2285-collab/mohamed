"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import { useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, getDocs, doc, updateDoc } from "firebase/firestore"
import { WelcomeModal } from "@/components/welcome-modal"

export default function EmployeeLayoutContent({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [loading, setLoading] = useState(true)
  const [isValid, setIsValid] = useState(false)
  const [showWelcomeModal, setShowWelcomeModal] = useState(false)
  const [employeeData, setEmployeeData] = useState<any>(null)

  useEffect(() => {
    const verifyEmployee = async () => {
      const code = searchParams.get("code")

      if (!code) {
        const storedCode = localStorage.getItem("employeeCode")
        if (!storedCode) {
          router.push("/login")
          return
        }
        await loadEmployeeData(storedCode)
        setIsValid(true)
        setLoading(false)
        return
      }

      try {
        const q = query(collection(db, "employees"), where("employeeCode", "==", code))
        const snapshot = await getDocs(q)

        if (snapshot.empty) {
          router.push("/login")
          return
        }

        localStorage.setItem("employeeCode", code)
        await loadEmployeeData(code)
        setIsValid(true)
      } catch (error) {
        console.error("[v0] Error verifying employee:", error)
        router.push("/login")
      } finally {
        setLoading(false)
      }
    }

    verifyEmployee()
  }, [searchParams, router])

  const loadEmployeeData = async (code: string) => {
    try {
      const q = query(collection(db, "employees"), where("employeeCode", "==", code))
      const snapshot = await getDocs(q)

      if (!snapshot.empty) {
        const data = snapshot.docs[0].data()
        const docId = snapshot.docs[0].id
        setEmployeeData({ ...data, id: docId })

        console.log("[v0] Employee data loaded:", {
          name: data.name,
          hasSeenWelcomeModal: data.hasSeenWelcomeModal,
          isAdmin: data.isAdmin,
          isReadOnly: data.isReadOnly,
        })

        if (!data.isAdmin && !data.isReadOnly && !data.hasSeenWelcomeModal) {
          console.log("[v0] First time user - showing welcome modal")
          setTimeout(() => {
            setShowWelcomeModal(true)
            console.log("[v0] Welcome modal state updated to true")
          }, 800)
        } else {
          console.log("[v0] User has already seen the modal or is admin/read-only")
        }
      }
    } catch (error) {
      console.error("[v0] Error loading employee data:", error)
    }
  }

  const handleModalSubmit = async (message: string, rating: number) => {
    if (!employeeData) return

    try {
      // Update employee's hasSeenWelcomeModal flag
      const employeeRef = doc(db, "employees", employeeData.id)
      await updateDoc(employeeRef, {
        hasSeenWelcomeModal: true,
      })

      // Save testimonial
      const testimonialData = {
        employeeCode: employeeData.employeeCode,
        employeeName: employeeData.name,
        employeeImage: employeeData.imageUrl || null,
        message,
        rating,
        createdAt: new Date().toISOString(),
      }

      await fetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testimonialData),
      })

      console.log("[v0] Testimonial saved successfully")
      setShowWelcomeModal(false)
    } catch (error) {
      console.error("[v0] Error saving testimonial:", error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-muted-background border-t-accent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (!isValid) {
    return null
  }

  return (
    <>
      <div>{children}</div>
      {showWelcomeModal && employeeData && (
        <WelcomeModal
          isOpen={showWelcomeModal}
          onClose={() => setShowWelcomeModal(false)}
          onSubmit={handleModalSubmit}
          employeeName={employeeData.name}
        />
      )}
    </>
  )
}
