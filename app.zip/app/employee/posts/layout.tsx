import type React from "react"
export default function PostsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
