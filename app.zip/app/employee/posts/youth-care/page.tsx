'use client';


import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, getDocs, onSnapshot, deleteDoc, doc } from "firebase/firestore"
import type { Employee } from "@/types/employee"
import ModernEmployeeHeader from "@/components/modern-employee-header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Plus, Trash2, Calendar, Share2 } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import AddPostModal from "@/components/add-post-modal"

interface Post {
  id: string
  title: string
  content: string
  imageUrl?: string | null
  linkUrl?: string | null
  createdAt: string
  updatedAt: string
  category: string
}

export default function YouthCarePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [employee, setEmployee] = useState<Employee | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      const code = searchParams.get("code") || localStorage.getItem("employeeCode")
      if (!code) {
        router.push("/login")
        return
      }

      try {
        const q = query(collection(db, "employees"), where("employeeCode", "==", code))
        const snapshot = await getDocs(q)
        if (!snapshot.empty) {
          const data = snapshot.docs[0].data() as Employee
          setEmployee(data)
          localStorage.setItem("employeeCode", code)
        }

        const postsQuery = query(collection(db, "posts"), where("category", "==", "youth-care"))
        const unsubscribe = onSnapshot(postsQuery, (snapshot) => {
          const postsList: Post[] = []
          snapshot.forEach((doc) => {
            postsList.push({ id: doc.id, ...doc.data() } as Post)
          })
          postsList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          setPosts(postsList)
        })

        return () => unsubscribe()
      } catch (error) {
        console.error("[v0] Error:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [searchParams, router])

  const handleDeletePost = async (postId: string) => {
    if (!confirm("هل تريد حذف هذا المنشور؟")) return
    try {
      await deleteDoc(doc(db, "posts", postId))
    } catch (error) {
      console.error("[v0] Error deleting post:", error)
    }
  }

  const handleShare = async (post: Post) => {
    const shareText = `${post.title}\n\n${post.content}`
    if (navigator.share) {
      navigator.share({ title: post.title, text: shareText })
    } else {
      navigator.clipboard.writeText(shareText)
      alert("تم نسخ المنشور إلى الحافظة")
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("employeeCode")
    router.push("/login")
  }

  const handleNavigateToForum = () => {
    window.location.href = `/employee/forum?code=${employee?.employeeCode}`
  }

  if (loading)
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-border border-t-blue-600 rounded-full animate-spin"></div>
        </div>
      </div>
    )

  if (!employee) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-cyan-50">
      <ModernEmployeeHeader
        employee={employee}
        onLogout={handleLogout}
        onNavigateToForum={handleNavigateToForum}
      />

      <main className="container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-600 text-white p-8 shadow-lg">
            <div className="flex items-center gap-4 mb-4">
              <span className="text-5xl">🎯</span>
              <h1 className="text-4xl font-bold">رعاية الشباب</h1>
            </div>
            <p className="text-blue-100 text-lg max-w-2xl">
              برامج تطوير الشباب والأنشطة الطلابية المميزة - احصل على أحدث الأخبار والفعاليات
            </p>
          </div>
        </motion.div>

        {employee.role === "admin" && (
          <div className="mb-8 flex justify-end">
            <Button
              onClick={() => setShowModal(true)}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:shadow-lg gap-2 text-white px-6 py-3"
            >
              <Plus className="w-5 h-5" />
              إضافة منشور
            </Button>
          </div>
        )}

        {showModal && (
          <AddPostModal
            onClose={() => setShowModal(false)}
            category="youth-care"
            categoryName="رعاية الشباب"
            categoryColor="blue"
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {posts.length === 0 ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="col-span-full text-center py-16">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-blue-100 rounded-full mb-6">
                  <span className="text-5xl">🎯</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">لا توجد منشورات حالياً</h3>
                <p className="text-gray-600">سيتم إضافة المنشورات قريباً</p>
              </motion.div>
            ) : (
              posts.map((post, index) => {
                const link = post.linkUrl?.trim() || null
                return (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ y: -4 }}
                  >
                    <Card className="overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 h-full flex flex-col">
                      {post.imageUrl && (
                        <div className="relative h-48 bg-gradient-to-r from-blue-400 to-cyan-400 overflow-hidden">
                          <img
                            src={post.imageUrl ?? "/placeholder.svg"}
                            alt={post.title}
                            className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/20"></div>
                        </div>
                      )}

                      <div className="p-6 flex-1 flex flex-col">
                        <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">{post.title}</h3>
                        <p className="text-gray-600 mb-4 text-sm line-clamp-3 flex-1">{post.content}</p>

                        <div className="space-y-2 mb-4 pt-4 border-t border-gray-100">
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <Calendar className="w-4 h-4" />
                            <span>{new Date(post.createdAt).toLocaleDateString("ar-SA")}</span>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          {link && (
                            <Button
                              onClick={() => window.open(link, "_blank")}
                              variant="outline"
                              className="flex-1 text-amber-600 border-amber-300 text-sm"
                            >
                              عرض الرابط
                            </Button>
                          )}
                          <Button
                            onClick={() => handleShare(post)}
                            variant="outline"
                            className="text-blue-600 border-blue-300"
                            size="sm"
                            title="مشاركة المنشور"
                          >
                            <Share2 className="w-4 h-4" />
                          </Button>
                          {employee.role === "admin" && (
                            <Button
                              onClick={() => handleDeletePost(post.id)}
                              variant="outline"
                              className="text-red-600 border-red-300"
                              size="sm"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                )
              })
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  )
}
