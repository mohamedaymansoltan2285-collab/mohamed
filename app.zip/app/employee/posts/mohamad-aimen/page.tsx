// app/employee/posts/mohamad-aimen/page.tsx
import React, { Suspense } from 'react'; 
import MohamadAimenContent from './MohamadAimenContent' // ✅ استيراد الملف مباشرة

// جعل الصفحة ديناميكية لضمان عدم التخزين المؤقت وتجنب أخطاء Server Rendering
export const dynamic = 'force-dynamic'; 

const LoadingFallback = () => (
    <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="w-12 h-12 border-4 border-border border-t-indigo-600 rounded-full animate-spin"></div>
    </div>
);

export default function MohamadAimenPage() {
    return (
        <Suspense fallback={<LoadingFallback />}>
            <MohamadAimenContent />
        </Suspense>
    );
}
