'use client';


import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, getDocs } from "firebase/firestore"
import type { Employee } from "@/types/employee"
import ModernEmployeeHeader from "@/components/modern-employee-header"
import { motion } from "framer-motion"

export default function PostsMainPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [employee, setEmployee] = useState<Employee | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchEmployee = async () => {
      const code = searchParams.get("code") || localStorage.getItem("employeeCode")
      if (!code) {
        router.push("/login")
        return
      }

      try {
        const q = query(collection(db, "employees"), where("employeeCode", "==", code))
        const snapshot = await getDocs(q)
        if (!snapshot.empty) {
          const data = snapshot.docs[0].data() as Employee
          setEmployee(data)
          localStorage.setItem("employeeCode", code)
        }
      } catch (error) {
        console.error("[v0] Error:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchEmployee()
  }, [searchParams, router])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-border border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (!employee) return null

  const services = [
    {
      id: "youth-care",
      title: "رعاية الشباب",
      description: "برامج تطوير الشباب والأنشطة الطلابية المميزة",
      icon: "🎯",
      gradient: "from-blue-500 to-cyan-500",
      color: "blue",
      href: "/employee/posts/youth-care",
    },
    {
      id: "student-union",
      title: "اتحاد الطلاب",
      description: "أخبار وفعاليات اتحاد الطلاب والتمثيل الطلابي",
      icon: "👥",
      gradient: "from-purple-500 to-pink-500",
      color: "purple",
      href: "/employee/posts/student-union",
    },
    {
      id: "women-support",
      title: "وحدة تكافؤ الفرص ودعم المرأة",
      description: "دعم المرأة ومناهضة العنف وتكافؤ الفرص",
      icon: "🌸",
      gradient: "from-rose-500 to-orange-500",
      color: "rose",
      href: "/employee/posts/women-support",
    },
    {
      id: "uccd",
      title: "مركز ربط الجامعة بالصناعة UCCD",
      description: "الشراكات الصناعية والتدريب والتوظيف",
      icon: "🏭",
      gradient: "from-amber-500 to-orange-500",
      color: "amber",
      href: "/employee/posts/uccd",
    },
    {
      id: "student-affairs",
      title: "شؤون الطلاب",
      description: "خدمات شؤون الطلاب والدعم الأكاديمي",
      icon: "📚",
      gradient: "from-teal-500 to-green-500",
      color: "teal",
      href: "/employee/posts/student-affairs",
    },
    {
      id: "mohamad-aimen",
      title: "المبرمج محمد أيمن",
      description: "تحديثات وأخبار من قسم التطوير والبرمجة",
      icon: "💻",
      gradient: "from-indigo-500 to-blue-500",
      color: "indigo",
      href: "/employee/posts/mohamad-aimen",
    },
  ]

  const handleNavigateToGallery = () => {
    window.location.href = "/gallery"
  }

  const handleNavigateToForum = () => {
    window.location.href = `/employee/forum?code=${employee.employeeCode}`
  }

  const handleLogout = () => {
    localStorage.removeItem("employeeCode")
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <ModernEmployeeHeader employee={employee} onLogout={handleLogout} onNavigateToForum={handleNavigateToForum} />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 text-white py-20">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
              الخدمات والمنشورات الطلابية
            </h1>
            <p className="text-lg md:text-xl text-white/90 text-pretty">
              استعرض آخر الأخبار والمنشورات من الوحدات الطلابية المختلفة والاستفادة من الخدمات المقدمة
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group cursor-pointer"
              onClick={() => router.push(service.href)}
            >
              <div className="h-full rounded-2xl overflow-hidden bg-white shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100">
                {/* Header Background */}
                <div className={`bg-gradient-to-r ${service.gradient} h-40 relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-black/10"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-7xl opacity-20 group-hover:scale-110 transition-transform duration-300">
                      {service.icon}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <div className="mb-4">
                    <span className="text-4xl mb-4 block">{service.icon}</span>
                    <h3 className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-300 text-pretty">
                      {service.title}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-6 text-sm leading-relaxed">{service.description}</p>
                  <div
                    className={`inline-flex items-center text-${service.color}-600 font-semibold group-hover:gap-3 transition-all duration-300 gap-2`}
                  >
                    <span>استعرض المنشورات</span>
                    <span className="text-xl">←</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Additional Info Section */}
      <section className="bg-white py-16 border-t border-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">متابعة المنشورات</h2>
            <p className="text-gray-600 text-lg mb-8 text-pretty">
              اختر أحد الخدمات أعلاه لعرض أحدث المنشورات والأخبار والاستفادة من البرامج المقدمة من الجامعة
            </p>
            <button
              onClick={handleNavigateToGallery}
              className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
            >
              <span>معرض الصور</span>
              <span>→</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
