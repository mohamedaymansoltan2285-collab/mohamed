"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Clock, TrendingUp, BarChart3, Sparkles, ChevronLeft } from "lucide-react"
import ProfessionalFooter from "@/components/professional-footer"

export default function FeaturesPage() {
  const router = useRouter()

  const features = [
    {
      icon: Clock,
      title: "تسجيل الحضور والانصراف",
      description: "تسجيل سهل وسريع لأوقات الحضور والانصراف بكل دقة",
    },
    {
      icon: TrendingUp,
      title: "متابعة الأداء اليومي",
      description: "تقييم أداء الموظفين بناءً على معايير محددة كل يوم",
    },
    {
      icon: BarChart3,
      title: "تقارير ذكية",
      description: "تقارير شاملة تساعد الإدارة على اتخاذ قرارات أفضل",
    },
    {
      icon: Sparkles,
      title: "واجهة جميلة وسهلة",
      description: "تصميم احترافي وسهل الاستخدام يعجب الجميع",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-lime-50 text-gray-900 p-4 flex flex-col">
      <div className="flex-1">
        {/* Header */}
        <div className="max-w-5xl mx-auto mb-12">
          <div className="flex items-center gap-4 mb-8">
            <button onClick={() => router.back()} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-900 to-blue-600 bg-clip-text text-transparent">
              مميزات النظام
            </h1>
          </div>

          {/* Features grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <div
                  key={index}
                  className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100 animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="bg-gradient-to-br from-blue-100 to-lime-100 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                    <Icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-slate-900">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              )
            })}
          </div>

          {/* Tagline */}
          <div className="bg-gradient-to-r from-blue-600 to-lime-500 rounded-2xl p-8 text-white text-center mb-8 shadow-xl">
            <p className="text-2xl font-bold">"كل تفاصيلك بين يديك مع نظام الخيرات الذكي"</p>
          </div>

          {/* Navigation buttons */}
          <div className="flex gap-4 justify-center">
            <Button
              onClick={() => router.push("/welcome/president")}
              className="bg-gradient-to-r from-lime-500 to-blue-500 hover:from-lime-600 hover:to-blue-600 text-white font-bold py-3 px-8 rounded-full"
            >
              التالي
            </Button>
            <Button onClick={() => router.back()} variant="outline" className="font-bold py-3 px-8 rounded-full">
              السابق
            </Button>
          </div>
        </div>
      </div>

      {/* Professional Footer */}
      <ProfessionalFooter />
    </div>
  )
}
