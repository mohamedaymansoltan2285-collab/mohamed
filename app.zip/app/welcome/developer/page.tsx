"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Code2, Palette } from "lucide-react"
import ProfessionalFooter from "@/components/professional-footer"

export default function DeveloperPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-slate-900 text-white flex flex-col">
      <div className="flex-1 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-12">
            <button onClick={() => router.back()} className="p-2 hover:bg-gray-700 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-lime-400 to-blue-400 bg-clip-text text-transparent">
              مبرمج النظام
            </h1>
          </div>

          {/* Main content */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            {/* Image */}
            <div className="flex justify-center animate-fade-in">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-lime-500 to-blue-500 rounded-3xl blur-2xl opacity-30"></div>
                <Image
                  src="/images/mmmmm.png"
                  alt="محمد أيمن"
                  width={300}
                  height={400}
                  className="relative rounded-3xl shadow-2xl border-4 border-lime-500/50"
                />
              </div>
            </div>

            {/* Text content */}
            <div className="animate-slide-in">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">محمد أيمن</h2>

              <p className="text-lg text-gray-300 mb-6">مبرمج ومصمم متخصص في تطوير الأنظمة الإدارية المتقدمة</p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <Code2 className="w-6 h-6 text-lime-400" />
                  <span className="text-gray-200">تطوير وبرمجة النظام</span>
                </div>
                <div className="flex items-center gap-3">
                  <Palette className="w-6 h-6 text-blue-400" />
                  <span className="text-gray-200">تصميم واجهة المستخدم</span>
                </div>
              </div>

              <p className="text-gray-300 mb-8 leading-relaxed">
                تم تصميم وتطوير هذا النظام برؤية حديثة لخدمة الجامعة وتحقيق أعلى معايير النزاهة في الإدارة
                والعمليات.
              </p>

              <p className="text-lime-400 font-semibold mb-8">مكرس لتقديم حلول تقنية احترافية وموثوقة</p>

              <div className="flex gap-4">
                <Button
                  onClick={() => router.push("/welcome/start")}
                  className="bg-gradient-to-r from-lime-500 to-blue-500 hover:from-lime-600 hover:to-blue-600 text-white font-bold py-3 px-8 rounded-full"
                >
                  التالي
                </Button>
                <Button
                  onClick={() => router.back()}
                  variant="outline"
                  className="font-bold py-3 px-8 rounded-full border-gray-500 text-white hover:bg-gray-800"
                >
                  السابق
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Footer */}
      <ProfessionalFooter />
    </div>
  )
}
