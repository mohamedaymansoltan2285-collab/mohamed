"use client"

import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { ChevronLeft, Zap } from 'lucide-react'
import ProfessionalFooter from "@/components/professional-footer"

export default function AboutPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-900 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="max-w-4xl mx-auto w-full">
          {/* Header with back button */}
          <div className="mb-12 flex items-center gap-4">
            <button onClick={() => router.back()} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-900 to-blue-600 bg-clip-text text-transparent">
              عن النظام
            </div>
          </div>

          {/* Main content */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            {/* Icon section */}
            <div className="flex justify-center">
              <div className="relative w-64 h-64 bg-gradient-to-br from-blue-100 to-lime-100 rounded-3xl flex items-center justify-center shadow-2xl">
                <Zap className="w-32 h-32 text-blue-600" />
              </div>
            </div>

            {/* Text section */}
            <div className="animate-slide-in">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-slate-900">نظام الحضور والغياب للطلاب</h2>

              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                نظام ذكي متقدم صُمم خصيصاً لمتابعة الحضور والانصراف وتحسين أداء الطلاب بشكل يومي، مع توفير تقارير
                تفصيلية تساعد الإدارة على اتخاذ قرارات مستنيرة وتحسين جودة العملية التعليمية.
              </p>

              <p className="text-lg text-lime-600 font-semibold mb-8">
                صُمم ليجعل الجودة أسلوب حياة داخل جامعة بني سويف التكنولوجية
              </p>

              <p className="text-gray-600 mb-8">
                مع تطبيق تقنيات الإدارة الحديثة والذكاء الاصطناعي، يوفر النظام حلاً شاملاً وموثوقاً لجميع احتياجات إدارة
                شؤون الطلاب.
              </p>

              <div className="flex gap-4">
                <Button
                  onClick={() => router.push("/welcome/features")}
                  className="bg-gradient-to-r from-lime-500 to-blue-500 hover:from-lime-600 hover:to-blue-600 text-white font-bold py-3 px-8 rounded-full"
                >
                  التالي
                </Button>
                <Button onClick={() => router.back()} variant="outline" className="font-bold py-3 px-8 rounded-full">
                  السابق
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ProfessionalFooter />
    </div>
  )
}
