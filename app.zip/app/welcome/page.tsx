"use client"

import { useRouter } from 'next/navigation'
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useEffect } from "react"
import { useAudio } from "@/components/audio-context"

export default function WelcomePage() {
  const router = useRouter()
  const { startWelcomeAudio } = useAudio()

  useEffect(() => {
    localStorage.setItem("hasVisitedWelcome", "true")
  }, [])

  const handleStartNow = () => {
    startWelcomeAudio()
    setTimeout(() => {
      router.push("/welcome/about")
    }, 500)
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-lime-500/8 to-blue-500/8 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-blue-500/8 to-lime-500/8 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-96 h-96 bg-gradient-to-r from-lime-500/5 to-transparent rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      {/* Main content container with improved spacing and layout */}
      <div className="max-w-2xl w-full flex flex-col items-center justify-center relative z-10">
        <div className="mb-12 animate-fade-in">
          <div className="relative group transition-transform duration-500 hover:scale-110">
            <div className="absolute inset-0 bg-gradient-to-r from-lime-600/20 to-blue-600/20 rounded-2xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <Image
              src="/images/1213.png"
              alt="جامعة بني سويف التكنولوجية"
              width={200}
              height={200}
              className="drop-shadow-lg relative z-10"
              priority
            />
          </div>
        </div>

        <h1
          className="text-5xl md:text-6xl font-bold text-center mb-4 text-gray-900 leading-tight animate-slide-up"
          style={{ animationDelay: "0.1s" }}
        >
          أهلاً وسهلاً
        </h1>

        <p
          className="text-3xl md:text-4xl font-bold text-center mb-6 bg-gradient-to-r from-lime-600 via-blue-600 to-lime-600 bg-clip-text text-transparent animate-slide-up"
          style={{ animationDelay: "0.2s" }}
        >
          جامعة بني سويف التكنولوجية
        </p>

        <p
          className="text-lg md:text-xl text-gray-600 text-center mb-12 max-w-xl leading-relaxed animate-fade-in"
          style={{ animationDelay: "0.3s" }}
        >
          نظام إدارة الطلاب المتقدم
          <br />
          <span className="text-gray-500">لضمان أعلى معايير الجودة والأداء الأكاديمي</span>
        </p>

        <div className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
          <Button
            onClick={handleStartNow}
            size="lg"
            className="bg-gradient-to-r from-lime-600 to-blue-600 hover:from-lime-700 hover:to-blue-700 text-white font-bold py-4 px-20 rounded-full transition-all duration-300 transform hover:scale-110 active:scale-95 shadow-xl hover:shadow-2xl text-lg"
          >
            ابدأ الآن
          </Button>
        </div>

        <div
          className="mt-16 flex justify-center gap-8 text-sm text-gray-500 animate-fade-in"
          style={{ animationDelay: "0.5s" }}
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-lime-600 rounded-full"></div>
            <span>إدارة سهلة</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
            <span>أداء عالي</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-lime-600 rounded-full"></div>
            <span>موثوقية تامة</span>
          </div>
        </div>
      </div>

      {/* CSS animations */}
      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in {
          animation: fade-in 0.9s ease-out forwards;
          opacity: 0;
        }

        .animate-slide-up {
          animation: slide-up 0.9s ease-out forwards;
          opacity: 0;
        }
      `}</style>
    </div>
  )
}
