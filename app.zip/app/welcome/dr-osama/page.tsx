"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Heart, BookOpen, Star, Lightbulb } from "lucide-react"
import ProfessionalFooter from "@/components/professional-footer"

export default function DrOsamaPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white flex flex-col relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-teal-500/10 to-emerald-500/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1.5s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-[500px] h-[500px] bg-gradient-to-r from-emerald-500/5 to-teal-500/5 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "3s" }}
        ></div>
      </div>

      <div className="flex-1 p-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-12 animate-fade-in">
            <button onClick={() => router.back()} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
              كلمة شكر وتقدير
            </h1>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            {/* Profile Image Section */}
            <div className="flex justify-center animate-scale-in">
              <div className="relative group">
                {/* Outer glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 rounded-full blur-2xl opacity-40 group-hover:opacity-60 transition-opacity duration-500 animate-pulse"></div>

                {/* Decorative ring */}
                <div className="absolute inset-0 rounded-full border-4 border-emerald-400/30 animate-spin-slow"></div>

                {/* Image container */}
                <div className="relative w-72 h-72 rounded-full overflow-hidden border-8 border-gradient-to-r from-emerald-400 to-teal-300 shadow-2xl transform transition-transform duration-500 group-hover:scale-105">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 z-10"></div>
                  <Image
                    src="/images/image12.png"
                    alt="الدكتور أسامة"
                    fill
                    className="object-cover relative z-0"
                    priority
                  />
                </div>
              </div>
            </div>

            {/* Content Section */}
            <div className="space-y-6 animate-slide-in-right">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-3 bg-gradient-to-r from-emerald-300 via-teal-200 to-emerald-300 bg-clip-text text-transparent leading-tight">
                  الدكتور أسامة
                </h2>
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                  أستاذ ورمز التميز في قسم تكنولوجيا المعلومات
                </h3>
                <p className="text-lg text-emerald-300/90 font-semibold italic">من محافظة الفيوم الجميلة</p>
              </div>

              {/* Main appreciation paragraph */}
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-emerald-400/20 shadow-xl">
                <p className="text-lg text-gray-200 leading-relaxed mb-4">
                  نتوجه بخالص الشكر والتقدير إلى الدكتور أسامة، أحد أعمدة قسم تكنولوجيا المعلومات، وصاحب الفضل الأكبر في
                  دعم فكرة هذا المشروع ورعايتها منذ بدايتها. لقد كان الدكتور أسامة أول من آمن بقيمة هذا النظام، وشجع على
                  تطويره وتنفيذه بكل حماس واهتمام.
                </p>
                <p className="text-lg text-gray-200 leading-relaxed mb-4">
                  تميز الدكتور أسامة بمتابعته الدقيقة للمشروع، حيث قام بتجربته بنفسه والتأكد من جودته وفعاليته، مما أعطى
                  دفعة قوية للإطلاق الرسمي. إن دعمه المستمر وتوجيهاته القيمة كانت من أهم أسباب نجاح هذا العمل.
                </p>
                <p className="text-lg text-gray-200 leading-relaxed">
                  يحظى الدكتور أسامة بمحبة واحترام كبيرين من جميع الطلاب، فهو ليس فقط أستاذاً متميزاً في مجاله، بل هو أيضاً
                  إنسان راقٍ يتمتع بأخلاق عالية وطيبة قلب، يمد يد العون دائماً ويقدم الدعم الحقيقي لكل من يحتاجه. شخصيته
                  الرائعة تعكس قيم محافظة الفيوم الأصيلة من حسن الأخلاق والعلم والكرم.
                </p>
              </div>

              {/* Qualities Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 backdrop-blur-sm rounded-xl p-4 border border-emerald-400/30 text-center transform transition-transform hover:scale-105">
                  <Heart className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">طيبة القلب</p>
                </div>
                <div className="bg-gradient-to-br from-teal-500/20 to-cyan-500/20 backdrop-blur-sm rounded-xl p-4 border border-teal-400/30 text-center transform transition-transform hover:scale-105">
                  <BookOpen className="w-8 h-8 text-teal-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">العلم والمعرفة</p>
                </div>
                <div className="bg-gradient-to-br from-emerald-500/20 to-green-500/20 backdrop-blur-sm rounded-xl p-4 border border-emerald-400/30 text-center transform transition-transform hover:scale-105">
                  <Star className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">التميز</p>
                </div>
                <div className="bg-gradient-to-br from-teal-500/20 to-emerald-500/20 backdrop-blur-sm rounded-xl p-4 border border-teal-400/30 text-center transform transition-transform hover:scale-105">
                  <Lightbulb className="w-8 h-8 text-teal-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">الإبداع</p>
                </div>
              </div>

              {/* Special appreciation quote */}
             <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 backdrop-blur-sm rounded-xl p-6 border-r-4 border-emerald-400 mt-6">
  <p className="text-xl text-emerald-300 font-semibold italic text-center">
    شكراً جزيلاً دكتور أسامة على دعمك الدائم وإيمانك بالمشروع منذ البداية. أنت قدوة حقيقية في العطاء
    والإبداع.
  </p>
</div>

              {/* Navigation Buttons */}
              <div className="flex gap-4 mt-8">
                <Button
                  onClick={() => router.push("/welcome/developer")}
                  className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500 hover:from-emerald-600 hover:via-teal-600 hover:to-emerald-600 text-slate-900 font-bold py-3 px-8 rounded-full shadow-xl hover:shadow-2xl transform transition-all hover:scale-105"
                >
                  التالي
                </Button>
                <Button
                  onClick={() => router.back()}
                  variant="outline"
                  className="font-bold py-3 px-8 rounded-full border-emerald-400/50 text-emerald-300 hover:bg-emerald-500/10 hover:border-emerald-400"
                >
                  السابق
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Footer */}
      <ProfessionalFooter />

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes scale-in {
          from {
            opacity: 0;
            transform: scale(0.8);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes slide-in-right {
          from {
            opacity: 0;
            transform: translateX(50px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes spin-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }

        .animate-fade-in {
          animation: fade-in 0.8s ease-out forwards;
        }

        .animate-scale-in {
          animation: scale-in 1s ease-out forwards;
          animation-delay: 0.2s;
          opacity: 0;
        }

        .animate-slide-in-right {
          animation: slide-in-right 0.9s ease-out forwards;
          animation-delay: 0.4s;
          opacity: 0;
        }

        .animate-spin-slow {
          animation: spin-slow 20s linear infinite;
        }
      `}</style>
    </div>
  )
}
