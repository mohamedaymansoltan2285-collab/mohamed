"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Award, Users, Lightbulb } from "lucide-react"
import ProfessionalFooter from "@/components/professional-footer"

export default function PresidentPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white flex flex-col relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-blue-500/10 to-amber-500/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1.5s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-[500px] h-[500px] bg-gradient-to-r from-amber-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "3s" }}
        ></div>
      </div>

      <div className="flex-1 p-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-4 mb-12 animate-fade-in">
            <button onClick={() => router.back()} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 bg-clip-text text-transparent">
              رئيس الجامعة
            </h1>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            <div className="flex justify-center animate-scale-in">
              <div className="relative group">
                {/* Outer glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 rounded-full blur-2xl opacity-40 group-hover:opacity-60 transition-opacity duration-500 animate-pulse"></div>

                {/* Decorative ring */}
                <div className="absolute inset-0 rounded-full border-4 border-amber-400/30 animate-spin-slow"></div>

                {/* Image container */}
                <div className="relative w-72 h-72 rounded-full overflow-hidden border-8 border-gradient-to-r from-amber-400 to-yellow-300 shadow-2xl transform transition-transform duration-500 group-hover:scale-105">
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-blue-500/20 z-10"></div>
                  <Image
                    src="/images/image1.jpg"
                    alt="رئيس جامعة بني سويف التكنولوجية"
                    fill
                    className="object-cover relative z-0"
                    priority
                  />
                </div>
              </div>
            </div>

            <div className="space-y-6 animate-slide-in-right">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-1 bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-300 bg-clip-text text-transparent leading-tight">
                  الأستاذ الدكتور
                </h2>
                {/* إضافة الاسم أسفل العنوان */}
                <h3 className="text-3xl md:text-4xl font-bold text-white mb-2">جان هنرى حنا</h3>
<h3 className="text-xl md:text-2xl font-bold text-amber-300 mb-6">
  رئيس جامعة بني سويف التكنولوجية
</h3>

                {/* إضافة النص الجديد تحت الاسم مباشرة */}
                <p className="text-lg text-gray-300">
                  رئيس جامعة بني سويف التكنولوجية منذ عام 2020، يقود الجامعة نحو التميز الأكاديمي والابتكار في التعليم.
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-amber-400/20 shadow-xl">
                <p className="text-lg text-gray-200 leading-relaxed mb-4">
                  تحت قيادة سعادة الأستاذ الدكتور رئيس الجامعة، تسير جامعة بني سويف التكنولوجية نحو آفاق جديدة من التميز
                  والإبداع. بفضل رؤيته الثاقبة وجهوده الدؤوبة، أصبحت الجامعة منارة للعلم والمعرفة، تقدم تعليماً متطوراً
                  يواكب أحدث المعايير العالمية.
                </p>
                <p className="text-lg text-gray-200 leading-relaxed">
                  يحرص سعادته على تطوير البنية التحتية التعليمية وتبني أحدث التقنيات، مما يضمن تخريج أجيال قادرة على
                  المنافسة والإبداع في سوق العمل المحلي والدولي. إن التزامه بالجودة والتميز يجعل من الجامعة صرحاً
                  أكاديمياً يفخر به الجميع.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="bg-gradient-to-br from-amber-500/20 to-yellow-500/20 backdrop-blur-sm rounded-xl p-4 border border-amber-400/30 text-center transform transition-transform hover:scale-105">
                  <Award className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">التميز الأكاديمي</p>
                </div>
                <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-sm rounded-xl p-4 border border-blue-400/30 text-center transform transition-transform hover:scale-105">
                  <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">خدمة المجتمع</p>
                </div>
                <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 backdrop-blur-sm rounded-xl p-4 border border-amber-400/30 text-center transform transition-transform hover:scale-105">
                  <Lightbulb className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-300 font-semibold">الابتكار والتطوير</p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-amber-500/10 to-blue-500/10 backdrop-blur-sm rounded-xl p-6 border-r-4 border-amber-400 mt-6">
  <p className="text-xl text-amber-300 font-semibold italic">
    نسعى لبناء جيل متميز قادر على قيادة المستقبل بثقة وإبداع
  </p>
</div>


              <div className="flex gap-4 mt-8">
                <Button
                  onClick={() => router.push("/welcome/dr-osama")}
                  className="bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-500 hover:from-amber-600 hover:via-yellow-600 hover:to-amber-600 text-slate-900 font-bold py-3 px-8 rounded-full shadow-xl hover:shadow-2xl transform transition-all hover:scale-105"
                >
                  التالي
                </Button>
                <Button
                  onClick={() => router.back()}
                  variant="outline"
                  className="font-bold py-3 px-8 rounded-full border-amber-400/50 text-amber-300 hover:bg-amber-500/10 hover:border-amber-400"
                >
                  السابق
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Footer */}
      <ProfessionalFooter />

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scale-in {
          from { opacity: 0; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes slide-in-right {
          from { opacity: 0; transform: translateX(50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-fade-in { animation: fade-in 0.8s ease-out forwards; }
        .animate-scale-in { animation: scale-in 1s ease-out forwards; animation-delay: 0.2s; opacity: 0; }
        .animate-slide-in-right { animation: slide-in-right 0.9s ease-out forwards; animation-delay: 0.4s; opacity: 0; }
        .animate-spin-slow { animation: spin-slow 20s linear infinite; }
      `}</style>
    </div>
  )
}
