"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Rocket, ArrowRight } from "lucide-react"
import ProfessionalFooter from "@/components/professional-footer"

export default function StartPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-lime-500 via-blue-600 to-slate-900 text-white flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>

        <div className="relative z-10 text-center max-w-2xl mx-auto">
          {/* Rocket icon */}
          <div className="mb-8 animate-bounce">
            <div className="inline-block bg-white/20 p-6 rounded-full backdrop-blur-md">
              <Rocket className="w-16 h-16 text-white" />
            </div>
          </div>

          {/* Main heading */}
          <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">جاهز للبدء؟</h1>

          {/* Subtitle */}
          <p
            className="text-2xl md:text-3xl mb-8 text-gray-100 font-light animate-fade-in"
            style={{ animationDelay: "0.2s" }}
          >
            ابدأ الآن رحلتك مع نظام
          </p>

          <p
            className="text-2xl mb-12 bg-gradient-to-r from-yellow-200 to-white bg-clip-text text-transparent font-bold animate-fade-in"
            style={{ animationDelay: "0.4s" }}
          >
            الحضور الذكى للطلاب  
          </p>

          <p
            className="text-lg md:text-xl mb-12 text-gray-200 leading-relaxed animate-fade-in"
            style={{ animationDelay: "0.6s" }}
          >
            لجامعة بنى سويف التكنولوجية     
          </p>

          {/* Call to action button */}
          <div className="animate-fade-in" style={{ animationDelay: "0.8s" }}>
            <Button
              onClick={() => router.push("/login")}
              size="lg"
              className="bg-white text-blue-600 hover:bg-gray-100 font-bold py-4 px-12 rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-2xl flex items-center gap-3 mx-auto"
            >
              ابدأ الآن
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Footer message */}
          <p className="mt-12 text-gray-200 text-sm animate-fade-in" style={{ animationDelay: "1s" }}>
مع طموح الطلاب… نرتقي بالجامعة، لأن الجودة تبدأ من الإنسان          </p>
        </div>
      </div>

      <ProfessionalFooter />
    </div>
  )
}
