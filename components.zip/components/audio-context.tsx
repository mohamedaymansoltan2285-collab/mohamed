"use client"

import type React from "react"
import { createContext, useContext, useEffect, useRef, useState } from "react"

interface AudioContextType {
  isPlaying: boolean
  startWelcomeAudio: () => void
  stopAudio: () => void
}

const AudioContext = createContext<AudioContextType | undefined>(undefined)

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const hasStartedRef = useRef(false)

  const startWelcomeAudio = () => {
    if (audioRef.current && !hasStartedRef.current) {
      audioRef.current.currentTime = 0
      audioRef.current.play().catch((err) => console.log("[v0] Audio play error:", err))
      setIsPlaying(true)
      hasStartedRef.current = true
      sessionStorage.setItem("audioPlaying", "true")
    }
  }

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      setIsPlaying(false)
      sessionStorage.removeItem("audioPlaying")
    }
  }

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleEnded = () => {
      setIsPlaying(false)
      sessionStorage.removeItem("audioPlaying")
    }

    audio.addEventListener("ended", handleEnded)
    return () => audio.removeEventListener("ended", handleEnded)
  }, [])

  return (
    <AudioContext.Provider value={{ isPlaying, startWelcomeAudio, stopAudio }}>
      <audio
        ref={audioRef}
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Audio%202025-11-10%20at%2020.34.46_69a35c93-hSBaD6Wh3jbY4b36voT2MDyo03MrRJ.mp3"
        preload="auto"
      />
      {children}
    </AudioContext.Provider>
  )
}

export function useAudio() {
  const context = useContext(AudioContext)
  if (context === undefined) {
    throw new Error("useAudio must be used within an AudioProvider")
  }
  return context
}
