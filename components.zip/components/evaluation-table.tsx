"use client"

import { Card } from "@/components/ui/card"
import type { Employee } from "@/types/employee"

interface EvaluationTableProps {
  employees: Employee[]
}

export default function EvaluationTable({ employees }: EvaluationTableProps) {
  if (employees.length === 0) {
    return null
  }

  return (
    <Card className="p-6 bg-gradient-to-br from-slate-50 to-slate-100 border-border">
      <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
        <span className="text-2xl">📋</span>
        جدول التقييم
      </h3>
      <div className="overflow-x-auto">
        <table className="w-full text-right">
          <thead>
            <tr className="border-b-2 border-border">
              <th className="px-4 py-3 font-semibold text-foreground text-sm">الموظف</th>
              <th className="px-4 py-3 font-semibold text-foreground text-sm">الكود</th>
              <th className="px-4 py-3 font-semibold text-foreground text-sm">الحالة</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.id} className="border-b border-border hover:bg-slate-200/50 transition-colors">
                <td className="px-4 py-4 text-sm text-foreground">{employee.fullName}</td>
                <td className="px-4 py-4 text-sm text-muted-foreground">{employee.employeeCode}</td>
                <td className="px-4 py-4 text-sm">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      employee.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {employee.status === "active" ? "نشط" : "غير نشط"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
