"use client"

import { useEffect, useState } from "react"
import { collection, onSnapshot, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Attendance, Lecture } from "@/types/lecture"
import { Calendar, Users, TrendingUp, Award } from "lucide-react"

interface StudentAttendanceStatsProps {
  studentId: string
  departmentId: string
}

export default function StudentAttendanceStats({ studentId, departmentId }: StudentAttendanceStatsProps) {
  const [attendances, setAttendances] = useState<Attendance[]>([])
  const [lectures, setLectures] = useState<Lecture[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Fetch all lectures for the department
    const lecturesQuery = query(collection(db, "lectures"), where("departmentId", "==", departmentId))
    const lecturesUnsubscribe = onSnapshot(lecturesQuery, (snapshot) => {
      const lecturesList: Lecture[] = []
      snapshot.forEach((doc) => {
        const data = doc.data() as Lecture
        lecturesList.push({ ...data, id: doc.id }) // spread قبل id
      })
      setLectures(lecturesList)
    })

    // Fetch student attendances
    const attendanceQuery = query(collection(db, "attendance"), where("studentId", "==", studentId))
    const attendanceUnsubscribe = onSnapshot(
      attendanceQuery,
      (snapshot) => {
        const attendanceList: Attendance[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Attendance
          attendanceList.push({ ...data, id: doc.id }) // spread قبل id
        })
        setAttendances(attendanceList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()))
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching attendances:", error)
        setLoading(false)
      },
    )

    return () => {
      lecturesUnsubscribe()
      attendanceUnsubscribe()
    }
  }, [studentId, departmentId])

  const totalPoints = attendances.length * 3
  const attendancePercentage = lectures.length > 0 ? Math.round((attendances.length / lectures.length) * 100) : 0

  if (loading) {
    return (
      <Card className="border-0 shadow-lg">
        <CardContent className="p-8 flex justify-center">
          <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Attended */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-500 to-teal-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">المحاضرات التي حضرتها</p>
                <p className="text-3xl font-bold mt-2">{attendances.length}</p>
              </div>
              <Users className="w-12 h-12 opacity-30" />
            </div>
          </CardContent>
        </Card>

        {/* Total Points */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">إجمالي النقاط</p>
                <p className="text-3xl font-bold mt-2">{totalPoints}</p>
              </div>
              <Award className="w-12 h-12 opacity-30" />
            </div>
          </CardContent>
        </Card>

        {/* Attendance Percentage */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-pink-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">نسبة الحضور</p>
                <p className="text-3xl font-bold mt-2">{attendancePercentage}%</p>
              </div>
              <TrendingUp className="w-12 h-12 opacity-30" />
            </div>
          </CardContent>
        </Card>

        {/* Total Lectures */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-500 to-red-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">إجمالي المحاضرات</p>
                <p className="text-3xl font-bold mt-2">{lectures.length}</p>
              </div>
              <Calendar className="w-12 h-12 opacity-30" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attended Lectures List */}
      <Card className="border-0 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-slate-100 to-gray-100 border-b">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            المحاضرات التي حضرتها
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {attendances.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-muted-foreground">لم تحضر أي محاضرات بعد</p>
            </div>
          ) : (
            <div className="space-y-3">
              {attendances.map((attendance) => {
                const lecture = lectures.find((l) => l.id === attendance.lectureId)
                return (
                  <div
                    key={attendance.id}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-gray-50 rounded-lg border-l-4 border-emerald-500 hover:shadow-md transition-all"
                  >
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground">{lecture?.title}</h4>
                      <p className="text-sm text-muted-foreground">{lecture?.course}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-emerald-600">+3 نقاط</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(attendance.timestamp).toLocaleDateString("ar-SA")}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
