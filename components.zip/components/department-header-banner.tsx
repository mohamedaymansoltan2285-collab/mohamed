"use client"

interface DepartmentHeaderBannerProps {
  title: string
  icon: string
  description: string
  color: string
  count: number
}

export default function DepartmentHeaderBanner({
  title,
  icon,
  description,
  color,
  count,
}: DepartmentHeaderBannerProps) {
  return (
    <div className={`bg-gradient-to-r ${color} rounded-2xl p-8 md:p-12 shadow-2xl overflow-hidden relative`}>
      {/* Decorative background elements */}
      <div className="absolute -top-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-white/5 rounded-full blur-2xl"></div>

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="text-7xl mb-4 inline-block">{icon}</div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-2 text-balance">{title}</h1>
            <p className="text-white/90 text-lg md:text-xl max-w-2xl">{description}</p>
          </div>
          <div className="bg-white/20 backdrop-blur-md rounded-2xl px-6 py-4 text-right">
            <p className="text-white/80 text-sm font-semibold mb-1">عدد الطلاب</p>
            <p className="text-5xl font-bold text-white">{count}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
