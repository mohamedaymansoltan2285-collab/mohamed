"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, onSnapshot } from "firebase/firestore"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Clock, AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import type { StudentRequest } from "@/types/request"

interface StudentRequestsSectionProps {
  studentId: string
}

export default function StudentRequestsSection({ studentId }: StudentRequestsSectionProps) {
  const [requests, setRequests] = useState<StudentRequest[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!studentId) return

    const q = query(collection(db, "student_requests"), where("studentId", "==", studentId))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const requestList: StudentRequest[] = []
        snapshot.forEach((doc) => {
          const data = doc.data()
          requestList.push({
            id: doc.id,
            studentId: data.studentId,
            studentName: data.studentName,
            studentCode: data.studentCode,
            studentDepartment: data.studentDepartment,
            studentImage: data.studentImage,
            description: data.description,
            imageUrl: data.imageUrl,
            status: data.status || "pending",
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          } as StudentRequest)
        })
        // Sort by newest first
        requestList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        setRequests(requestList)
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching requests:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [studentId])

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<
      string,
      {
        label: string
        color: string
        icon: React.ComponentType<{ className?: string }>
        bgColor: string
      }
    > = {
      pending: {
        label: "قيد الانتظار",
        color: "bg-yellow-100 text-yellow-800",
        icon: Clock,
        bgColor: "bg-yellow-50",
      },
      reviewed: {
        label: "تم المراجعة",
        color: "bg-blue-100 text-blue-800",
        icon: AlertCircle,
        bgColor: "bg-blue-50",
      },
      resolved: {
        label: "تم الحل",
        color: "bg-green-100 text-green-800",
        icon: CheckCircle,
        bgColor: "bg-green-50",
      },
    }
    const config = statusConfig[status] || statusConfig.pending
    const Icon = config.icon
    return {
      ...config,
      icon: Icon,
    }
  }

  if (loading) {
    return (
      <Card className="shadow-sm border-border/40">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-green-600" />
            الطلبات المرسلة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center py-8">
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
              <p className="text-sm text-muted-foreground">جاري تحميل الطلبات...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="shadow-sm border-border/40">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-green-600" />
          الطلبات المرسلة
        </CardTitle>
        <CardDescription>جميع الطلبات والشكاوى التي أرسلتها لشؤون الطلاب</CardDescription>
      </CardHeader>
      <CardContent>
        {requests.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
            <p className="text-muted-foreground font-medium">لم تقم بإرسال أي طلبات حتى الآن</p>
            <p className="text-sm text-muted-foreground mt-1">يمكنك إرسال طلب باستخدام الزر أعلاه</p>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.map((request) => {
              const statusConfig = getStatusBadge(request.status)
              const StatusIcon = statusConfig.icon
              return (
                <div
                  key={request.id}
                  className={`p-4 rounded-lg border border-gray-200 ${statusConfig.bgColor} hover:shadow-md transition-shadow`}
                >
                  {/* Header with Status */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-foreground flex items-center gap-2">
                        <FileText className="w-4 h-4 text-green-600" />
                        طلب #{request.id.slice(-6).toUpperCase()}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        تاريخ الإرسال:{" "}
                        {new Date(request.createdAt).toLocaleDateString("ar-SA", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                        {" الساعة "}
                        {new Date(request.createdAt).toLocaleTimeString("ar-SA", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <Badge className={statusConfig.color}>
                      <StatusIcon className="w-3 h-3 ml-1" />
                      {statusConfig.label}
                    </Badge>
                  </div>

                  {/* Description */}
                  <div className="mb-3 p-3 bg-white/60 rounded-lg border border-gray-100">
                    <p className="text-sm leading-relaxed text-foreground">{request.description}</p>
                  </div>

                  {/* Attached Image */}
                  {request.imageUrl && (
                    <div className="mb-3">
                      <p className="text-xs font-semibold text-muted-foreground mb-2">الصورة المرفقة:</p>
                      <img
                        src={request.imageUrl || "/placeholder.svg"}
                        alt="الصورة المرفقة"
                        className="max-w-xs h-auto rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                      />
                    </div>
                  )}

                  {/* Last Update Info */}
                  {request.updatedAt && (
                    <p className="text-xs text-muted-foreground">
                      آخر تحديث:{" "}
                      {new Date(request.updatedAt).toLocaleDateString("ar-SA", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {/* Summary Stats */}
        {requests.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-200 grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="text-2xl font-bold text-yellow-700">
                {requests.filter((r) => r.status === "pending").length}
              </p>
              <p className="text-xs text-yellow-600 mt-1">قيد الانتظار</p>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-2xl font-bold text-blue-700">
                {requests.filter((r) => r.status === "reviewed").length}
              </p>
              <p className="text-xs text-blue-600 mt-1">تم مراجعتها</p>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg border border-green-200">
              <p className="text-2xl font-bold text-green-700">
                {requests.filter((r) => r.status === "resolved").length}
              </p>
              <p className="text-xs text-green-600 mt-1">تم حلها</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
