"use client"

import { Card } from "@/components/ui/card"
import { Calendar, BarChart3, Star } from "lucide-react"

export default function EmployeeStats({ employee }: { employee: any }) {
  const startDate = new Date(employee.joinDate)
  const today = new Date()
  const daysWorked = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 3600 * 24))
  const monthsWorked = Math.floor(daysWorked / 30)

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Days Worked Card */}
      <Card className="p-8 shadow-lg hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-100 group-hover:from-blue-100 group-hover:to-cyan-100 transition-all duration-300"></div>
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <p className="text-muted-foreground text-sm font-medium mb-2">عدد أيام العمل</p>
              <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-2">
                {daysWorked}
              </p>
              <p className="text-sm text-blue-600 font-semibold">يوم من التطور والنمو</p>
            </div>
            <div className="p-4 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl shadow-lg group-hover:shadow-xl transition-all group-hover:scale-110">
              <Calendar className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </Card>

      {/* Months Worked Card */}
      <Card className="p-8 shadow-lg hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-indigo-50 to-purple-100 group-hover:from-purple-100 group-hover:to-indigo-100 transition-all duration-300"></div>
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <p className="text-muted-foreground text-sm font-medium mb-2">عدد الأشهر</p>
              <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent mb-2">
                {monthsWorked}
              </p>
              <p className="text-sm text-purple-600 font-semibold">شهر من الخبرة والعمل</p>
            </div>
            <div className="p-4 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-xl shadow-lg group-hover:shadow-xl transition-all group-hover:scale-110">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </Card>

      {/* Rating Card */}
      <Card className="p-8 shadow-lg hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-yellow-50 to-amber-100 group-hover:from-amber-100 group-hover:to-yellow-100 transition-all duration-300"></div>
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <p className="text-muted-foreground text-sm font-medium mb-2">التقييم</p>
              <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-600 to-yellow-600 bg-clip-text text-transparent mb-2">
                5/5
              </p>
              <p className="text-sm text-amber-600 font-semibold">أداء متميز</p>
            </div>
            <div className="p-4 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl shadow-lg group-hover:shadow-xl transition-all group-hover:scale-110">
              <Star className="w-6 h-6 text-white fill-current" />
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
