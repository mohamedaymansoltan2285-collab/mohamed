"use client"

import { useEffect, useState } from "react"
import { collection, onSnapshot, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Lecture } from "@/types/lecture"
import { Calendar, BookOpen, Code2, MapPin } from "lucide-react"
import AttendanceModal from "@/components/attendance-modal"

interface StudentLecturesListProps {
  studentId: string
  departmentId: string
}

export default function StudentLecturesList({ studentId, departmentId }: StudentLecturesListProps) {
  const [lectures, setLectures] = useState<Lecture[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedLecture, setSelectedLecture] = useState<Lecture | null>(null)
  const [showAttendanceModal, setShowAttendanceModal] = useState(false)

  useEffect(() => {
    const q = query(collection(db, "lectures"), where("departmentId", "==", departmentId))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const lecturesList: Lecture[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Lecture
          lecturesList.push({
            ...data,
            id: doc.id,
            
          })
        })
        setLectures(lecturesList.sort((a, b) => new Date(b.lectureDate).getTime() - new Date(a.lectureDate).getTime()))
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching lectures:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [departmentId])

  const handleAttendance = (lecture: Lecture) => {
    setSelectedLecture(lecture)
    setShowAttendanceModal(true)
  }

  if (loading) {
    return (
      <Card className="border-0 shadow-lg">
        <CardContent className="p-8 flex justify-center">
          <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg bg-gradient-to-r from-emerald-500 to-teal-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-3">
            <BookOpen className="w-6 h-6" />
            المحاضرات المتاحة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white opacity-90">عدد المحاضرات: {lectures.length}</p>
        </CardContent>
      </Card>

      {lectures.length === 0 ? (
        <Card className="p-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-0">
          <div className="text-center">
            <BookOpen className="w-16 h-16 text-blue-300 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium text-lg">لا توجد محاضرات في هذا القسم حتى الآن</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lectures.map((lecture) => (
            <Card
              key={lecture.id}
              className="border-0 shadow-lg hover:shadow-xl transition-all transform hover:scale-105 overflow-hidden group"
            >
              <CardHeader className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg line-clamp-2">{lecture.title}</CardTitle>
                  <span className="text-xs bg-white text-emerald-600 px-2 py-1 rounded-full font-semibold whitespace-nowrap ml-2">
                    {lecture.course}
                  </span>
                </div>
              </CardHeader>

              <CardContent className="p-4 space-y-4">
                {/* Lecture Description */}
                {lecture.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{lecture.description}</p>
                )}

                {/* Lecture Date */}
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>
                    {new Date(lecture.lectureDate).toLocaleDateString("ar-EG", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}{" "}
                    -{" "}
                    {new Date(lecture.lectureDate).toLocaleTimeString("ar-EG", {
                      hour: "2-digit",
                      minute: "2-digit",
                      hour12: true,
                    })}
                  </span>
                </div>

                {/* Location Display */}
                {lecture.location && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-red-500" />
                    <span>{lecture.location}</span>
                  </div>
                )}

                {/* Attendance Methods */}
                <div className="bg-gray-50 p-3 rounded-lg space-y-2">
                  <p className="text-xs font-semibold text-gray-600">طرق التحضير:</p>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-green-600" />
                    <span className="text-gray-600">تحديد الموقع (400 متر)</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Code2 className="w-4 h-4 text-blue-600" />
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-semibold">
                      يتطلب كود من المحاضر
                    </span>
                  </div>
                </div>

                {/* Attendance Button */}
                <Button
                  onClick={() => handleAttendance(lecture)}
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
                >
                  تحضير
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Attendance Modal */}
      {showAttendanceModal && selectedLecture && (
        <AttendanceModal
          lecture={selectedLecture}
          studentId={studentId}
          onClose={() => {
            setShowAttendanceModal(false)
            setSelectedLecture(null)
          }}
        />
      )}
    </div>
  )
}
