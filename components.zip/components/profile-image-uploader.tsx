"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { uploadImageToImgBB } from "@/lib/imgbb-upload"
import { Camera, Check, AlertCircle, Loader } from "lucide-react"

interface ProfileImageUploaderProps {
  employeeName: string
  currentImageUrl?: string
  onImageUpload: (imageUrl: string) => Promise<void>
  canUpload?: boolean
  disabled?: boolean
}

export default function ProfileImageUploader({
  employeeName,
  currentImageUrl,
  onImageUpload,
  canUpload = true,
  disabled = false,
}: ProfileImageUploaderProps) {
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const initials = employeeName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      setError("يرجى اختيار صورة فقط")
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("حجم الصورة يجب أن لا يتجاوز 5 ميجابايت")
      return
    }

    setError(null)
    setSuccess(false)
    setUploading(true)

    try {
      const imageUrl = await uploadImageToImgBB(file)
      await onImageUpload(imageUrl)

      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err: any) {
      console.error("[v0] Error uploading image:", err)
      setError(err.message || "حدث خطأ أثناء رفع الصورة")
    } finally {
      setUploading(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  return (
    <div className="flex justify-center mb-8">
      <div className="relative inline-block group">
        {/* صورة الملف الشخصي الكبيرة والمركزية */}
        <Avatar className="w-40 h-40 border-4 border-background shadow-2xl ring-4 ring-blue-100 group-hover:ring-blue-200 transition-all duration-300">
          <AvatarImage src={currentImageUrl || "/placeholder.svg"} alt={employeeName} />
          <AvatarFallback className="text-5xl font-bold bg-gradient-to-br from-blue-500 to-indigo-600 text-white">
            {initials}
          </AvatarFallback>
        </Avatar>

        {canUpload && !uploading && (
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled || uploading}
            className="absolute bottom-2 left-2 p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-xl transition-all duration-300 hover:scale-125 hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
            title="تحديث الصورة الشخصية"
            aria-label="تحديث الصورة الشخصية"
          >
            <Camera className="w-6 h-6" />
          </button>
        )}

        {canUpload && uploading && (
          <div className="absolute bottom-2 left-2 p-3 bg-blue-600 text-white rounded-full shadow-xl">
            <Loader className="w-6 h-6 animate-spin" />
          </div>
        )}

        {success && (
          <div className="absolute bottom-2 left-2 p-3 bg-green-500 text-white rounded-full shadow-xl animate-in fade-in">
            <Check className="w-6 h-6" />
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          disabled={disabled || uploading || !canUpload}
          className="hidden"
          aria-label="تحميل صورة الملف الشخصي"
        />
      </div>

      <div className="absolute top-full mt-4 left-1/2 -translate-x-1/2 w-80 space-y-3">
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-sm animate-in fade-in">
            <Check className="w-4 h-4 flex-shrink-0" />
            <span>تم تحديث الصورة بنجاح</span>
          </div>
        )}
      </div>
    </div>
  )
}
