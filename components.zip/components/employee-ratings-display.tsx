"use client"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, onSnapshot } from "firebase/firestore"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, TrendingUp, Calendar, Award, Clock } from "lucide-react"

// تحديث نوع Criterion ليشمل docId اختياريًا
export interface Criterion {
  id: string
  text: string
  departments: string[]
  docId?: string
}

export interface EmployeeRating {
  id: string
  employeeId: string
  criterionId: string
  rating: number
  date: string
  timeSlot?: "morning" | "evening"
}

interface EmployeeRatingsDisplayProps {
  employeeId: string
  departmentId: string
}

export default function EmployeeRatingsDisplay({ employeeId, departmentId }: EmployeeRatingsDisplayProps) {
  const [criteria, setCriteria] = useState<Criterion[]>([])
  const [ratings, setRatings] = useState<EmployeeRating[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const criteriaUnsubscribe = onSnapshot(
      collection(db, "criteria"),
      (snapshot) => {
        const criteriaList: Criterion[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Omit<Criterion, "docId">
          if (data.departments && data.departments.includes(departmentId)) {
            criteriaList.push({ ...data, docId: doc.id }) // docId اختياري الآن
          }
        })
        setCriteria(criteriaList)
      },
      (err) => {
        console.log("Criteria fetch error:", err)
        setCriteria([])
      }
    )

    const ratingsUnsubscribe = onSnapshot(
      query(collection(db, "employeeRatings"), where("employeeId", "==", employeeId)),
      (snapshot) => {
        const ratingsList: EmployeeRating[] = []
        snapshot.forEach((doc) => {
          ratingsList.push({ id: doc.id, ...doc.data() } as EmployeeRating)
        })
        setRatings(ratingsList)
        setLoading(false)
      },
      (err) => {
        console.log("Ratings fetch error:", err)
        setRatings([])
        setLoading(false)
      }
    )

    return () => {
      criteriaUnsubscribe()
      ratingsUnsubscribe()
    }
  }, [employeeId, departmentId])

  const getCriterionRatings = (criterionId: string) =>
    ratings.filter((r) => r.criterionId === criterionId)

  const getAverageRating = (criterionId: string): number => {
    const criterionRatings = getCriterionRatings(criterionId)
    if (criterionRatings.length === 0) return 0
    const sum = criterionRatings.reduce((acc, r) => acc + r.rating, 0)
    return sum / criterionRatings.length
  }

  const getLatestRating = (criterionId: string): EmployeeRating | undefined => {
    const criterionRatings = getCriterionRatings(criterionId)
    return criterionRatings.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
  }

  const getTimeSlotLabel = (timeSlot: "morning" | "evening" | undefined): string =>
    timeSlot === "morning"
      ? "صباحي (10 ص - 3 م)"
      : timeSlot === "evening"
      ? "مسائي (3 م - 9 م)"
      : "غير محدد"

  if (loading)
    return (
      <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-slate-100">
        <CardContent className="p-8 text-center">
          <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل التقييمات...</p>
        </CardContent>
      </Card>
    )

  if (criteria.length === 0 && ratings.length === 0)
    return (
      <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-50 to-orange-50">
        <CardContent className="p-8 text-center">
          <Award className="w-12 h-12 text-amber-400 mx-auto mb-4 opacity-50" />
          <p className="text-muted-foreground font-medium">لم تتم إضافة معايير تقييم لقسمك بعد</p>
        </CardContent>
      </Card>
    )

  const overallAverage =
    criteria.length > 0
      ? criteria.reduce((sum, c) => sum + getAverageRating(c.id), 0) / criteria.length
      : 0

  return (
    <div className="space-y-6">
      {/* Overall Rating Summary */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-400 rounded-full mix-blend-multiply blur-xl"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-400 rounded-full mix-blend-multiply blur-xl"></div>
        </div>
        <CardHeader className="relative pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                متوسط التقييم الإجمالي
              </CardTitle>
              <CardDescription>معدل الأداء الكلي خلال الفترة</CardDescription>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold text-indigo-600">{overallAverage.toFixed(1)}</div>
              <div className="flex gap-1 justify-end mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= Math.round(overallAverage) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Individual Criteria Ratings */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Award className="w-5 h-5 text-indigo-600" />
          تفاصيل التقييمات
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {criteria.map((criterion) => {
            const criterionRatings = getCriterionRatings(criterion.id)
            const average = getAverageRating(criterion.id)
            const latest = getLatestRating(criterion.id)

            return (
              <Card key={criterion.id} className="border-0 shadow-md hover:shadow-lg transition-shadow overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-base line-clamp-2">{criterion.text}</CardTitle>
                      <Badge className="mt-2 bg-indigo-100 text-indigo-700 border-indigo-300">
                        {criterionRatings.length} تقييم
                      </Badge>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-2xl font-bold text-indigo-600">{average.toFixed(1)}</div>
                      <div className="flex gap-0.5 justify-end mt-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= Math.round(average) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </CardHeader>

                {latest && (
                  <CardContent className="space-y-2 pt-0">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>آخر تقييم: {new Date(latest.date).toLocaleDateString("ar-EG")}</span>
                    </div>
                    {latest.timeSlot && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>الفترة: {getTimeSlotLabel(latest.timeSlot)}</span>
                      </div>
                    )}
                    <div className="flex gap-1 pt-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${
                            star <= latest.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </CardContent>
                )}
              </Card>
            )
          })}
        </div>
      </div>

      {/* Recent Ratings Timeline */}
      {ratings.length > 0 && (
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>آخر التقييمات</CardTitle>
            <CardDescription>سجل التقييمات الحديثة مع الفترات الزمنية</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {ratings
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 10)
                .map((rating, idx) => {
                  const criterion = criteria.find((c) => c.id === rating.criterionId)
                  return (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg border border-border"
                    >
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium text-foreground line-clamp-1">
                          {criterion?.text || "معيار محذوف"}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(rating.date).toLocaleDateString("ar-EG")}</span>
                          {rating.timeSlot && (
                            <>
                              <Clock className="w-3 h-3 mr-1" />
                              <span>{getTimeSlotLabel(rating.timeSlot)}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= rating.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )
                })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
