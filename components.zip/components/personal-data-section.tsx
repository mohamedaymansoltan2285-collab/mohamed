"use client"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, query, onSnapshot, doc, updateDoc } from "firebase/firestore"
import PersonalDataCard from "./personal-data-card"
import PersonalDataModal from "./personal-data-modal"

interface PersonalDataSectionProps {
  employeeId: string
  canEdit?: boolean
}

export default function PersonalDataSection({ employeeId, canEdit = true }: PersonalDataSectionProps) {
  const [personalData, setPersonalData] = useState<Record<string, any>>({})
  const [allEmployees, setAllEmployees] = useState<any[]>([])
  const [selectedField, setSelectedField] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const fields = [
    { key: "favoriteVacationDay", label: "اليوم المفضل للأجازة" },
    { key: "favoritePerson", label: "الشخص المفضل في العمل" },
    { key: "favoriteFriends", label: "الأصدقاء المفضلين" },
    { key: "suggestions", label: "اقتراحاتك" },
    { key: "personalNotes", label: "الملاحظات الشخصية" },
    { key: "preferredDepartment", label: "القسم المفضل" },
    { key: "favoriteChallengeType", label: "نوع التحدي المفضل" },
    { key: "educationLevel", label: "المستوى التعليمي" },
    { key: "favoriteQuote", label: "عبارة مفضلة" },
  ]

  useEffect(() => {
    // Fetch all employees for dropdowns
    const q = query(collection(db, "employees"))
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const employees = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setAllEmployees(employees)
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    // Fetch personal data for this employee
    const docRef = doc(db, "employees", employeeId)
    const unsubscribe = onSnapshot(docRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data()
        const personalDataObj: Record<string, any> = {}
        fields.forEach((field) => {
          personalDataObj[field.key] = data[field.key] || null
        })
        setPersonalData(personalDataObj)
      }
    })

    return () => unsubscribe()
  }, [employeeId, fields])

  const handleSaveField = async (fieldKey: string, value: any) => {
    try {
      setIsLoading(true)
      const docRef = doc(db, "employees", employeeId)
      await updateDoc(docRef, {
        [fieldKey]: value,
        updatedAt: new Date().toISOString(),
      })
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 2000)
    } catch (error) {
      console.error("[v0] Error saving personal data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">البيانات الشخصية الإضافية</h2>
        <p className="text-gray-600">
          {canEdit ? "أكمل معلوماتك الشخصية لإنشاء ملفك الشخصي" : "معلومات شخصية إضافية للموظف"}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {fields.map((field, index) => (
          <PersonalDataCard
            key={field.key}
            fieldType={field.key}
            label={field.label}
            value={personalData[field.key]}
            onClick={() => canEdit && setSelectedField(field.key)}
            canEdit={canEdit}
            allEmployees={allEmployees}
          />
        ))}
      </div>

      {selectedField && (
        <PersonalDataModal
          isOpen={!!selectedField}
          onClose={() => setSelectedField(null)}
          fieldType={selectedField}
          currentValue={personalData[selectedField]}
          allEmployees={allEmployees}
          onSave={(value) => handleSaveField(selectedField, value)}
          isLoading={isLoading}
          canEdit={canEdit}
        />
      )}
    </div>
  )
}
