"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

interface DepartmentLink {
  label: string
  href: string
  icon: string
  color: string
  description: string
}

interface DepartmentNavigationGridProps {
  departments: DepartmentLink[]
}

export default function DepartmentNavigationGrid({ departments }: DepartmentNavigationGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {departments.map((dept) => (
        <Link key={dept.href} href={dept.href}>
          <Card
            className={`h-full p-6 cursor-pointer border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-gradient-to-br ${dept.color} group`}
          >
            <div className="h-full flex flex-col justify-between">
              <div>
                <div className="text-5xl mb-4 inline-block group-hover:scale-110 transition-transform duration-300">
                  {dept.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{dept.label}</h3>
                <p className="text-white/80 text-sm">{dept.description}</p>
              </div>
              <Button className="mt-4 w-full bg-white text-current hover:bg-white/90 transition-all duration-300 flex items-center justify-center gap-2">
                عرض الموظفين
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  )
}
