"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { auth, db } from "@/lib/firebase"
import { onAuthStateChanged, signOut, type User } from "firebase/auth"
import { doc, getDoc, setDoc, collection, query, where, getDocs } from "firebase/firestore"

interface AuthContextType {
  user: User | null
  loading: boolean
  userRole: "admin" | "employee" | null
  employeeCode: string | null
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [userRole, setUserRole] = useState<"admin" | "employee" | null>(null)
  const [employeeCode, setEmployeeCode] = useState<string | null>(null)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser)
      console.log("[v0] Auth state changed, user:", currentUser?.email)

      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, "users", currentUser.uid))

          if (userDoc.exists()) {
            const role = userDoc.data().role as "admin" | "employee"
            setUserRole(role)
            console.log("[v0] User role from users collection:", role)
          } else {
            const employeeQuery = query(collection(db, "employees"), where("email", "==", currentUser.email))
            const employeeSnapshot = await getDocs(employeeQuery)

            if (employeeSnapshot.docs.length > 0) {
              const employeeData = employeeSnapshot.docs[0].data()
              setUserRole("employee")
              setEmployeeCode(employeeData.employeeCode)
              console.log("[v0] User is employee, code:", employeeData.employeeCode)
            } else {
              const userData = {
                uid: currentUser.uid,
                email: currentUser.email,
                role: "admin",
                createdAt: new Date().toISOString(),
              }
              await setDoc(doc(db, "users", currentUser.uid), userData)
              setUserRole("admin")
              console.log("[v0] User role set to admin")
            }
          }
        } catch (error) {
          console.error("[v0] Error managing user data:", error)
          setUserRole("admin")
        }
      } else {
        setUserRole(null)
        setEmployeeCode(null)
      }

      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const logout = async () => {
    try {
      await signOut(auth)
      setUser(null)
      setUserRole(null)
      setEmployeeCode(null)
      localStorage.removeItem("employeeCode")
    } catch (error) {
      console.error("[v0] Error logging out:", error)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, userRole, employeeCode, logout }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
