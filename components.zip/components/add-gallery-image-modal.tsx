"use client"

import type React from "react"

import { useState } from "react"
import { db } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Upload, LinkIcon, Loader2, ImageIcon } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface AddGalleryImageModalProps {
  onClose: () => void
}

export default function AddGalleryImageModal({ onClose }: AddGalleryImageModalProps) {
  const [imageUrl, setImageUrl] = useState("")
  const [description, setDescription] = useState("")
  const [uploading, setUploading] = useState(false)
  const [uploadingFile, setUploadingFile] = useState(false)

  const handleUrlSubmit = async () => {
    if (!imageUrl.trim()) return

    setUploading(true)
    try {
      await addDoc(collection(db, "gallery"), {
        imageUrl: imageUrl.trim(),
        description: description.trim(),
        uploadedAt: new Date().toISOString(),
      })
      onClose()
    } catch (error) {
      console.error("[v0] Error adding image:", error)
      alert("حدث خطأ أثناء إضافة الصورة")
    } finally {
      setUploading(false)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingFile(true)
    const formData = new FormData()
    formData.append("image", file)

    try {
      const response = await fetch(`https://api.imgbb.com/1/upload?key=a2ea630cce2c301d4e273795d2566796`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()
      if (data.success) {
        await addDoc(collection(db, "gallery"), {
          imageUrl: data.data.url,
          description: description.trim(),
          uploadedAt: new Date().toISOString(),
        })
        onClose()
      } else {
        alert("فشل رفع الصورة")
      }
    } catch (error) {
      console.error("[v0] Error uploading image:", error)
      alert("حدث خطأ أثناء رفع الصورة")
    } finally {
      setUploadingFile(false)
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", duration: 0.5 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <Card className="border-0 shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <ImageIcon className="w-6 h-6" />
                    إضافة صورة جديدة
                  </CardTitle>
                  <CardDescription className="text-blue-100">
                    أضف صورة للمعرض من خلال رفع ملف أو إدخال رابط
                  </CardDescription>
                </div>
                <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* File Upload Section */}
              <div className="space-y-3">
                <Label htmlFor="file-upload" className="text-base font-semibold">
                  رفع صورة من الجهاز
                </Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors">
                  <input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={uploadingFile || uploading}
                    className="hidden"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-3">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-gray-700">انقر لاختيار صورة</p>
                      <p className="text-sm text-gray-500 mt-1">PNG, JPG, GIF حتى 10MB</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-white text-gray-500">أو</span>
                </div>
              </div>

              {/* URL Input Section */}
              <div className="space-y-3">
                <Label htmlFor="image-url" className="text-base font-semibold">
                  رابط الصورة من الإنترنت
                </Label>
                <div className="relative">
                  <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="image-url"
                    type="url"
                    placeholder="https://example.com/image.jpg"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    disabled={uploading || uploadingFile}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Description Input */}
              <div className="space-y-3">
                <Label htmlFor="description" className="text-base font-semibold">
                  وصف الصورة (اختياري)
                </Label>
                <Textarea
                  id="description"
                  placeholder="أضف وصفاً للصورة..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={uploading || uploadingFile}
                  rows={3}
                  className="resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleUrlSubmit}
                  disabled={!imageUrl.trim() || uploading || uploadingFile}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  {uploading || uploadingFile ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الإضافة...
                    </>
                  ) : (
                    "إضافة الصورة"
                  )}
                </Button>
                <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
                  إلغاء
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
