"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, BarChart3, Users, ClipboardCheck, ImageIcon, FileText } from "lucide-react"
import { cn } from "@/lib/utils"

export default function AdminNavigation() {
  const pathname = usePathname()

  const navItems = [
    {
      href: "/admin/dashboard",
      label: "لوحة التحكم",
      icon: LayoutDashboard,
    },
    {
      href: "/admin/analytics",
      label: "التحليلات",
      icon: BarChart3,
    },
    {
      href: "/admin/employees",
      label: "الطلاب",
      icon: Users,
    },
    {
      href: "/admin/requests",
      label: "الطلبات",
      icon: FileText,
    },
    {
      href: "/admin/criteria",
      label: "المعايير",
      icon: ClipboardCheck,
    },
    {
      href: "/admin/gallery",
      label: "معرض الصور",
      icon: ImageIcon,
    },
  ]

  return (
    <nav className="bg-card border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex overflow-x-auto gap-1 py-4">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-md transition-colors whitespace-nowrap",
                  isActive ? "bg-accent text-accent-foreground" : "text-foreground hover:bg-muted",
                )}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
