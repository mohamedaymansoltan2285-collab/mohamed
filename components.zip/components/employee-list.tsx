"use client"

import type { Employee } from "@/types/employee"

import { Button } from "@/components/ui/button"
import { Trash2, Edit2 } from "lucide-react"
import { useState } from "react"
import EditEmployeeModal from "./edit-employee-modal"

interface EmployeeListProps {
  employees: Employee[]
  onDelete: (id: string) => void
  onUpdate: (id: string, data: Partial<Employee>) => void
}

export default function EmployeeList({ employees, onDelete, onUpdate }: EmployeeListProps) {
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)

  if (employees.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">لا توجد بيانات موظفين</p>
      </div>
    )
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-right py-3 px-4 font-semibold">الاسم</th>
              <th className="text-right py-3 px-4 font-semibold">البريد الإلكتروني</th>
              <th className="text-right py-3 px-4 font-semibold">القسم</th>
              <th className="text-right py-3 px-4 font-semibold">رقم الهاتف</th>
              <th className="text-right py-3 px-4 font-semibold">تاريخ الانضمام</th>
              <th className="text-right py-3 px-4 font-semibold">الحالة</th>
              <th className="text-right py-3 px-4 font-semibold">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.id} className="border-b border-border hover:bg-muted/50">
                <td className="py-3 px-4">{employee.fullName}</td>
                <td className="py-3 px-4 text-muted-foreground">{employee.email}</td>
                <td className="py-3 px-4">{employee.department || "-"}</td>
                <td className="py-3 px-4">{employee.phone || "-"}</td>
                <td className="py-3 px-4">
                  {employee.joinDate ? new Date(employee.joinDate).toLocaleDateString("ar-SA") : "-"}
                </td>
                <td className="py-3 px-4">
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      employee.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                    }`}
                  >
                    {employee.status === "active" ? "نشيط" : "غير نشيط"}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={() => setEditingEmployee(employee)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => onDelete(employee.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editingEmployee && (
        <EditEmployeeModal
          employee={editingEmployee}
          onClose={() => setEditingEmployee(null)}
          onSave={(updatedData) => {
            onUpdate(editingEmployee.id, updatedData)
            setEditingEmployee(null)
          }}
        />
      )}
    </>
  )
}
