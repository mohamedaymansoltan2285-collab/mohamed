"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { collection, addDoc } from "firebase/firestore"
import { db, auth } from "@/lib/firebase"
import { createUserWithEmailAndPassword } from "firebase/auth"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function EmployeeForm({ initialData, employeeId }: any) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: initialData?.name || "",
    age: initialData?.age || "",
    email: initialData?.email || "",
    phone: initialData?.phone || "",
    emergencyPhone: initialData?.emergencyPhone || "",
    address: initialData?.address || "",
    maritalStatus: initialData?.maritalStatus || "single",
    gender: initialData?.gender || "male",
    religion: initialData?.religion || "",
    category: initialData?.category || "",
    joinDate: initialData?.joinDate || new Date().toISOString().split("T")[0],
  })

  const generateUniqueCode = () => {
    return `EMP-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
  }

  const handleChange = (e: any) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const uniqueCode = generateUniqueCode()
      const employeeEmail = `emp_${uniqueCode}@zawagyapp.com`
      const defaultPassword = "emp123456"

      // Create user in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(auth, employeeEmail, defaultPassword)

      // Add employee data to Firestore
      const employeeData = {
        ...formData,
        uniqueCode,
        email: formData.email,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const docRef = await addDoc(collection(db, "employees"), employeeData)

      alert(`تم إنشاء الموظف بنجاح!\n\nالكود: ${uniqueCode}\nكلمة المرور: ${defaultPassword}`)
      router.push("/admin/employees")
    } catch (error: any) {
      console.error("Error adding employee:", error)
      alert("حدث خطأ في إضافة الموظف. يرجى المحاولة مرة أخرى.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="p-8 shadow-lg">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">الاسم الكامل *</label>
            <Input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="أدخل اسم الموظف"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">العمر *</label>
            <Input
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
              placeholder="أدخل العمر"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">البريد الإلكتروني *</label>
            <Input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="الإيميل"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">رقم الهاتف *</label>
            <Input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="رقم الهاتف"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">رقم الطوارئ *</label>
            <Input
              type="tel"
              name="emergencyPhone"
              value={formData.emergencyPhone}
              onChange={handleChange}
              placeholder="رقم الطوارئ"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">الديانة</label>
            <Input
              type="text"
              name="religion"
              value={formData.religion}
              onChange={handleChange}
              placeholder="الديانة"
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-foreground mb-2">العنوان *</label>
            <Input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="العنوان الكامل"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">الحالة الاجتماعية *</label>
            <select
              name="maritalStatus"
              value={formData.maritalStatus}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 bg-muted-background border border-border/50 rounded-lg focus:outline-none focus:border-accent"
            >
              <option value="single">أعزب</option>
              <option value="married">متزوج</option>
              <option value="divorced">مطلق</option>
              <option value="widowed">أرمل</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">النوع *</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 bg-muted-background border border-border/50 rounded-lg focus:outline-none focus:border-accent"
            >
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
              <option value="other">أخرى</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">الفئة *</label>
            <Input
              type="text"
              name="category"
              value={formData.category}
              onChange={handleChange}
              placeholder="الفئة (موارد بشرية، إدارة، إلخ)"
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">تاريخ التعيين *</label>
            <Input
              type="date"
              name="joinDate"
              value={formData.joinDate}
              onChange={handleChange}
              required
              className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
            />
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          <Button
            type="submit"
            disabled={loading}
            className="bg-accent hover:bg-accent-hover text-white font-medium flex-1"
          >
            {loading ? "جاري الحفظ..." : "حفظ البيانات"}
          </Button>
          <Button
            type="button"
            onClick={() => router.back()}
            className="bg-muted-background text-foreground hover:bg-border flex-1"
          >
            إلغاء
          </Button>
        </div>
      </form>
    </Card>
  )
}
