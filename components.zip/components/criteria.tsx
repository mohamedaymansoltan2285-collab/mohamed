"use client"

export default function Criteria() {
  return null
}
