"use client"

import type React from "react"
import { useState } from "react"
import { db } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Upload, Loader2, FileText } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import type { Employee } from "@/types/employee"

interface SendRequestModalProps {
  onClose: () => void
  employee: Employee
  employeeId: string
}

export default function SendRequestModal({ onClose, employee, employeeId }: SendRequestModalProps) {
  const [description, setDescription] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [uploading, setUploading] = useState(false)
  const [uploadingFile, setUploadingFile] = useState(false)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingFile(true)
    const formData = new FormData()
    formData.append("image", file)

    try {
      const response = await fetch(`https://api.imgbb.com/1/upload?key=a2ea630cce2c301d4e273795d2566796`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()
      if (data.success) {
        setImageUrl(data.data.url)
      } else {
        alert("فشل رفع الصورة")
      }
    } catch (error) {
      console.error("[v0] Error uploading image:", error)
      alert("حدث خطأ أثناء رفع الصورة")
    } finally {
      setUploadingFile(false)
    }
  }

  const handleSubmit = async () => {
    if (!description.trim()) {
      alert("يرجى إدخال وصف الطلب")
      return
    }

    setUploading(true)
    try {
      await addDoc(collection(db, "student_requests"), {
        studentId: employeeId,
        studentName: employee.fullName,
        studentCode: employee.employeeCode,
        studentDepartment: employee.department,
        studentImage: employee.profileImage || null,
        description: description.trim(),
        imageUrl: imageUrl || null,
        status: "pending",
        createdAt: new Date().toISOString(),
      })

      alert("تم إرسال طلبك بنجاح")
      setDescription("")
      setImageUrl("")
      onClose()
    } catch (error) {
      console.error("[v0] Error sending request:", error)
      alert("حدث خطأ أثناء إرسال الطلب")
    } finally {
      setUploading(false)
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", duration: 0.5 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <Card className="border-0 shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <FileText className="w-6 h-6" />
                    إرسال طلب لشؤون الطلاب
                  </CardTitle>
                  <CardDescription className="text-green-100">أرسل طلبك أو شكواك أو مشكلتك للإدارة</CardDescription>
                </div>
                <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* Student Info Display */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-600">الاسم</p>
                    <p className="font-semibold">{employee.fullName}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">الرقم الكودي</p>
                    <p className="font-semibold">{employee.employeeCode}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-600">القسم</p>
                    <p className="font-semibold">{employee.department}</p>
                  </div>
                </div>
              </div>

              {/* Description Input */}
              <div className="space-y-3">
                <Label htmlFor="description" className="text-base font-semibold">
                  وصف الطلب أو الشكوى
                </Label>
                <Textarea
                  id="description"
                  placeholder="اكتب وصف مفصل لطلبك أو شكواك أو المشكلة التي تواجهها..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={uploading || uploadingFile}
                  rows={5}
                  className="resize-none"
                />
              </div>

              {/* File Upload Section */}
              <div className="space-y-3">
                <Label htmlFor="file-upload" className="text-base font-semibold">
                  رفع صورة أو ملف (اختياري)
                </Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-500 transition-colors">
                  <input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={uploadingFile || uploading}
                    className="hidden"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-2">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Upload className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700">انقر لاختيار صورة</p>
                      <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF حتى 10MB</p>
                    </div>
                  </label>
                </div>

                {imageUrl && (
                  <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-sm text-gray-600 mb-2">تم تحميل الصورة بنجاح</p>
                    <img src={imageUrl || "/placeholder.svg"} alt="المرفقة" className="max-h-32 rounded-lg" />
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleSubmit}
                  disabled={!description.trim() || uploading || uploadingFile}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                >
                  {uploading || uploadingFile ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    "إرسال الطلب"
                  )}
                </Button>
                <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
                  إلغاء
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
