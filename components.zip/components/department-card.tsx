"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Employee } from "@/types/employee"
import { Mail, Phone, Bird as ID } from "lucide-react"

interface DepartmentCardProps {
  employee: Employee
  deptColor: string
  deptIcon: string
}

export default function DepartmentCard({ employee, deptColor, deptIcon }: DepartmentCardProps) {
  return (
    <div className="group">
      <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 overflow-hidden bg-gradient-to-br from-background to-muted-background">
        <div className={`h-24 bg-gradient-to-r ${deptColor} relative overflow-hidden`}>
          <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity" />
          <div className="absolute -bottom-8 -right-8 text-6xl opacity-20 group-hover:opacity-30 transition-opacity">
            {deptIcon}
          </div>
        </div>

        <CardContent className="p-6 relative -mt-8">
          <div className="bg-background rounded-lg p-4 mb-4 shadow-sm">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="text-lg font-bold text-foreground">{employee.fullName}</h3>
                <p className="text-sm text-muted-foreground mt-1">موظف نشط</p>
              </div>
              <Badge
                variant="outline"
                className="bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 border-green-200"
              >
                نشط
              </Badge>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg p-3 mb-4 border border-blue-200">
              <p className="text-xs text-muted-foreground mb-1">الرقم الوظيفي</p>
              <p className="text-2xl font-bold text-blue-700 font-mono">{employee.employeeCode}</p>
            </div>

            <div className="space-y-2 pt-3 border-t">
              {employee.email && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span className="text-foreground truncate">{employee.email}</span>
                </div>
              )}
              {employee.phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="text-foreground">{employee.phone}</span>
                </div>
              )}
              {employee.category && (
                <div className="flex items-center gap-2 text-sm">
                  <ID className="w-4 h-4 text-muted-foreground" />
                  <span className="text-foreground">{employee.category}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
