"use client"

import type { User } from "firebase/auth"
import { Button } from "@/components/ui/button"
import { LogOut } from 'lucide-react'
import { useState } from "react"

interface AdminHeaderProps {
  user: User | null
  onLogout: () => Promise<void>
}

export default function AdminHeader({ user, onLogout }: AdminHeaderProps) {
  const [showMenu, setShowMenu] = useState(false)

  const handleLogout = async () => {
    await onLogout()
  }

  return (
    <header className="border-b border-border bg-card">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-accent-foreground font-bold">
            BTU
          </div>
          <h1 className="text-xl font-bold">نظام إدارة الطلاب</h1>
        </div>

        <div className="flex items-center gap-4">
          {user && (
            <div className="text-right">
              <p className="text-sm font-medium">{user.email}</p>
              <p className="text-xs text-muted-foreground">دكتور</p>
            </div>
          )}

          <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-2 bg-transparent">
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">تسجيل الخروج</span>
          </Button>
        </div>
      </div>
    </header>
  )
}
