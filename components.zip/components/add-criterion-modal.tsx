"use client"

import type React from "react"
import { useState } from "react"
import { db } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { X, AlertCircle, CheckCircle } from "lucide-react"
import { DEPARTMENTS } from "@/types/employee"

interface AddCriterionModalProps {
  onClose: () => void
  onCriterionAdded: () => void
}

export default function AddCriterionModal({ onClose, onCriterionAdded }: AddCriterionModalProps) {
  const [criterionText, setCriterionText] = useState("")
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const handleToggleDepartment = (department: string) => {
    setSelectedDepartments((prev) =>
      prev.includes(department) ? prev.filter((d) => d !== department) : [...prev, department],
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!criterionText.trim()) {
      setError("يجب إدخال نص المعيار")
      return
    }

    if (selectedDepartments.length === 0) {
      setError("يجب اختيار قسم واحد على الأقل")
      return
    }

    setLoading(true)

    try {
      const criterionData = {
        text: criterionText.trim(),
        departments: selectedDepartments.length > 0 ? [...selectedDepartments] : [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      console.log("[v0] Saving criterion with departments:", criterionData.departments)

      await addDoc(collection(db, "criteria"), criterionData)

      setSuccess("تم إضافة المعيار بنجاح!")
      setCriterionText("")
      setSelectedDepartments([])

      setTimeout(() => {
        onCriterionAdded()
        onClose()
      }, 1500)
    } catch (err: any) {
      setError(err?.message || "حدث خطأ في إضافة المعيار")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
      <Card className="w-full max-w-md md:max-w-lg shadow-2xl border-0 flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 md:p-6 border-b border-border bg-gradient-to-r from-indigo-50 to-blue-50 flex-shrink-0">
          <h2 className="text-base md:text-lg font-bold text-foreground">إضافة معيار جديد</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 md:space-y-6">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in flex-shrink-0">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 p-4 bg-green-50 border-2 border-green-300 rounded-lg text-green-700 text-sm animate-in fade-in flex-shrink-0">
              <CheckCircle className="w-5 h-5 flex-shrink-0" />
              <span className="font-semibold">{success}</span>
            </div>
          )}

          <div>
            <label className="block text-sm font-semibold text-foreground mb-2 md:mb-3">نص المعيار</label>
            <textarea
              value={criterionText}
              onChange={(e) => setCriterionText(e.target.value)}
              placeholder="أدخل نص المعيار (مثال: الالتزام بمواعيد العمل)"
              className="w-full px-4 py-3 border border-input rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all resize-none text-sm md:text-base"
              rows={3}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-foreground mb-3">
              اختر الأقسام المطبقة على هذا المعيار
            </label>
            <div className="grid grid-cols-2 gap-2 md:gap-3">
              {DEPARTMENTS.map((dept) => (
                <button
                  key={dept.value}
                  type="button"
                  onClick={() => handleToggleDepartment(dept.value)}
                  disabled={loading}
                  className={`flex items-center gap-2 md:gap-3 p-3 md:p-4 rounded-lg border-2 transition-all text-sm md:text-base ${
                    selectedDepartments.includes(dept.value)
                      ? "border-indigo-500 bg-indigo-50"
                      : "border-border bg-background hover:border-indigo-300"
                  } ${loading ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <input
                    type="checkbox"
                    checked={selectedDepartments.includes(dept.value)}
                    onChange={() => {}}
                    className="w-4 h-4 accent-indigo-600"
                  />
                  <span className="text-base md:text-lg">{dept.icon}</span>
                  <span className="font-medium text-foreground">{dept.label}</span>
                </button>
              ))}
            </div>
          </div>
        </form>

        <div className="flex gap-2 md:gap-3 p-4 md:p-6 border-t border-border bg-muted/30 flex-shrink-0">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={loading}
            className="flex-1 bg-transparent hover:bg-muted text-sm md:text-base"
          >
            إلغاء
          </Button>
          <Button
            type="submit"
            disabled={loading}
            onClick={handleSubmit}
            className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-sm md:text-base"
          >
            {loading ? "جاري الحفظ..." : "إضافة المعيار"}
          </Button>
        </div>
      </Card>
    </div>
  )
}
