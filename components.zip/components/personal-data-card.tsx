"use client"

import type React from "react"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Heart,
  Users,
  Lightbulb,
  BookOpen,
  Quote,
  Building2,
  Trophy,
  Calendar,
  MessageSquare,
  Edit2,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface PersonalDataCardProps {
  fieldType: string
  label: string
  value: any
  onClick: () => void
  canEdit?: boolean
  allEmployees?: any[]
}

export default function PersonalDataCard({
  fieldType,
  label,
  value,
  onClick,
  canEdit = true,
  allEmployees = [],
}: PersonalDataCardProps) {
  const getIcon = (field: string) => {
    const icons: Record<string, React.ReactNode> = {
      favoriteVacationDay: <Calendar className="w-5 h-5" />,
      favoritePerson: <Heart className="w-5 h-5" />,
      favoriteFriends: <Users className="w-5 h-5" />,
      suggestions: <Lightbulb className="w-5 h-5" />,
      personalNotes: <MessageSquare className="w-5 h-5" />,
      preferredDepartment: <Building2 className="w-5 h-5" />,
      favoriteChallengeType: <Trophy className="w-5 h-5" />,
      educationLevel: <BookOpen className="w-5 h-5" />,
      favoriteQuote: <Quote className="w-5 h-5" />,
    }
    return icons[field] || <Lightbulb className="w-5 h-5" />
  }

  const getColor = (index: number) => {
    const colors = [
      "from-blue-50 hover:from-blue-100 border-blue-200",
      "from-purple-50 hover:from-purple-100 border-purple-200",
      "from-green-50 hover:from-green-100 border-green-200",
      "from-amber-50 hover:from-amber-100 border-amber-200",
      "from-pink-50 hover:from-pink-100 border-pink-200",
      "from-indigo-50 hover:from-indigo-100 border-indigo-200",
      "from-teal-50 hover:from-teal-100 border-teal-200",
      "from-orange-50 hover:from-orange-100 border-orange-200",
      "from-cyan-50 hover:from-cyan-100 border-cyan-200",
    ]
    return colors[index % colors.length]
  }

  const formatValue = () => {
    if (!value) return "لم يتم إدخال البيانات"

    if (fieldType === "favoriteFriends" && Array.isArray(value)) {
      if (value.length === 0) return "لم يتم اختيار أحد"
      return value
        .map((id: string) => {
          const emp = allEmployees.find((e) => e.id === id)
          return emp?.fullName
        })
        .join(", ")
    }

    if (fieldType === "educationLevel" && typeof value === "object") {
      return value.level
        ? `${value.level}${value.institution ? ` - ${value.institution}` : ""}`
        : "لم يتم إدخال البيانات"
    }

    if (typeof value === "string" && value.length > 60) {
      return value.substring(0, 60) + "..."
    }

    return value
  }

  // ✅ بديل Object.keys لتجنب خطأ TS7015
  const fieldIndexMap: Record<string, number> = {
    favoriteVacationDay: 0,
    favoritePerson: 1,
    favoriteFriends: 2,
    suggestions: 3,
    personalNotes: 4,
    preferredDepartment: 5,
    favoriteChallengeType: 6,
    educationLevel: 7,
    favoriteQuote: 8,
  }

  const colorClass = getColor(fieldIndexMap[fieldType] ?? 0)

  return (
    <Card
      onClick={onClick}
      className={cn(
        "cursor-pointer transition-all duration-300 transform hover:shadow-lg hover:scale-102 border-2 bg-gradient-to-br",
        colorClass,
        !canEdit && "opacity-75 cursor-default hover:shadow-md hover:scale-100",
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-start gap-2 flex-1">
            <div className="text-blue-600 mt-1 flex-shrink-0">{getIcon(fieldType)}</div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-foreground">{label}</h3>
              <p className="text-xs text-gray-500 mt-1">{formatValue()}</p>
            </div>
          </div>
          {canEdit && (
            <Edit2 className="w-4 h-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
          )}
        </div>

        {!value && (
          <Badge variant="outline" className="text-xs">
            {canEdit ? "اضغط للإضافة" : "لا توجد بيانات"}
          </Badge>
        )}
      </CardContent>
    </Card>
  )
}
