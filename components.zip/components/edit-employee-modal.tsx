"use client"

import type React from "react"

import { useState } from "react"
import type { Employee } from "@/types/employee"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

import { Card } from "@/components/ui/card"
import { X } from "lucide-react"

interface EditEmployeeModalProps {
  employee: Employee
  onClose: () => void
  onSave: (data: Partial<Employee>) => void
}

export default function EditEmployeeModal({ employee, onClose, onSave }: EditEmployeeModalProps) {
  const [formData, setFormData] = useState({
    fullName: employee.fullName,
    phone: employee.phone,
    department: employee.department,
    status: employee.status,
  })
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    onSave(formData)
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-semibold">تعديل بيانات الموظف</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <Input
            placeholder="الاسم الكامل"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            disabled={loading}
          />

          <Input
            placeholder="رقم الهاتف"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            disabled={loading}
          />

          <Input
            placeholder="القسم"
            name="department"
            value={formData.department}
            onChange={handleChange}
            disabled={loading}
          />

          <div>
            <label className="text-sm font-medium">الحالة</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              disabled={loading}
              className="w-full mt-1 px-3 py-2 border border-input rounded-md bg-background text-foreground text-sm"
            >
              <option value="active">نشيط</option>
              <option value="inactive">غير نشيط</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
              className="flex-1 bg-transparent"
            >
              إلغاء
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? "جاري الحفظ..." : "حفظ"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
