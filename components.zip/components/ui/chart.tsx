"use client"

import * as React from "react"
import * as RechartsPrimitive from "recharts"

import { cn } from "@/lib/utils"

// === تعريف الأنواع محليًا لتجنب الخط الأحمر ===
type NameType = string | number
type ValueType = string | number
type Payload<V = ValueType, N = NameType> = {
  name?: N
  value?: V
  dataKey?: string
  payload?: any
  [key: string]: any
}
type TooltipProps<V = ValueType, N = NameType> = any
type LegendProps = any
// ==============================================

// Format: { THEME_NAME: CSS_SELECTOR }
const THEMES = { light: "", dark: ".dark" } as const

export type ChartConfig = {
  [k in string]: {
    label?: React.ReactNode
    icon?: React.ComponentType
  } & (
    | { color?: string; theme?: never }
    | { color?: never; theme: Record<keyof typeof THEMES, string> }
  )
}

type ChartContextProps = {
  config: ChartConfig
}

const ChartContext = React.createContext<ChartContextProps | null>(null)

function useChart() {
  const context = React.useContext(ChartContext)

  if (!context) {
    throw new Error("useChart must be used within a <ChartContainer />")
  }

  return context
}

const ChartContainer = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    config?: Record<string, any>
  }
>(({ className, ...props }, ref) => <div ref={ref} className={className} {...props} />)
ChartContainer.displayName = "ChartContainer"

function ChartContainerWrapper({
  id,
  className,
  children,
  config,
  ...props
}: React.ComponentProps<"div"> & {
  config: ChartConfig
  children: React.ComponentProps<typeof RechartsPrimitive.ResponsiveContainer>["children"]
}) {
  const uniqueId = React.useId()
  const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`

  return (
    <ChartContext.Provider value={{ config }}>
      <div
        data-slot="chart"
        data-chart={chartId}
        className={cn(
          "[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border flex aspect-video justify-center text-xs [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-hidden [&_.recharts-sector]:outline-hidden [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-surface]:outline-hidden",
          className,
        )}
        {...props}
      >
        <ChartStyle id={chartId} config={config} />
        <RechartsPrimitive.ResponsiveContainer>{children}</RechartsPrimitive.ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  )
}


const ChartStyle = ({ id, config }: { id: string; config: ChartConfig }) => {
  const colorConfig = Object.entries(config).filter(([, config]) => config.theme || config.color)

  if (!colorConfig.length) {
    return null
  }

  return (
    <style
      dangerouslySetInnerHTML={{
        __html: Object.entries(THEMES)
          .map(
            ([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig
  .map(([key, itemConfig]) => {
    const color = itemConfig.theme?.[theme as keyof typeof itemConfig.theme] || itemConfig.color
    return color ? ` 	--color-${key}: ${color};` : null
  })
  .join("\n")}
}
`,
          )
          .join("\n"),
      }}
    />
  )
}

const ChartTooltip = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={className} {...props} />,
)
ChartTooltip.displayName = "ChartTooltip"

// تعريف نوع payload المخصص للتلميح
type ChartTooltipPayload = Payload<ValueType, NameType>

// استخدام واجهة بدلاً من دمج TooltipProps مباشرة لتجنب مشاكل Omit
interface ChartTooltipInjectedProps extends Pick<TooltipProps<ValueType, NameType>, 'formatter' | 'labelFormatter'> {
  // تم إزالة 'color' من Pick وإضافته هنا يدوياً لتجنب خطأ TS2344
    color?: string; 
    // الخصائص المحقونة من Recharts (Tooltip)
    active?: boolean
    payload?: ChartTooltipPayload[]
    label?: ValueType | NameType // يمكن أن يكون Label أي نوع من القيمة أو الاسم
}

// تعريف نوع يجمع بين الخصائص المحقونة وخصائص HTMLdiv وخصائصنا المخصصة
type ChartTooltipContentProps = ChartTooltipInjectedProps &
  React.ComponentProps<"div"> & {
    hideLabel?: boolean
    hideIndicator?: boolean
    indicator?: "line" | "dot" | "dashed"
    nameKey?: string
    labelKey?: string
    labelClassName?: string
  }

function ChartTooltipContent({
  active,
  payload, 
  className,
  indicator = "dot",
  hideLabel = false,
  hideIndicator = false,
  label, 
  labelFormatter,
  labelClassName,
  formatter,
  color,
  nameKey,
  labelKey,
}: ChartTooltipContentProps) {
  const { config } = useChart()

  // التأكد من أن payload هو مصفوفة من النوع الصحيح قبل استخدامه
  const typedPayload = payload as ChartTooltipPayload[] | undefined

  const tooltipLabel = React.useMemo(() => {
    if (hideLabel || !typedPayload?.length) {
      return null
    }

    const [item] = typedPayload
    const key = `${labelKey || item?.dataKey || item?.name || "value"}`
    const itemConfig = getPayloadConfigFromPayload(config, item, key)
    
    // label قد يكون رقمًا أو نصًا، نستخدم الفحص الصحيح
    const value =
      !labelKey && (typeof label === "string" || typeof label === "number") 
        ? config[label as keyof typeof config]?.label || label 
        : itemConfig?.label || label


    if (labelFormatter && typeof label !== 'undefined') {
      // تم حل مشكلة implicit any: الآن 'typedPayload' هو ChartTooltipPayload[]
      return <div className={cn("font-medium", labelClassName)}>{labelFormatter(label, typedPayload)}</div>
    }

    if (!value) {
      return null
    }

    return <div className={cn("font-medium", labelClassName)}>{value}</div>
  }, [label, labelFormatter, typedPayload, hideLabel, labelClassName, config, labelKey])

  if (!active || !typedPayload?.length) {
    return null
  }

  const nestLabel = typedPayload.length === 1 && indicator !== "dot"

  return (
    <div
      className={cn(
        "border-border/50 bg-background grid min-w-[8rem] items-start gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs shadow-xl",
        className,
      )}
    >
      {!nestLabel ? tooltipLabel : null}
      <div className="grid gap-1.5">
        {/* الآن 'item' و 'index' لهما أنواع صريحة بفضل نوع دالة .map على 'typedPayload' */}
        {typedPayload.map((item: ChartTooltipPayload, index: number) => { 
          const key = `${nameKey || item.name || item.dataKey || "value"}`
          const itemConfig = getPayloadConfigFromPayload(config, item, key)
          const indicatorColor = color || item.fill || item.color || item.payload?.fill || item.payload?.color

          return (
            <div
              key={item.dataKey || index}
              className={cn(
                "[&>svg]:text-muted-foreground flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5",
                indicator === "dot" && "items-center",
              )}
            >
              {formatter && item?.value !== undefined && item.name ? (
                // استخدام item.payload الآمن (البيانات الأصلية)
                formatter(item.value, item.name, item, index, item.payload)
              ) : (
                <>
                  {itemConfig?.icon ? (
                    <itemConfig.icon />
                  ) : (
                    !hideIndicator && (
                      <div
                        className={cn("shrink-0 rounded-[2px] border-[--color-border] bg-[--color-bg]", {
                          "h-2.5 w-2.5": indicator === "dot",
                          "w-1": indicator === "line",
                          "w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
                          "my-0.5": nestLabel && indicator === "dashed",
                        })}
                        style={
                          {
                            "--color-bg": indicatorColor,
                            "--color-border": indicatorColor,
                          } as React.CSSProperties
                        }
                      />
                    )
                  )}
                  <div
                    className={cn("flex flex-1 justify-between leading-none", nestLabel ? "items-end" : "items-center")}
                  >
                    <div className="grid gap-1.5">
                      {nestLabel ? tooltipLabel : null}
                      <span className="text-muted-foreground">{itemConfig?.label || item.name}</span>
                    </div>
                    {item.value !== undefined && ( // التحقق من القيمة لضمان عدم عرض null أو undefined
                      <span className="text-foreground font-mono font-medium tabular-nums">
                        {item.value?.toLocaleString()}
                      </span>
                    )}
                  </div>
                </>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

const ChartTooltipContentWrapper = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={`rounded-lg border border-border bg-background p-2 shadow-md ${className || ""}`}
      {...props}
    />
  ),
)
ChartTooltipContentWrapper.displayName = "ChartTooltipContent"

const ChartLegend = RechartsPrimitive.Legend

// تعريف نوع payload المخصص للتسمية
type ChartLegendPayload = Payload<ValueType, NameType>

// تعريف نوع يجمع بين خصائص LegendProps وخصائص HTMLdiv (تم إزالة payload من Pick)
function ChartLegendContent({
  className,
  hideIcon = false,
  payload, 
  verticalAlign = "bottom",
  nameKey,
}: React.ComponentProps<"div"> &
  Pick<LegendProps, "verticalAlign" | "align" | "layout" | "formatter"> & {
    // إضافة payload بشكل اختياري خارج Pick لتجنب خطأ TS2344
    payload?: ChartLegendPayload[] 
    hideIcon?: boolean
    nameKey?: string
  }) {
  const { config } = useChart()

  // التأكد من أن payload هو مصفوفة من النوع الصحيح قبل استخدامه
  const typedPayload = payload as ChartLegendPayload[] | undefined

  if (!typedPayload?.length) { 
    return null
  }

  return (
    <div className={cn("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className)}>
      {/* الآن 'item' له نوع صريح بفضل 'typedPayload' */}
      {typedPayload.map((item: ChartLegendPayload) => { 
        const key = `${nameKey || item.dataKey || "value"}`
        const itemConfig = getPayloadConfigFromPayload(config, item, key)

        // تحديد اللون للعناصر التي لا تحتوي على لون محدد
        const itemColor = item.color || item.payload?.fill || item.payload?.color || 'currentColor';

        return (
          <div
            key={item.value || item.dataKey}
            className={"[&>svg]:text-muted-foreground flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3"}
          >
            {itemConfig?.icon && !hideIcon ? (
              <itemConfig.icon />
            ) : (
              <div
                className="h-2 w-2 shrink-0 rounded-[2px]"
                style={{
                  backgroundColor: itemColor,
                }}
              />
            )}
            <span className="text-xs text-muted-foreground">{itemConfig?.label || item.value}</span>
          </div>
        )
      })}
    </div>
  )
}

// Helper to extract item config from a payload.
function getPayloadConfigFromPayload(config: ChartConfig, payload: unknown, key: string) {
  if (typeof payload !== "object" || payload === null) {
    return undefined
  }

  const payloadPayload =
    "payload" in payload && typeof payload.payload === "object" && payload.payload !== null
      ? payload.payload
      : undefined

  let configLabelKey: string = key

  // تأكدنا من أننا نصل إلى المفاتيح بشكل آمن
  if (key in payload && typeof (payload as Record<string, unknown>)[key] === "string") {
    configLabelKey = (payload as Record<string, string>)[key]
  } else if (
    payloadPayload &&
    key in payloadPayload &&
    typeof (payloadPayload as Record<string, unknown>)[key] === "string"
  ) {
    configLabelKey = (payloadPayload as Record<string, string>)[key]
  }

  return configLabelKey in config ? config[configLabelKey] : config[key as keyof typeof config]
}

export {
  ChartContainerWrapper as ChartContainer,
  ChartTooltip,
  ChartTooltipContentWrapper as ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartStyle,
}