"use client"

import { useEffect, useState } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { StarIcon } from "./star-icon"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { motion, AnimatePresence } from "framer-motion"

interface WelcomeModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (message: string, rating: number) => Promise<void>
  employeeName: string
}

export function WelcomeModal({ isOpen, onClose, onSubmit, employeeName }: WelcomeModalProps) {
  const [message, setMessage] = useState("")
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (isOpen) {
      const style = document.createElement("style")
      style.id = "modal-scrollbar-hide"
      style.textContent = `
        .modal-content::-webkit-scrollbar {
          display: none !important;
        }
        .modal-content {
          scrollbar-width: none !important;
          -ms-overflow-style: none !important;
        }
      `
      document.head.appendChild(style)
      return () => {
        const existingStyle = document.getElementById("modal-scrollbar-hide")
        if (existingStyle) {
          existingStyle.remove()
        }
      }
    }
  }, [isOpen])

  const handleSubmit = async () => {
    if (!message.trim() || rating === 0) {
      return
    }

    setIsSubmitting(true)
    try {
      await onSubmit(message, rating)
      setMessage("")
      setRating(0)
      onClose()
    } catch (error) {
      console.error("[v0] Error submitting testimonial:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] p-0 border-0 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 overflow-hidden">
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
              className="modal-content overflow-y-auto max-h-[85vh] [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
            >
              {/* Header with gradient */}
              <div className="relative bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 p-6 md:p-8 text-white overflow-hidden sticky top-0 z-20">
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                  className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl"
                />
                <motion.div
                  animate={{
                    scale: [1, 1.3, 1],
                    opacity: [0.2, 0.4, 0.2],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                    delay: 1,
                  }}
                  className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full blur-3xl"
                />

                <motion.div
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1, duration: 0.4 }}
                  className="text-center relative z-10"
                >
                  <motion.div
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                  >
                    <h2 className="text-2xl md:text-3xl font-bold mb-2 drop-shadow-lg">مرحباً بك، {employeeName}! 🎉</h2>
                  </motion.div>
                  <p className="text-white/95 font-medium">نتمنى لك تجربة رائعة في نظامنا</p>
                </motion.div>
              </div>

              {/* Content */}
              <div className="p-6 md:p-8 space-y-6">
                {/* Developer Section */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2, duration: 0.4 }}
                  className="flex flex-col items-center"
                >
                  <div className="relative mb-4">
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.3, type: "spring", stiffness: 150, damping: 15 }}
                      className="relative"
                    >
                      <motion.div
                        animate={{
                          boxShadow: [
                            "0 8px 24px rgba(59, 130, 246, 0.3)",
                            "0 12px 32px rgba(168, 85, 247, 0.4)",
                            "0 8px 24px rgba(59, 130, 246, 0.3)",
                          ],
                        }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                        className="rounded-full"
                      >
                        <Avatar className="w-20 md:w-24 h-20 md:h-24 border-4 border-white shadow-2xl">
                          <AvatarImage src="/developer.png" alt="مطور النظام" />
                          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-2xl md:text-3xl font-bold">
                            M
                          </AvatarFallback>
                        </Avatar>
                      </motion.div>
                      <motion.div
                        initial={{ scale: 0, rotate: -90 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{ delay: 0.6, type: "spring", stiffness: 200 }}
                        className="absolute -bottom-1 -right-1"
                      >
                        <motion.div
                          animate={{ rotate: [0, 15, -15, 0] }}
                          transition={{ delay: 1, duration: 0.6, repeat: Number.POSITIVE_INFINITY, repeatDelay: 2 }}
                          className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-2 shadow-xl"
                        >
                          <StarIcon className="w-4 md:w-5 h-4 md:h-5 text-white" filled />
                        </motion.div>
                      </motion.div>
                    </motion.div>
                  </div>

                  <motion.div
                    initial={{ y: 15, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4, duration: 0.4 }}
                    className="text-center"
                  >
                    <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      مطور النظام
                    </h3>
                    <p className="text-muted-foreground text-sm md:text-base leading-relaxed max-w-lg px-4">
                      يسعدنا أن تكون معنا! نود أن نسمع رأيك في النظام. شاركنا كلمة جميلة أو تقييمك للنظام
                    </p>
                  </motion.div>
                </motion.div>

                {/* Rating Section */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5, duration: 0.4 }}
                >
                  <label className="block text-center text-base md:text-lg font-bold text-foreground mb-4">
                    قيّم تجربتك مع النظام
                  </label>
                  <div className="flex justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <motion.button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoveredRating(star)}
                        onMouseLeave={() => setHoveredRating(0)}
                        whileHover={{ scale: 1.2, rotate: 10 }}
                        whileTap={{ scale: 0.9 }}
                        className="focus:outline-none transition-transform"
                      >
                        <StarIcon
                          filled={star <= (hoveredRating || rating)}
                          className={`w-8 md:w-10 h-8 md:h-10 transition-all duration-300 ${
                            star <= (hoveredRating || rating) ? "text-yellow-400 drop-shadow-lg" : "text-gray-300"
                          }`}
                        />
                      </motion.button>
                    ))}
                  </div>
                  <AnimatePresence mode="wait">
                    {rating > 0 && (
                      <motion.p
                        key={rating}
                        initial={{ opacity: 0, y: -10, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -10, scale: 0.9 }}
                        transition={{ duration: 0.3 }}
                        className="text-center mt-3 text-sm md:text-base font-semibold text-muted-foreground"
                      >
                        {rating === 5 && "ممتاز! شكراً لتقييمك الرائع 🌟"}
                        {rating === 4 && "رائع جداً! نقدر تقييمك 😊"}
                        {rating === 3 && "جيد! نسعى للأفضل دائماً 👍"}
                        {rating === 2 && "نأمل أن نحسن تجربتك قريباً 🙏"}
                        {rating === 1 && "نعتذر عن أي إزعاج، سنعمل على التحسين 💪"}
                      </motion.p>
                    )}
                  </AnimatePresence>
                </motion.div>

                {/* Message Section */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6, duration: 0.4 }}
                >
                  <label className="block text-center text-base md:text-lg font-bold text-foreground mb-4">
                    اكتب كلمة جميلة أو رسالة شكر
                  </label>
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="شاركنا رأيك أو كلمة تشجيعية... ✨"
                    className="min-h-24 md:min-h-28 resize-none bg-white border-2 border-gray-200 focus:border-blue-500 rounded-xl text-sm md:text-base shadow-lg transition-all focus:shadow-xl"
                    maxLength={500}
                  />
                  <p className="text-xs md:text-sm text-muted-foreground text-left mt-2">{message.length}/500 حرف</p>
                </motion.div>

                {/* Action Buttons */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.7, duration: 0.4 }}
                  className="flex gap-3 justify-center pt-4 pb-2"
                >
                  <Button
                    onClick={onClose}
                    variant="outline"
                    className="px-6 md:px-8 py-4 md:py-5 text-sm md:text-base font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all bg-white border-2 border-gray-200 hover:border-gray-300"
                    disabled={isSubmitting}
                  >
                    تخطي
                  </Button>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      onClick={handleSubmit}
                      disabled={!message.trim() || rating === 0 || isSubmitting}
                      className="px-6 md:px-8 py-4 md:py-5 text-sm md:text-base font-semibold rounded-xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white shadow-xl hover:shadow-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center gap-2">
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          جاري الإرسال...
                        </span>
                      ) : (
                        "إرسال التقييم ✨"
                      )}
                    </Button>
                  </motion.div>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  )
}
