"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { signInWithEmailAndPassword } from "firebase/auth"
import { auth } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"

export default function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [activeTab, setActiveTab] = useState<"admin" | "employee">("admin")
  const router = useRouter()

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      if (!email.includes("admin") && email !== "admin@zawagyapp.com") {
        setError("بيانات الإدارة غير صحيحة")
        setLoading(false)
        return
      }

      const result = await signInWithEmailAndPassword(auth, email, password)
      if (result.user) {
        router.push("/admin/dashboard")
      }
    } catch (err: any) {
      setError("البريد الإلكتروني أو كلمة المرور غير صحيحة")
    } finally {
      setLoading(false)
    }
  }

  const handleEmployeeLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Employee login with unique code
      const uniqueCode = email
      const employeeEmail = `emp_${uniqueCode}@zawagyapp.com`

      const result = await signInWithEmailAndPassword(auth, employeeEmail, password)
      if (result.user) {
        router.push(`/employee/profile?code=${encodeURIComponent(uniqueCode)}`)
      }
    } catch (err: any) {
      setError("الكود أو كلمة المرور غير صحيحة")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted-background to-background flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/3 rounded-full blur-3xl"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 shadow-2xl border-border/50 backdrop-blur-sm bg-card/95">
        <div className="p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">نظام الموظفين</h1>
            <p className="text-muted">نظام احترافي لإدارة بيانات الموظفين</p>
          </div>

          <div className="flex gap-2 mb-6 bg-muted-background p-1 rounded-lg">
            <button
              onClick={() => setActiveTab("admin")}
              className={`flex-1 py-2 px-4 rounded-md font-medium transition-all ${
                activeTab === "admin" ? "bg-card text-accent shadow-md" : "text-muted hover:text-foreground"
              }`}
            >
              مسؤول
            </button>
            <button
              onClick={() => setActiveTab("employee")}
              className={`flex-1 py-2 px-4 rounded-md font-medium transition-all ${
                activeTab === "employee" ? "bg-card text-accent shadow-md" : "text-muted hover:text-foreground"
              }`}
            >
              موظف
            </button>
          </div>

          <form onSubmit={activeTab === "admin" ? handleAdminLogin : handleEmployeeLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                {activeTab === "admin" ? "البريد الإلكتروني" : "كود الموظف"}
              </label>
              <Input
                type={activeTab === "admin" ? "email" : "text"}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={activeTab === "admin" ? "admin@zawagyapp.com" : "أدخل كودك"}
                className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">كلمة المرور</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="bg-muted-background border-border/50 focus:border-accent focus:ring-accent/20"
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-danger/10 border border-danger/20 rounded-lg text-danger text-sm">{error}</div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-accent hover:bg-accent-hover text-white font-medium py-2 transition-all"
            >
              {loading ? "جاري الدخول..." : "دخول"}
            </Button>
          </form>

          <p className="text-center text-muted text-sm mt-4">جرب: admin@zawagyapp.com | كلمة المرور: admin123</p>
        </div>
      </Card>
    </div>
  )
}
