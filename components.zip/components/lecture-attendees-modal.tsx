"use client"

import { useEffect, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { collection, query, where, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Lecture, Attendance } from "@/types/lecture"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Code2, Clock, Users } from "lucide-react"

interface LectureAttendeesModalProps {
  lecture: Lecture
  onClose: () => void
}

export default function LectureAttendeesModal({ lecture, onClose }: LectureAttendeesModalProps) {
  const [attendees, setAttendees] = useState<Attendance[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const q = query(collection(db, "attendance"), where("lectureId", "==", lecture.id))

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const attendeesList: Attendance[] = []
        snapshot.forEach((doc) => {
          const data = doc.data() as Attendance
          attendeesList.push({
             ...data,
            id: doc.id,
           
          })
        })
        setAttendees(attendeesList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()))
        setLoading(false)
      },
      (error) => {
        console.error("[v0] Error fetching attendees:", error)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [lecture.id])

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{lecture.title} - الحضور</span>
            <Badge variant="secondary" className="ml-2">
              {attendees.length} طالب
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <Card className="bg-blue-50 border-0">
            <CardContent className="p-4 flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">إجمالي الحضور</p>
                <p className="text-2xl font-bold text-blue-700">{attendees.length}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-0">
            <CardContent className="p-4 flex items-center gap-3">
              <MapPin className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">بالموقع</p>
                <p className="text-2xl font-bold text-green-700">
                  {attendees.filter((a) => a.attendanceMethod === "geolocation").length}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-purple-50 border-0">
            <CardContent className="p-4 flex items-center gap-3">
              <Code2 className="w-8 h-8 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">بالكود</p>
                <p className="text-2xl font-bold text-purple-700">
                  {attendees.filter((a) => a.attendanceMethod === "code").length}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <ScrollArea className="flex-1 pr-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
            </div>
          ) : attendees.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">لا يوجد حضور لهذه المحاضرة حتى الآن</div>
          ) : (
            <div className="space-y-3">
              {attendees.map((attendee) => (
                <div
                  key={attendee.id}
                  className="flex items-center justify-between p-3 bg-white border rounded-lg hover:shadow-sm transition-all"
                >
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={attendee.studentImage || "/placeholder.svg"} />
                      <AvatarFallback>{attendee.studentName.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{attendee.studentName}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {new Date(attendee.timestamp).toLocaleTimeString("ar-SA")}
                        <span>•</span>
                        {new Date(attendee.timestamp).toLocaleDateString("ar-SA")}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {attendee.attendanceMethod === "geolocation" ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 gap-1">
                        <MapPin className="w-3 h-3" />
                        موقع
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 gap-1">
                        <Code2 className="w-3 h-3" />
                        كود
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
