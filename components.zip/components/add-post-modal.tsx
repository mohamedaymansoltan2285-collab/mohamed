"use client"
import { useState } from "react"
import { db } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Loader2, FileText } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface AddPostModalProps {
  onClose: () => void
  category: "youth-care" | "student-union" | "women-support" | "uccd" | "student-affairs" | "mohamad-aimen"
  categoryName: string
  categoryColor: string
}

const categoryColorMap: Record<string, { from: string; to: string }> = {
  "youth-care": { from: "blue", to: "cyan" },
  "student-union": { from: "purple", to: "pink" },
  "women-support": { from: "rose", to: "pink" },
  uccd: { from: "amber", to: "orange" },
  "student-affairs": { from: "green", to: "emerald" },
  "mohamad-aimen": { from: "violet", to: "indigo" },
}

export default function AddPostModal({ onClose, category, categoryName, categoryColor }: AddPostModalProps) {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [link, setLink] = useState("")
  const [uploading, setUploading] = useState(false)

  const handleSubmit = async () => {
    if (!title.trim() || !content.trim()) {
      alert("يجب إدخال العنوان والمحتوى")
      return
    }

    setUploading(true)
    try {
      await addDoc(collection(db, "posts"), {
        title: title.trim(),
        content: content.trim(),
        imageUrl: imageUrl.trim() || null,
        linkUrl: link.trim() || null,
        category: category,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      })
      setTitle("")
      setContent("")
      setImageUrl("")
      setLink("")
      onClose()
    } catch (error) {
      console.error("[v0] Error adding post:", error)
      alert("حدث خطأ أثناء إضافة المنشور")
    } finally {
      setUploading(false)
    }
  }

  const colors = categoryColorMap[category] || { from: "blue", to: "cyan" }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", duration: 0.5 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <Card className="border-0 shadow-2xl">
            <CardHeader className={`bg-gradient-to-r from-${colors.from}-600 to-${colors.to}-600 text-white`}>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-2">
                    <FileText className="w-6 h-6" />
                    إضافة منشور جديد
                  </CardTitle>
                  <CardDescription className="text-white/80">{categoryName}</CardDescription>
                </div>
                <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* Title Input */}
              <div className="space-y-3">
                <Label htmlFor="title" className="text-base font-semibold">
                  عنوان المنشور
                </Label>
                <Input
                  id="title"
                  type="text"
                  placeholder="أدخل عنوان المنشور..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  disabled={uploading}
                  className="text-lg"
                />
              </div>

              {/* Content Input */}
              <div className="space-y-3">
                <Label htmlFor="content" className="text-base font-semibold">
                  محتوى المنشور
                </Label>
                <Textarea
                  id="content"
                  placeholder="أكتب محتوى المنشور هنا..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  disabled={uploading}
                  rows={5}
                  className="resize-none text-base"
                />
              </div>

              {/* Image URL */}
              <div className="space-y-3">
                <Label htmlFor="image-url" className="text-base font-semibold">
                  رابط الصورة (اختياري)
                </Label>
                <Input
                  id="image-url"
                  type="url"
                  placeholder="https://example.com/image.jpg"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  disabled={uploading}
                  className="text-base"
                />
              </div>

              {/* Link */}
              <div className="space-y-3">
                <Label htmlFor="link" className="text-base font-semibold">
                  رابط إضافي (اختياري)
                </Label>
                <Input
                  id="link"
                  type="url"
                  placeholder="https://example.com"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  disabled={uploading}
                  className="text-base"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleSubmit}
                  disabled={!title.trim() || !content.trim() || uploading}
                  className={`flex-1 bg-gradient-to-r from-${colors.from}-600 to-${colors.to}-600 hover:from-${colors.from}-700 hover:to-${colors.to}-700`}
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الإضافة...
                    </>
                  ) : (
                    "إضافة المنشور"
                  )}
                </Button>
                <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
                  إلغاء
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
