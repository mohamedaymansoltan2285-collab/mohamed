"use client"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, addDoc, updateDoc, doc, onSnapshot } from "firebase/firestore"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, AlertCircle } from "lucide-react"
import type { Employee } from "@/types/employee"
import type { Criterion, EmployeeRating } from "@/types/criteria"
import { useAuth } from "@/components/auth-context"

interface DepartmentEvaluationTableProps {
  departmentId: string
  employees: Employee[]
  criteria: Criterion[]
}

type TimeSlot = "morning" | "evening"

export default function DepartmentEvaluationTable({
  departmentId,
  employees,
  criteria,
}: DepartmentEvaluationTableProps) {
  const { user } = useAuth()
  const [ratings, setRatings] = useState<EmployeeRating[]>([])
  const [hoveredRating, setHoveredRating] = useState<{ employeeId: string; criterionId: string } | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentTimeSlot, setCurrentTimeSlot] = useState<TimeSlot>("morning")
  const [activeTimeSlot, setActiveTimeSlot] = useState<TimeSlot | null>(null)

  const determineTimeSlot = () => {
    const now = new Date()
    const hour = now.getHours()

    if (hour >= 10 && hour < 15) {
      setCurrentTimeSlot("morning")
      setActiveTimeSlot("morning")
    } else if (hour >= 15 && hour < 21) {
      setCurrentTimeSlot("evening")
      setActiveTimeSlot("evening")
    } else {
      setActiveTimeSlot(null)
    }
  }

  useEffect(() => {
    determineTimeSlot()
    const timer = setInterval(determineTimeSlot, 60000) // Check every minute
    return () => clearInterval(timer)
  }, [])

  // Filter criteria for this department
  const departmentCriteria = criteria.filter((c) => c.departments.includes(departmentId))

  useEffect(() => {
    if (departmentCriteria.length === 0) {
      setLoading(false)
      return
    }

    const today = new Date().toISOString().split("T")[0]
    const criteriaIds = departmentCriteria.map((c) => c.id)

    const unsubscribe = onSnapshot(
      query(
        collection(db, "employeeRatings"),
        where("departmentId", "==", departmentId),
        where("date", "==", today),
        where("timeSlot", "==", currentTimeSlot),
      ),
      (snapshot) => {
        const ratingsList: EmployeeRating[] = []
        snapshot.forEach((doc) => {
          ratingsList.push({ id: doc.id, ...doc.data() } as EmployeeRating)
        })
        setRatings(ratingsList)
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [departmentId, departmentCriteria, currentTimeSlot])

  const handleRating = async (employeeId: string, criterionId: string, rating: number) => {
    if (!user) return

    try {
      const today = new Date().toISOString().split("T")[0]
      const existingRating = ratings.find(
        (r) =>
          r.employeeId === employeeId &&
          r.criterionId === criterionId &&
          r.date === today &&
          r.timeSlot === currentTimeSlot,
      )

      if (existingRating) {
        await updateDoc(doc(db, "employeeRatings", existingRating.id), {
          rating,
          updatedAt: new Date().toISOString(),
        })
      } else {
        await addDoc(collection(db, "employeeRatings"), {
          employeeId,
          criterionId,
          departmentId,
          rating,
          date: today,
          timeSlot: currentTimeSlot,
          ratedBy: user.uid,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        })
      }
    } catch (error) {
      console.error("[v0] Error rating employee:", error)
    }
  }

  const getEmployeeRating = (employeeId: string, criterionId: string): number => {
    const rating = ratings.find(
      (r) => r.employeeId === employeeId && r.criterionId === criterionId && r.timeSlot === currentTimeSlot,
    )
    return rating?.rating || 0
  }

  if (departmentCriteria.length === 0) {
    return (
      <Card className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 border-border">
        <div className="text-center">
          <div className="text-4xl mb-4">📊</div>
          <p className="text-muted-foreground font-medium">لا توجد معايير مطبقة على هذا القسم حتى الآن</p>
        </div>
      </Card>
    )
  }

  const isTimeSlotActive = activeTimeSlot !== null
  const getTimeSlotLabel = (slot: TimeSlot) =>
    slot === "morning" ? "الفترة الصباحية (10 ص - 3 م)" : "الفترة المسائية (3 م - 9 م)"

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-200">
        <div className="flex items-center gap-3">
          <Clock className="w-5 h-5 text-blue-600" />
          <div>
            <p className="text-sm font-medium text-muted-foreground">الفترة الزمنية الحالية</p>
            <p className="text-lg font-bold text-foreground">{getTimeSlotLabel(currentTimeSlot)}</p>
          </div>
        </div>
        {!isTimeSlotActive && (
          <Badge className="bg-amber-100 text-amber-700 border-amber-300 gap-1.5">
            <AlertCircle className="w-3.5 h-3.5" />
            خارج الساعات المحددة
          </Badge>
        )}
        {isTimeSlotActive && (
          <Badge className="bg-green-100 text-green-700 border-green-300 gap-1.5">
            <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
            نشط الآن
          </Badge>
        )}
      </div>

      <Card className="border-0 shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-indigo-500 to-blue-500 text-white">
                <th className="px-6 py-4 text-right font-semibold">طالب</th>
                {departmentCriteria.map((criterion) => (
                  <th key={criterion.id} className="px-4 py-4 text-center font-semibold text-sm max-w-[150px]">
                    <span className="line-clamp-2">{criterion.text}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((employee, idx) => (
                <tr
                  key={employee.id}
                  className={`border-b border-border transition-colors hover:bg-indigo-50/50 ${
                    idx % 2 === 0 ? "bg-white" : "bg-slate-50/50"
                  }`}
                >
                  <td className="px-6 py-4 font-medium text-foreground">{employee.fullName}</td>
                  {departmentCriteria.map((criterion) => (
                    <td key={criterion.id} className="px-4 py-4 text-center">
                      <div className="flex justify-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => handleRating(employee.id, criterion.id, star)}
                            onMouseEnter={() =>
                              setHoveredRating({ employeeId: employee.id, criterionId: criterion.id })
                            }
                            onMouseLeave={() => setHoveredRating(null)}
                            disabled={!isTimeSlotActive}
                            className="transition-transform hover:scale-125 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Star
                              className={`w-5 h-5 ${
                                star <=
                                (
                                  hoveredRating?.employeeId === employee.id &&
                                  hoveredRating?.criterionId === criterion.id
                                    ? 5
                                    : getEmployeeRating(employee.id, criterion.id)
                                )
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-700">
          <strong>ملاحظة:</strong> يتم حفظ التقييمات تلقائياً عند الضغط على النجوم. يتاح التقييم فقط خلال الفترات المحددة
          (10 ص - 3 م) و (3 م - 9 م).
        </p>
      </div>
    </div>
  )
}
