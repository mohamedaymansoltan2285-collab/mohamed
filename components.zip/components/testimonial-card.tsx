"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { StarIcon } from "./star-icon"
import type { Testimonial } from "@/types/testimonial"

interface TestimonialCardProps {
  testimonial: Testimonial
  index: number
}

export function TestimonialCard({ testimonial, index }: TestimonialCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatDate = (date: any) => {
    if (!date) return ""
    const d = date.toDate ? date.toDate() : new Date(date)
    return new Intl.DateTimeFormat("ar-EG", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(d)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.15, ease: "easeOut" }}
      whileHover={{ y: -8 }}
      className="h-full"
    >
      <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-500 h-full bg-gradient-to-br from-white via-white to-amber-50 overflow-hidden group hover:scale-[1.02] transform">
        <div className="h-2 bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 group-hover:shadow-lg transition-all"></div>

        <CardContent className="p-6 md:p-8 flex flex-col h-full relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100/20 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-amber-100/30 transition-all"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-orange-100/15 rounded-full -ml-12 -mb-12 blur-2xl group-hover:bg-orange-100/25 transition-all"></div>

          {/* Header with avatar and info */}
          <div className="flex items-start gap-4 mb-6 relative z-10">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              whileInView={{ scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ type: "spring", stiffness: 200, damping: 15, delay: index * 0.15 + 0.1 }}
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-amber-300 to-orange-300 rounded-full opacity-30 blur-lg group-hover:opacity-50 transition-all"></div>
                <Avatar className="h-16 w-16 flex-shrink-0 border-3 border-amber-200 shadow-xl group-hover:shadow-2xl transition-all relative">
                  <AvatarImage src={testimonial.profileImage || "/placeholder.svg"} alt={testimonial.employeeName} />
                  <AvatarFallback className="bg-gradient-to-br from-amber-400 to-orange-500 text-white font-bold text-lg">
                    {getInitials(testimonial.employeeName)}
                  </AvatarFallback>
                </Avatar>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -15 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 + 0.15 }}
              className="flex-1"
            >
              <h3 className="font-bold text-foreground text-lg md:text-xl mb-1.5 line-clamp-2 group-hover:text-amber-600 transition-colors duration-300">
                {testimonial.employeeName}
              </h3>
              {testimonial.department && (
                <p className="text-sm text-muted-foreground mb-3 font-medium">{testimonial.department}</p>
              )}

              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.15 + 0.25 }}
                className="flex gap-1.5 items-center"
              >
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.div
                    key={star}
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    viewport={{ once: true }}
                    transition={{
                      type: "spring",
                      stiffness: 200,
                      damping: 15,
                      delay: index * 0.15 + 0.3 + star * 0.08,
                    }}
                  >
                    <div className="relative">
                      {star <= testimonial.rating && (
                        <motion.div
                          layoutId={`star-glow-${testimonial.id}-${star}`}
                          className="absolute inset-0 bg-amber-300 rounded-full blur-md opacity-50"
                        />
                      )}
                      <div
                        className={`w-5 h-5 transition-all relative z-10 ${
                          star <= testimonial.rating ? "text-amber-400 drop-shadow-lg" : "text-gray-300"
                        }`}
                      >
                        <StarIcon filled={star <= testimonial.rating} className="w-full h-full" />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.15 + 0.35 }}
            className="flex-1 mb-6 relative z-10"
          >
            <div className="relative">
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 0.3, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.15 + 0.4 }}
                className="absolute -top-4 -right-2 text-5xl text-amber-200 leading-none"
              >
                "
              </motion.div>
              <p className="text-foreground leading-relaxed text-right whitespace-pre-wrap break-words text-base md:text-lg bg-gradient-to-b from-amber-50/80 to-orange-50/60 rounded-xl p-5 border-r-4 border-amber-300 group-hover:border-orange-400 group-hover:shadow-md transition-all relative z-10">
                {testimonial.message}
              </p>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-amber-100/0 via-amber-100/10 to-orange-100/0 rounded-xl pointer-events-none"
                animate={{ opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: index * 0.15 + 0.45 }}
            className="flex items-center justify-between pt-5 border-t border-amber-100 relative z-10"
          >
            <p className="text-xs text-muted-foreground font-medium">{formatDate(testimonial.createdAt)}</p>
            <motion.div
              animate={{ scale: [1, 1.2, 1], rotate: [0, 12, -12, 0] }}
              transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY, delay: index * 0.2 }}
              className="text-amber-400"
            >
              <StarIcon filled className="w-4 h-4 drop-shadow-sm" />
            </motion.div>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
