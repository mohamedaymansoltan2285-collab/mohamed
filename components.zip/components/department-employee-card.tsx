"use client"

import type { Employee } from "@/types/employee"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Copy, Check } from "lucide-react"
import { useState } from "react"

interface DepartmentEmployeeCardProps {
  employee: Employee
  departmentColor: string
}

export default function DepartmentEmployeeCard({ employee, departmentColor }: DepartmentEmployeeCardProps) {
  const [copied, setCopied] = useState(false)

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(employee.employeeCode || employee.uniqueCode || "")
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const initials = employee.fullName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  return (
    <Card
      className={`group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br ${departmentColor}`}
    >
      <div className="p-6 h-full flex flex-col">
        {/* Header with Status Badge */}
        <div className="flex items-start justify-between mb-4">
          <Avatar className="w-16 h-16 border-4 border-white shadow-md">
            <AvatarImage src={employee.profileImage || "/placeholder.svg"} alt={employee.fullName} />
            <AvatarFallback className={`text-white font-bold text-lg bg-gradient-to-br ${departmentColor}`}>
              {initials}
            </AvatarFallback>
          </Avatar>
          <Badge
            className={`${employee.status === "active" ? "bg-green-500 hover:bg-green-600" : "bg-red-500 hover:bg-red-600"} text-white`}
          >
            {employee.status === "active" ? "نشيط" : "غير نشيط"}
          </Badge>
        </div>

        {/* Employee Info */}
        <div className="flex-1 space-y-2 mb-4">
          <h3 className="font-bold text-lg text-white line-clamp-2 text-pretty">{employee.fullName}</h3>
          <p className="text-sm text-white/90">{employee.email}</p>
          {employee.phone && <p className="text-sm text-white/80">📱 {employee.phone}</p>}
        </div>

        {/* Employee Code Section */}
        <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3 mb-4">
          <p className="text-xs text-white/80 mb-1 font-semibold">الرقم الكودي:</p>
          <div className="flex items-center justify-between gap-2">
            <code className="text-sm font-mono font-bold text-white tracking-wider">
              {employee.employeeCode || employee.uniqueCode || "---"}
            </code>
            <button
              onClick={handleCopyCode}
              className={`p-2 rounded-md transition-all duration-200 ${
                copied ? "bg-green-400 text-white" : "bg-white/30 text-white hover:bg-white/40"
              }`}
              title="نسخ الرقم الكودي"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Additional Info */}
        <div className="grid grid-cols-2 gap-2 text-xs text-white/80">
          <div>
            <p className="opacity-75">تاريخ الالتحاق</p>
            <p className="font-semibold text-white">{employee.joinDate?.slice(0, 10) || "---"}</p>
          </div>
          <div>
            <p className="opacity-75">النوع</p>
            <p className="font-semibold text-white">{employee.gender || "---"}</p>
          </div>
        </div>
      </div>
    </Card>
  )
}
