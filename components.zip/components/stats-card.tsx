import { Card } from "@/components/ui/card"

interface StatsCardProps {
  title: string
  value: number
  icon: string
  trend?: string
  color?: string
  loading?: boolean
}

export default function StatsCard({ title, value, icon, trend, color = "blue", loading = false }: StatsCardProps) {
  const colorClasses = {
    blue: "bg-blue-50 text-blue-600",
    pink: "bg-pink-50 text-pink-600",
    green: "bg-green-50 text-green-600",
    purple: "bg-purple-50 text-purple-600",
  }

  return (
    <Card className="p-6 shadow-lg hover:shadow-xl transition-shadow hover:scale-105 duration-300">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-muted text-sm font-medium mb-2">{title}</p>
          <p className="text-3xl font-bold text-foreground">{loading ? "..." : value}</p>
          {trend && <p className="text-success text-sm mt-2">{trend} هذا الشهر</p>}
        </div>
        <div className={`text-4xl p-3 rounded-lg ${colorClasses[color as keyof typeof colorClasses]}`}>{icon}</div>
      </div>
    </Card>
  )
}
