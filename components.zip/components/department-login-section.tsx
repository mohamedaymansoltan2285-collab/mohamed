"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LogIn, Lock, Code } from "lucide-react"

export default function DepartmentLoginSection() {
  const router = useRouter()
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)

  const handleAdminLogin = () => {
    router.push("/login?role=admin")
  }

  const handleEmployeeLogin = () => {
    router.push("/login?role=employee")
  }

  return (
    <div className="mt-12 pt-12 border-t border-border">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">الدخول إلى النظام</h2>
        <p className="text-muted-foreground">اختر طريقة الدخول المناسبة لك</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Admin Login Card */}
        <Card
          className="border-0 shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
          onMouseEnter={() => setHoveredCard("admin")}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <div className="h-32 bg-gradient-to-br from-blue-500 to-indigo-600 opacity-90"></div>
          <CardHeader className="relative -mt-16 pb-3">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-3 rounded-lg shadow-lg">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <div className="text-4xl">🔐</div>
            </div>
            <CardTitle className="text-xl">دخول المدير</CardTitle>
            <CardDescription>البريد الإلكتروني وكلمة المرور</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 bg-blue-50 p-4 rounded-lg">
              <p className="text-xs font-semibold text-blue-900">البيانات:</p>
              <p className="text-xs text-blue-800">البريد: admin@test.com</p>
              <p className="text-xs text-blue-800">كلمة المرور: 123456</p>
            </div>
            <Button
              onClick={handleAdminLogin}
              className={`w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all transform ${
                hoveredCard === "admin" ? "translate-y-0" : ""
              }`}
            >
              <LogIn className="w-4 h-4 ml-2" />
              دخول المديرين
            </Button>
            <p className="text-xs text-muted-foreground text-center">إدارة البيانات والموظفين</p>
          </CardContent>
        </Card>

        {/* Employee Login Card */}
        <Card
          className="border-0 shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer overflow-hidden"
          onMouseEnter={() => setHoveredCard("employee")}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <div className="h-32 bg-gradient-to-br from-green-500 to-emerald-600 opacity-90"></div>
          <CardHeader className="relative -mt-16 pb-3">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-gradient-to-br from-green-600 to-emerald-600 p-3 rounded-lg shadow-lg">
                <Code className="w-6 h-6 text-white" />
              </div>
              <div className="text-4xl">💼</div>
            </div>
            <CardTitle className="text-xl">دخول الموظف</CardTitle>
            <CardDescription>برقم وظيفي من 8 أرقام</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 bg-green-50 p-4 rounded-lg">
              <p className="text-xs font-semibold text-green-900">المتطلبات:</p>
              <p className="text-xs text-green-800">أدخل رقمك الوظيفي من 8 أرقام</p>
              <p className="text-xs text-green-800">تلقيته من قسم الموارد البشرية</p>
            </div>
            <Button
              onClick={handleEmployeeLogin}
              className={`w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 transition-all transform ${
                hoveredCard === "employee" ? "translate-y-0" : ""
              }`}
            >
              <LogIn className="w-4 h-4 ml-2" />
              دخول الموظفين
            </Button>
            <p className="text-xs text-muted-foreground text-center">عرض ملفك الشخصي</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
