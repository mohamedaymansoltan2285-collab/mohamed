"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, query, where, onSnapshot } from "firebase/firestore"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Download, Copy, Printer, BarChart3, Users, TrendingUp, CheckCircle, AlertCircle, Award } from "lucide-react"
import type { Employee } from "@/types/employee"
import type { Criterion, EmployeeRating } from "@/types/criteria"

interface RatingsSummaryTableProps {
  departmentId: string
  employees: Employee[]
  criteria: Criterion[]
}

interface EmployeeRatingSummary {
  employeeId: string
  employeeName: string
  ratings: { criterionId: string; criterionText: string; scores: number[] }[]
  averageScore: number
  performanceLevel: string
  performanceColor: string
  performanceIcon: React.ReactNode
  totalRatings: number
}

const getPerformanceLevel = (
  avg: number,
): {
  level: string
  color: string
  icon: React.ReactNode
  textColor: string
  bgColor: string
} => {
  if (avg >= 4.5)
    return {
      level: "ممتاز",
      color: "bg-emerald-100 text-emerald-700 border-emerald-300",
      icon: <Award className="w-4 h-4" />,
      textColor: "text-emerald-700",
      bgColor: "bg-emerald-50",
    }
  if (avg >= 4)
    return {
      level: "جيد جداً",
      color: "bg-blue-100 text-blue-700 border-blue-300",
      icon: <CheckCircle className="w-4 h-4" />,
      textColor: "text-blue-700",
      bgColor: "bg-blue-50",
    }
  if (avg >= 3)
    return {
      level: "جيد",
      color: "bg-amber-100 text-amber-700 border-amber-300",
      icon: <TrendingUp className="w-4 h-4" />,
      textColor: "text-amber-700",
      bgColor: "bg-amber-50",
    }
  return {
    level: "يحتاج تحسن",
    color: "bg-orange-100 text-orange-700 border-orange-300",
    icon: <AlertCircle className="w-4 h-4" />,
    textColor: "text-orange-700",
    bgColor: "bg-orange-50",
  }
}

export default function RatingsSummaryTable({ departmentId, employees, criteria }: RatingsSummaryTableProps) {
  const [ratingsSummary, setRatingsSummary] = useState<EmployeeRatingSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  const departmentCriteria = criteria.filter((c) => c.departments.includes(departmentId))

  useEffect(() => {
    if (departmentCriteria.length === 0 || employees.length === 0) {
      setLoading(false)
      return
    }

    const q = query(collection(db, "employeeRatings"), where("departmentId", "==", departmentId))

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allRatings: EmployeeRating[] = []
      snapshot.forEach((doc) => {
        allRatings.push({ id: doc.id, ...doc.data() } as EmployeeRating)
      })

      // Group ratings by employee
      const summaryMap = new Map<string, EmployeeRatingSummary>()

      employees.forEach((emp) => {
        const employeeRatings = allRatings.filter((r) => r.employeeId === emp.id)
        const ratingsByCriterion = new Map<string, number[]>()

        departmentCriteria.forEach((crit) => {
          ratingsByCriterion.set(crit.id, [])
        })

        employeeRatings.forEach((rating) => {
          const scores = ratingsByCriterion.get(rating.criterionId) || []
          scores.push(rating.rating)
          ratingsByCriterion.set(rating.criterionId, scores)
        })

        const ratingsArray = Array.from(ratingsByCriterion.entries()).map(([critId, scores]) => ({
          criterionId: critId,
          criterionText: departmentCriteria.find((c) => c.id === critId)?.text || "",
          scores,
        }))

        const allScores = Array.from(ratingsByCriterion.values()).flat()
        const averageScore = allScores.length > 0 ? allScores.reduce((a, b) => a + b, 0) / allScores.length : 0
        const performanceData = getPerformanceLevel(averageScore)

        summaryMap.set(emp.id, {
          employeeId: emp.id,
          employeeName: emp.fullName || emp.email,
          ratings: ratingsArray,
          averageScore: Math.round(averageScore * 100) / 100,
          performanceLevel: performanceData.level,
          performanceColor: performanceData.color,
          performanceIcon: performanceData.icon,
          totalRatings: allScores.length,
        })
      })

      setRatingsSummary(Array.from(summaryMap.values()).sort((a, b) => b.averageScore - a.averageScore))
      setLoading(false)
    })

    return () => unsubscribe()
  }, [departmentId, departmentCriteria, employees])

  const exportToCSV = () => {
    const csvContent = generateCSV()
    const element = document.createElement("a")
    element.setAttribute("href", "data:text/csv;charset=utf-8,%EF%BB%BF" + encodeURIComponent(csvContent))
    element.setAttribute("download", `تقرير_التقييمات_${new Date().toLocaleDateString("ar-EG")}.csv`)
    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const exportToExcel = () => {
    const headers = ["اسم الموظف", "المعدل", "الحالة", "عدد التقييمات", ...departmentCriteria.map((c) => c.text)]
    const rows = ratingsSummary.map((emp) => [
      emp.employeeName,
      emp.averageScore,
      emp.performanceLevel,
      emp.totalRatings,
      ...departmentCriteria.map((crit) => {
        const rating = emp.ratings.find((r) => r.criterionId === crit.id)
        return rating?.scores.length
          ? `${(rating.scores.reduce((a, b) => a + b) / rating.scores.length).toFixed(1)}`
          : "-"
      }),
    ])

    let csvContent = "data:text/csv;charset=utf-8,%EF%BB%BF"
    csvContent += headers.map((h) => `"${h}"`).join(",") + "\n"
    rows.forEach((row) => {
      csvContent += row.map((cell) => `"${cell}"`).join(",") + "\n"
    })

    const element = document.createElement("a")
    element.setAttribute("href", encodeURIComponent(csvContent))
    element.setAttribute("download", `تقرير_التقييمات_${new Date().toLocaleDateString("ar-EG")}.xlsx`)
    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const generateCSV = (): string => {
    const headers = ["اسم الموظف", "المعدل", "الحالة", "عدد التقييمات", ...departmentCriteria.map((c) => c.text)]
    const rows = ratingsSummary.map((emp) => [
      emp.employeeName,
      emp.averageScore,
      emp.performanceLevel,
      emp.totalRatings,
      ...departmentCriteria.map((crit) => {
        const rating = emp.ratings.find((r) => r.criterionId === crit.id)
        return rating?.scores.length
          ? `${(rating.scores.reduce((a, b) => a + b) / rating.scores.length).toFixed(1)}`
          : "-"
      }),
    ])

    let csv = headers.map((h) => `"${h}"`).join(",") + "\n"
    rows.forEach((row) => {
      csv += row.map((cell) => `"${cell}"`).join(",") + "\n"
    })
    return csv
  }

  const copyToClipboard = async () => {
    const text = generateCSV()
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("[v0] Failed to copy:", err)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  if (loading) {
    return (
      <Card className="p-12 text-center bg-gradient-to-br from-slate-50 to-blue-50 border-0 shadow-lg">
        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground font-medium">جاري تحميل البيانات...</p>
      </Card>
    )
  }

  if (ratingsSummary.length === 0) {
    return (
      <Card className="p-16 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 border-0 shadow-lg">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100 mb-6">
            <BarChart3 className="w-10 h-10 text-blue-600" />
          </div>
          <p className="text-foreground text-lg font-bold">لا توجد تقييمات بعد</p>
          <p className="text-muted-foreground mt-2">ابدأ بتقييم الموظفين لرؤية النتائج هنا</p>
        </div>
      </Card>
    )
  }

  const avgDepartment =
    ratingsSummary.length > 0
      ? Math.round((ratingsSummary.reduce((sum, emp) => sum + emp.averageScore, 0) / ratingsSummary.length) * 100) / 100
      : 0

  const excellentCount = ratingsSummary.filter((e) => e.averageScore >= 4.5).length
  const goodCount = ratingsSummary.filter((e) => e.averageScore >= 3 && e.averageScore < 4.5).length
  const needsImprovementCount = ratingsSummary.filter((e) => e.averageScore < 3).length

  return (
    <div className="space-y-8 print:space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 border-0 shadow-lg text-white overflow-hidden relative group">
          <div className="absolute -right-8 -top-8 w-24 h-24 bg-white/10 rounded-full group-hover:scale-110 transition-transform"></div>
          <div className="flex items-start justify-between relative z-10">
            <div>
              <p className="text-blue-100 text-sm font-medium">عدد الموظفين</p>
              <p className="text-4xl font-bold mt-3">{ratingsSummary.length}</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-indigo-500 to-indigo-600 border-0 shadow-lg text-white overflow-hidden relative group">
          <div className="absolute -right-8 -top-8 w-24 h-24 bg-white/10 rounded-full group-hover:scale-110 transition-transform"></div>
          <div className="flex items-start justify-between relative z-10">
            <div>
              <p className="text-indigo-100 text-sm font-medium">المعدل العام</p>
              <p className="text-4xl font-bold mt-3">{avgDepartment.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-500 to-purple-600 border-0 shadow-lg text-white overflow-hidden relative group">
          <div className="absolute -right-8 -top-8 w-24 h-24 bg-white/10 rounded-full group-hover:scale-110 transition-transform"></div>
          <div className="flex items-start justify-between relative z-10">
            <div>
              <p className="text-purple-100 text-sm font-medium">إجمالي التقييمات</p>
              <p className="text-4xl font-bold mt-3">{ratingsSummary.reduce((sum, e) => sum + e.totalRatings, 0)}</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
              <Award className="w-6 h-6 text-white" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-cyan-500 to-cyan-600 border-0 shadow-lg text-white overflow-hidden relative group">
          <div className="absolute -right-8 -top-8 w-24 h-24 bg-white/10 rounded-full group-hover:scale-110 transition-transform"></div>
          <div className="flex items-start justify-between relative z-10">
            <div>
              <p className="text-cyan-100 text-sm font-medium">المعايير</p>
              <p className="text-4xl font-bold mt-3">{departmentCriteria.length}</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-wrap gap-3 p-5 bg-gradient-to-r from-slate-50 to-blue-50 rounded-xl border border-slate-200 print:hidden">
        <Button
          onClick={exportToCSV}
          variant="outline"
          size="sm"
          className="gap-2 bg-white hover:bg-emerald-50 border-emerald-200 hover:border-emerald-300 text-emerald-700 font-medium transition-all"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">CSV</span>
        </Button>
        <Button
          onClick={exportToExcel}
          variant="outline"
          size="sm"
          className="gap-2 bg-white hover:bg-green-50 border-green-200 hover:border-green-300 text-green-700 font-medium transition-all"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">Excel</span>
        </Button>
        <Button
          onClick={copyToClipboard}
          variant="outline"
          size="sm"
          className="gap-2 bg-white hover:bg-blue-50 border-blue-200 hover:border-blue-300 text-blue-700 font-medium transition-all"
        >
          <Copy className="w-4 h-4" />
          <span className="hidden sm:inline">{copied ? "تم النسخ ✓" : "نسخ"}</span>
        </Button>
        <Button
          onClick={handlePrint}
          variant="outline"
          size="sm"
          className="gap-2 bg-white hover:bg-orange-50 border-orange-200 hover:border-orange-300 text-orange-700 font-medium transition-all"
        >
          <Printer className="w-4 h-4" />
          <span className="hidden sm:inline">طباعة</span>
        </Button>
      </div>

      <Card className="border-0 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 text-white">
                <th className="px-6 py-5 text-right font-semibold text-sm">الموظف</th>
                {departmentCriteria.map((crit) => (
                  <th key={crit.id} className="px-4 py-5 text-center font-semibold text-xs sm:text-sm max-w-[100px]">
                    <span className="line-clamp-2">{crit.text}</span>
                  </th>
                ))}
                <th className="px-4 py-5 text-center font-semibold text-sm">المعدل</th>
                <th className="px-6 py-5 text-center font-semibold text-sm">الحالة</th>
              </tr>
            </thead>
            <tbody>
              {ratingsSummary.map((emp, idx) => {
                const perfData = getPerformanceLevel(emp.averageScore)
                return (
                  <tr
                    key={emp.employeeId}
                    className={`border-b border-slate-200 transition-all hover:bg-blue-50/50 ${
                      idx % 2 === 0 ? "bg-white" : "bg-slate-50/40"
                    }`}
                  >
                    <td className="px-6 py-5 font-semibold text-foreground">{emp.employeeName}</td>
                    {departmentCriteria.map((crit) => {
                      const rating = emp.ratings.find((r) => r.criterionId === crit.id)
                      const avg = rating?.scores.length
                        ? rating.scores.reduce((a, b) => a + b) / rating.scores.length
                        : 0
                      return (
                        <td key={crit.id} className="px-4 py-5 text-center">
                          {avg > 0 ? (
                            <div className="flex flex-col items-center gap-1">
                              <span className="font-bold text-base text-blue-600">{avg.toFixed(1)}</span>
                              <span className="text-xs text-muted-foreground bg-slate-100 px-2 py-0.5 rounded">
                                ({rating?.scores.length})
                              </span>
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm font-medium">-</span>
                          )}
                        </td>
                      )
                    })}
                    <td className="px-4 py-5 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <span className="font-bold text-lg text-slate-700">{emp.averageScore.toFixed(1)}/5</span>
                        <div className="w-16 h-2 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all ${
                              emp.averageScore >= 4.5
                                ? "bg-emerald-500"
                                : emp.averageScore >= 4
                                  ? "bg-blue-500"
                                  : emp.averageScore >= 3
                                    ? "bg-amber-500"
                                    : "bg-orange-500"
                            }`}
                            style={{ width: `${(emp.averageScore / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5 text-center">
                      <Badge
                        className={`${emp.performanceColor} border font-semibold gap-1.5 flex items-center justify-center w-fit mx-auto`}
                      >
                        {emp.performanceIcon}
                        <span>{emp.performanceLevel}</span>
                      </Badge>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <Card className="p-7 bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 hover:shadow-lg transition-shadow">
          <div className="flex items-start justify-between mb-6">
            <div>
              <p className="text-emerald-600 text-sm font-semibold">الأداء الممتاز</p>
              <p className="text-4xl font-bold text-emerald-700 mt-3">{excellentCount}</p>
            </div>
            <div className="p-3 bg-emerald-100 rounded-lg">
              <Award className="w-6 h-6 text-emerald-600" />
            </div>
          </div>
          <div className="pt-4 border-t border-emerald-200">
            <p className="text-sm text-emerald-600 font-medium">
              {((excellentCount / ratingsSummary.length) * 100).toFixed(0)}% من الموظفين
            </p>
          </div>
        </Card>

        <Card className="p-7 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 hover:shadow-lg transition-shadow">
          <div className="flex items-start justify-between mb-6">
            <div>
              <p className="text-blue-600 text-sm font-semibold">الأداء الجيد</p>
              <p className="text-4xl font-bold text-blue-700 mt-3">{goodCount}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="pt-4 border-t border-blue-200">
            <p className="text-sm text-blue-600 font-medium">
              {((goodCount / ratingsSummary.length) * 100).toFixed(0)}% من الموظفين
            </p>
          </div>
        </Card>

        <Card className="p-7 bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200 hover:shadow-lg transition-shadow">
          <div className="flex items-start justify-between mb-6">
            <div>
              <p className="text-orange-600 text-sm font-semibold">يحتاج تحسن</p>
              <p className="text-4xl font-bold text-orange-700 mt-3">{needsImprovementCount}</p>
            </div>
            <div className="p-3 bg-orange-100 rounded-lg">
              <AlertCircle className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="pt-4 border-t border-orange-200">
            <p className="text-sm text-orange-600 font-medium">
              {((needsImprovementCount / ratingsSummary.length) * 100).toFixed(0)}% من الموظفين
            </p>
          </div>
        </Card>
      </div>

      {/* Footer Note */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-5 text-sm text-blue-700 print:bg-white print:border-blue-300">
        <div className="flex items-start gap-3">
          <BarChart3 className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold mb-1">ملاحظة مهمة</p>
            <p>يتم تحديث هذا الجدول تلقائياً مع إضافة تقييمات جديدة. الأرقام تمثل المعدل على مقياس من 1 إلى 5.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
