// components/PostCard.tsx
"use client"

import React, { useCallback, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { Heart, MessageCircle, Share2, Check, Send, Users } from "lucide-react"

// ********** الاستيرادات الإضافية الضرورية للمكونات **********
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
// *********************************************************

// ********** التأكد من الاستيراد الصحيح للدووال المساعدة **********
import { getInitials, formatDate, copyToClipboard, generateCommentId } from "@/utils/forum-utils"
// *************************************************

import { doc, updateDoc, arrayUnion, arrayRemove, serverTimestamp, Timestamp } from "firebase/firestore"
import { db } from "@/lib/firebase" 
import { useToast } from "@/hooks/use-toast"
import { Employee, Post, Comment } from "@/types/forum"

// ***************************************************************
// 🚀 التعديل الهام: تم تغيير نوع الدوال ليطابق الدوال المخصصة في ForumContent
// ***************************************************************
interface PostCardProps {
  post: Post
  currentEmployee: Employee
  
  // ✅ الأنواع المصححة: (دالة تقبل القيمة الجديدة فقط)
  setCommentingPostId: (id: string | null) => void 
  commentingPostId: string | null
  commentContent: string
  setCommentContent: (content: string) => void 
  isSubmittingComment: boolean
  setIsSubmittingComment: (isSubmitting: boolean) => void 
  copiedPostId: string | null
  setCopiedPostId: (id: string | null) => void 
  setShowLikers: (id: string | null) => void
}
// ***************************************************************


// دالة مساعدة لتحويل Timestamp أو Date إلى قيمة رقمية للمقارنة (بالميلي ثانية)
const getSortValue = (timestampOrDate: Timestamp | Date | undefined): number => {
    if (!timestampOrDate) return 0;
    
    // التحقق من نوع Timestamp
    if (typeof timestampOrDate === 'object' && timestampOrDate !== null && 'seconds' in timestampOrDate) {
        // إذا كان Timestamp، نحول الثواني إلى ميلي ثانية
        return (timestampOrDate as Timestamp).seconds * 1000; 
    }
    // إذا كان Date
    if (timestampOrDate instanceof Date) {
        return timestampOrDate.getTime();
    }
    return 0;
};


// مكون فرعي للتعليق
const CommentItem: React.FC<{ comment: Comment }> = React.memo(({ comment }) => {
    const createdAt = comment.createdAt as Timestamp | Date | undefined;
    
    return (
        <div className="flex gap-3 text-right bg-gray-50 p-3 rounded-lg border border-gray-100">
            <Avatar className="h-8 w-8 flex-shrink-0 border border-gray-200 shadow-sm">
                <AvatarImage src={comment.profileImage || "/placeholder.svg"} />
                <AvatarFallback className="bg-gray-200 text-gray-700 text-xs font-bold">
                    {getInitials(comment.employeeName)}
                </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm text-foreground">{comment.employeeName}</p>
                <p className="text-xs text-muted-foreground mb-1">{formatDate(createdAt)}</p>
                <p className="text-sm text-gray-700 whitespace-pre-wrap">{comment.content}</p>
            </div>
        </div>
    )
})
CommentItem.displayName = 'CommentItem'

const PostCard: React.FC<PostCardProps> = ({ 
  post,
  currentEmployee,
  setCommentingPostId,
  commentingPostId,
  commentContent,
  setCommentContent,
  isSubmittingComment,
  setIsSubmittingComment,
  copiedPostId,
  setCopiedPostId,
  setShowLikers,
}) => {
  const router = useRouter()
  const { toast } = useToast()
  
  const isLiked = useMemo(() => post.likes.includes(currentEmployee.id), [post.likes, currentEmployee.id])
  const isCommenting = commentingPostId === post.id
  
  const handleLike = useCallback(async () => {
    if (!currentEmployee) return

    try {
      const postRef = doc(db, "forumPosts", post.id)
      if (isLiked) {
        await updateDoc(postRef, {
          likes: arrayRemove(currentEmployee.id),
        })
      } else {
        await updateDoc(postRef, {
          likes: arrayUnion(currentEmployee.id),
        })
      }
    } catch (error) {
      console.error("[Forum] Error updating like:", error)
      toast({
        title: "خطأ",
        description: "فشل تحديث الإعجاب",
        variant: "destructive",
      })
    }
  }, [post.id, isLiked, currentEmployee, toast])

  const handleShare = useCallback(async () => {
    if (typeof window === "undefined") return

    const postLink = `${window.location.origin}/employee/forum?post=${post.id}`
    const shareText = `تحقق من منشور ${post.employeeName}: ${post.content.substring(0, 50)}...`

    try {
      if (navigator.share) {
        await navigator.share({
          title: "منشور من الملتقى",
          text: shareText,
          url: postLink,
        })
      } else {
        const copied = await copyToClipboard(postLink)
        if (copied) {
          setCopiedPostId(post.id)
          toast({ title: "نجاح", description: "تم نسخ الرابط إلى الحافظة" }) 
          setTimeout(() => setCopiedPostId(null), 2000)
        } else {
          throw new Error("Copy failed")
        }
      }
    } catch (error) {
      console.error("[Forum] Error sharing/copying:", error)
      toast({
        title: "خطأ",
        description: "فشلت المشاركة، الرجاء النسخ يدوياً",
        variant: "destructive",
      })
    }
  }, [post.id, post.employeeName, post.content, setCopiedPostId, toast])
  
  const handleAddComment = useCallback(async () => {
    if (!commentContent.trim() || !currentEmployee) {
      toast({
        title: "تنبيه",
        description: "يرجى إدخال محتوى التعليق",
        variant: "destructive",
      })
      return
    }

    const commentId = generateCommentId() 
    
    // التأكد من أن نوع createdAt هو FieldValue (serverTimestamp) عند الإرسال
    const newComment = {
      id: commentId,
      employeeName: currentEmployee.fullName,
      profileImage: currentEmployee.profileImage,
      content: commentContent,
      createdAt: serverTimestamp(),
    }
    
    try {
      setIsSubmittingComment(true)
      const postRef = doc(db, "forumPosts", post.id)

      await updateDoc(postRef, {
        comments: arrayUnion(newComment),
      })

      setCommentContent("")
      setCommentingPostId(null)
      toast({
        title: "نجاح",
        description: "تم إضافة التعليق بنجاح",
      })
    } catch (error) {
      console.error("[Forum] Error adding comment:", error)
      toast({
        title: "خطأ",
        description: "فشل إضافة التعليق",
        variant: "destructive",
      })
    } finally {
      setIsSubmittingComment(false)
    }
  }, [commentContent, currentEmployee, post.id, setCommentContent, setCommentingPostId, setIsSubmittingComment, toast])
  
  const viewEmployeeProfile = useCallback((employeeId: string) => {
    router.push(`/employee/view?code=${post.employeeCode}`) 
  }, [router, post.employeeCode]) 

  return (
    <Card key={post.id} className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 animate-fade-in bg-white overflow-hidden hover:scale-[1.01] transform">
      <div className="h-1 bg-gradient-to-r from-blue-400 to-purple-400"></div>
      <CardContent className="p-8">
        <div className="flex items-start justify-between mb-6">
          <div className="flex gap-4 flex-1">
            <Avatar className="h-14 w-14 flex-shrink-0 border-2 border-blue-200 shadow-md">
              <AvatarImage src={post.profileImage || "/placeholder.svg"} />
              <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-400 text-white font-bold">
                {getInitials(post.employeeName)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <button
                onClick={() => viewEmployeeProfile(post.employeeId)}
                className="flex items-center gap-2 mb-1 hover:opacity-70 transition-opacity group"
              >
                <p className="font-semibold text-foreground text-lg group-hover:text-blue-600 transition-colors">
                  {post.employeeName}
                </p>
              </button>
              <p className="text-sm text-muted-foreground">{formatDate(post.createdAt)}</p>
            </div>
          </div>
        </div>

        <p className="text-lg text-gray-800 mb-6 whitespace-pre-wrap">{post.content}</p>

        <div className="flex items-center justify-between border-t border-b border-gray-100 py-3 text-sm">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowLikers(post.id)} 
              disabled={post.likeCount === 0}
              className="flex items-center gap-1 text-gray-500 hover:text-blue-600 transition-colors disabled:cursor-default disabled:opacity-50"
            >
              <Users className="w-4 h-4" />
              <span>{post.likeCount} إعجاب</span>
            </button>
            <div className="flex items-center gap-1 text-gray-500">
              <MessageCircle className="w-4 h-4" />
              <span>{post.commentCount} تعليق</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <Share2 className="w-4 h-4" />
              <span>{post.shares} مشاركة</span>
            </div>
          </div>
        </div>

        <div className="flex justify-around border-t border-gray-100 mt-0 pt-3">
          <Button
            variant="ghost"
            onClick={handleLike}
            className={`flex items-center gap-2 p-2 rounded-lg transition-colors w-1/3 ${
              isLiked ? "text-red-600 hover:bg-red-50" : "text-gray-500 hover:text-red-600 hover:bg-gray-50"
            }`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? "fill-red-600" : ""}`} />
            <span className="font-medium">{isLiked ? "أعجبني" : "إعجاب"}</span>
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              setCommentingPostId(isCommenting ? null : post.id)
              if (!isCommenting) setCommentContent("")
            }}
            className="flex items-center gap-2 text-gray-500 hover:text-blue-600 hover:bg-gray-50 p-2 rounded-lg transition-colors w-1/3"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="font-medium">تعليق</span>
          </Button>
          <Button
            variant="ghost"
            onClick={handleShare}
            className={`flex items-center gap-2 text-gray-500 hover:text-purple-600 hover:bg-gray-50 p-2 rounded-lg transition-colors w-1/3 ${
              copiedPostId === post.id ? "text-green-600 hover:text-green-600" : ""
            }`}
          >
            {copiedPostId === post.id ? <Check className="w-5 h-5 text-green-600" /> : <Share2 className="w-5 h-5" />}
            <span className="font-medium">{copiedPostId === post.id ? "تم النسخ" : "مشاركة"}</span>
          </Button>
        </div>

        {isCommenting && (
          <div className="mt-4 pt-4 border-t border-gray-100 flex gap-3 items-end">
            <Textarea
              placeholder="اكتب تعليقك هنا..."
              value={commentContent}
              onChange={(e) => setCommentContent(e.target.value)}
              className="min-h-[50px] resize-none flex-1 bg-gray-50 border-gray-200 focus:ring-blue-500"
              disabled={isSubmittingComment}
            />
            <Button 
              onClick={handleAddComment} 
              disabled={isSubmittingComment || !commentContent.trim()}
              className="flex-shrink-0 bg-blue-600 hover:bg-blue-700 h-10 w-10 p-0"
            >
              {isSubmittingComment ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Send className="w-4 h-4 transform -translate-x-0.5" />
              )}
            </Button>
          </div>
        )}

        {post.comments.length > 0 && (
          <div className="mt-6 space-y-3 pt-4 border-t border-gray-100">
            {post.comments
                .sort((a, b) => getSortValue(b.createdAt) - getSortValue(a.createdAt))
                .slice(0, 3)
                .map((comment, index) => (
                  <CommentItem key={comment.id || index} comment={comment} />
            ))}
            {post.comments.length > 3 && (
              <p className="text-sm text-blue-600 font-medium text-center cursor-pointer hover:underline pt-2">
                عرض المزيد من التعليقات ({post.comments.length - 3})
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ************** تصدير افتراضي **************
export default PostCard