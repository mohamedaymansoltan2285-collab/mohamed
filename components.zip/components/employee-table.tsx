"use client"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface EmployeeTableProps {
  employees: any[]
  loading: boolean
  onDelete: (id: string) => void
}

export default function EmployeeTable({ employees, loading, onDelete }: EmployeeTableProps) {
  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="w-8 h-8 border-4 border-muted-background border-t-accent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (employees.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted">لا توجد بيانات موظفين حالياً</p>
      </div>
    )
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border">
            <th className="text-right py-3 px-4 font-semibold text-foreground">الاسم</th>
            <th className="text-right py-3 px-4 font-semibold text-foreground">الكود</th>
            <th className="text-right py-3 px-4 font-semibold text-foreground">البريد</th>
            <th className="text-right py-3 px-4 font-semibold text-foreground">الجنس</th>
            <th className="text-right py-3 px-4 font-semibold text-foreground">الفئة</th>
            <th className="text-center py-3 px-4 font-semibold text-foreground">الإجراءات</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id} className="border-b border-border hover:bg-muted-background transition-colors">
              <td className="py-4 px-4">{employee.name}</td>
              <td className="py-4 px-4 font-mono text-accent">{employee.uniqueCode}</td>
              <td className="py-4 px-4 text-muted text-sm">{employee.email}</td>
              <td className="py-4 px-4">
                <span className="text-sm">{employee.gender === "male" ? "ذكر" : "أنثى"}</span>
              </td>
              <td className="py-4 px-4">
                <span className="px-3 py-1 bg-accent/10 text-accent rounded-full text-sm font-medium">
                  {employee.category}
                </span>
              </td>
              <td className="py-4 px-4">
                <div className="flex gap-2 justify-center">
                  <Link href={`/admin/edit-employee/${employee.id}`}>
                    <Button className="bg-accent/10 text-accent hover:bg-accent/20 text-sm">تعديل</Button>
                  </Link>
                  <Button
                    onClick={() => onDelete(employee.id)}
                    className="bg-danger/10 text-danger hover:bg-danger/20 text-sm"
                  >
                    حذف
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
