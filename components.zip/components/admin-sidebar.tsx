"use client"

import { useRouter } from 'next/navigation'
import { signOut } from "firebase/auth"
import { auth } from "@/lib/firebase"
import Link from "next/link"
import { useState } from "react"

export default function AdminSidebar() {
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)

  const handleLogout = async () => {
    await signOut(auth)
    router.push("/login")
  }

  return (
    <div
      className={`bg-card border-r border-border transition-all duration-300 ${
        collapsed ? "w-20" : "w-64"
      } flex flex-col`}
    >
      <div className="p-6 border-b border-border flex items-center justify-between">
        {!collapsed && <h1 className="text-xl font-bold text-foreground">لوحة التحكم</h1>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-muted-background rounded-lg transition-colors"
        >
          <span className="material-icons-round text-2xl">menu</span>
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-2">

        {/* Dashboard */}
        <Link
          href="/admin/dashboard"
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted hover:bg-muted-background transition-colors group"
        >
          <span className="material-icons-round text-2xl">dashboard</span>
          {!collapsed && <span>لوحة البيانات</span>}
        </Link>

        {/* Students */}
        <Link
          href="/admin/employees"
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted hover:bg-muted-background transition-colors group"
        >
          <span className="material-icons-round text-2xl">group</span>
          {!collapsed && <span>الطلاب</span>}
        </Link>

        {/* Add Student */}
        <Link
          href="/admin/add-employee"
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted hover:bg-muted-background transition-colors group"
        >
          <span className="material-icons-round text-2xl">person_add</span>
          {!collapsed && <span>إضافة طالب</span>}
        </Link>

      </nav>

      <div className="p-4 border-t border-border">
        <button
          onClick={handleLogout}
          className="w-full px-4 py-2 bg-danger/10 text-danger rounded-lg hover:bg-danger/20 transition-colors font-medium flex items-center justify-center gap-2"
        >
          <span className="material-icons-round">
            {collapsed ? "logout" : "logout"}
          </span>
          {!collapsed && "تسجيل الخروج"}
        </button>
      </div>
    </div>
  )
}
