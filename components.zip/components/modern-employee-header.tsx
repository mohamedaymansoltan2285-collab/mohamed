"use client"

import { useState } from "react"
import { LogOut, MessageCircle, Menu, X, ImageIcon } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import type { Employee } from "@/types/employee"

interface ModernEmployeeHeaderProps {
  employee: Employee
  onLogout: () => void
  onNavigateToForum: () => void
  onNavigateToView?: () => void
  onNavigateToTestimonials?: () => void
}

export default function ModernEmployeeHeader({
  employee,
  onLogout,
  onNavigateToForum,
  onNavigateToView,
  onNavigateToTestimonials,
}: ModernEmployeeHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const initials = employee.fullName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  const handleNavigateToGallery = () => {
    window.location.href = "/gallery"
  }

  const handleNavigateToPostsHub = () => {
    window.location.href = `/employee/posts?code=${employee.employeeCode}`
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 shadow-sm">
      <div className="container mx-auto px-4 py-3 md:py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Company Name */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm">
              BTU
            </div>
            <div className="hidden sm:flex flex-col">
              <h1 className="text-lg font-bold text-foreground">نظام الطلاب</h1>
              <p className="text-xs text-muted-foreground leading-none">جامعة بنى سويف التكنولوجية</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            {/* Employee Info */}
            <div className="flex items-center gap-3 pr-4 border-r border-border">
              <Avatar className="h-9 w-9 border border-border">
                <AvatarImage src={employee.profileImage || "/placeholder.svg"} alt={employee.fullName} />
                <AvatarFallback className="bg-blue-100 text-blue-700 font-bold text-sm">{initials}</AvatarFallback>
              </Avatar>
              <div className="flex flex-col min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{employee.fullName}</p>
                <p className="text-xs text-muted-foreground font-mono">{employee.employeeCode}</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              <Button
                onClick={handleNavigateToPostsHub}
                variant="ghost"
                size="sm"
                className="gap-2 text-green-600 hover:text-green-700 hover:bg-green-50"
              >
                <span className="text-lg">📰</span>
                <span className="hidden lg:inline">المنشورات</span>
              </Button>
              <Button
                onClick={handleNavigateToGallery}
                variant="ghost"
                size="sm"
                className="gap-2 text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
              >
                <ImageIcon className="w-4 h-4" />
                <span className="hidden lg:inline">المعرض</span>
              </Button>
              {onNavigateToView && (
                <Button
                  onClick={onNavigateToView}
                  variant="ghost"
                  size="sm"
                  className="gap-2 text-purple-600 hover:text-purple-700 hover:bg-purple-50"
                >
                  <span className="text-lg">👁️</span>
                  <span className="hidden lg:inline">عرض</span>
                </Button>
              )}
              {onNavigateToTestimonials && (
                <Button
                  onClick={onNavigateToTestimonials}
                  variant="ghost"
                  size="sm"
                  className="gap-2 text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                >
                  <span className="text-lg">⭐</span>
                  <span className="hidden lg:inline">التقييمات</span>
                </Button>
              )}
              <Button
                onClick={onNavigateToForum}
                variant="ghost"
                size="sm"
                className="gap-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden lg:inline">الملتقى</span>
              </Button>
              <Button
                onClick={onLogout}
                variant="ghost"
                size="sm"
                className="gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden lg:inline">خروج</span>
              </Button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <Avatar className="h-8 w-8 border border-border">
              <AvatarImage src={employee.profileImage || "/placeholder.svg"} alt={employee.fullName} />
              <AvatarFallback className="bg-blue-100 text-blue-700 font-bold text-xs">{initials}</AvatarFallback>
            </Avatar>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2 border-t border-border/50 mt-3 space-y-2 animate-in fade-in slide-in-from-top-2">
            <div className="px-2 py-2 bg-muted rounded-lg mb-3">
              <p className="font-semibold text-sm">{employee.fullName}</p>
              <p className="text-xs text-muted-foreground font-mono">{employee.employeeCode}</p>
            </div>
            <Button
              onClick={() => {
                handleNavigateToPostsHub()
                setMobileMenuOpen(false)
              }}
              variant="ghost"
              className="w-full justify-start gap-2 text-green-600"
            >
              <span className="text-lg">📰</span>
              المنشورات
            </Button>
            <Button
              onClick={() => {
                handleNavigateToGallery()
                setMobileMenuOpen(false)
              }}
              variant="ghost"
              className="w-full justify-start gap-2 text-indigo-600"
            >
              <ImageIcon className="w-4 h-4" />
              معرض الصور
            </Button>
            {onNavigateToView && (
              <Button
                onClick={() => {
                  onNavigateToView()
                  setMobileMenuOpen(false)
                }}
                variant="ghost"
                className="w-full justify-start gap-2 text-purple-600"
              >
                <span className="text-lg">👁️</span>
                عرض الملف
              </Button>
            )}
            {onNavigateToTestimonials && (
              <Button
                onClick={() => {
                  onNavigateToTestimonials()
                  setMobileMenuOpen(false)
                }}
                variant="ghost"
                className="w-full justify-start gap-2 text-amber-600"
              >
                <span className="text-lg">⭐</span>
                صفحة التقييمات
              </Button>
            )}
            <Button
              onClick={() => {
                onNavigateToForum()
                setMobileMenuOpen(false)
              }}
              variant="ghost"
              className="w-full justify-start gap-2 text-blue-600"
            >
              <MessageCircle className="w-4 h-4" />
              الملتقى الذاتي
            </Button>
            <Button
              onClick={() => {
                onLogout()
                setMobileMenuOpen(false)
              }}
              variant="ghost"
              className="w-full justify-start gap-2 text-red-600"
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        )}
      </div>
    </header>
  )
}
