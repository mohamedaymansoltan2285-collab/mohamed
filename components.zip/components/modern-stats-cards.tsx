"use client"

import { Card } from "@/components/ui/card"
import { Calendar, Clock, Cake, TrendingUp } from 'lucide-react'
import { useMemo } from "react"

interface ModernStatsCardsProps {
  employee: {
    joinDate: string
    age?: number
  }
  ratings?: {
    averageRating?: number
  }
}

export default function ModernStatsCards({ employee, ratings }: ModernStatsCardsProps) {
  const stats = useMemo(() => {
    const startDate = new Date(employee.joinDate)
    const today = new Date()
    const daysWorked = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 3600 * 24))
    const monthsWorked = Math.floor(daysWorked / 30)
    const yearsWorked = Math.floor(daysWorked / 365)
    const averageRating = ratings?.averageRating || 0
    const ratingPercentage = Math.round((averageRating / 5) * 100)

    return {
      daysWorked,
      monthsWorked,
      yearsWorked,
      age: employee.age || 0,
      averageRating,
      ratingPercentage,
    }
  }, [employee, ratings])

  const cards = [
    {
      label: "عدد أيام العمل",
      value: stats.daysWorked.toString(),
      subtitle: "يوم من النمو المهني",
      icon: Calendar,
      gradient: "from-blue-500 via-blue-600 to-cyan-600",
      bgGradient: "from-blue-50 via-blue-50 to-cyan-50",
      accentColor: "text-blue-600",
      iconBg: "bg-gradient-to-br from-blue-500 to-cyan-500",
    },
    {
      label: "عدد الأشهر",
      value: stats.monthsWorked.toString(),
      subtitle: "شهر من الخبرة",
      icon: Clock,
      gradient: "from-purple-500 via-purple-600 to-indigo-600",
      bgGradient: "from-purple-50 via-purple-50 to-indigo-50",
      accentColor: "text-purple-600",
      iconBg: "bg-gradient-to-br from-purple-500 to-indigo-500",
    },
    {
      label: "العمر",
      value: stats.age.toString(),
      subtitle: "سنة",
      icon: Cake,
      gradient: "from-pink-500 via-pink-600 to-rose-600",
      bgGradient: "from-pink-50 via-pink-50 to-rose-50",
      accentColor: "text-pink-600",
      iconBg: "bg-gradient-to-br from-pink-500 to-rose-500",
    },
    {
      label: "التقييم الإجمالي",
      value: `${stats.ratingPercentage}%`,
      subtitle: `${stats.averageRating.toFixed(1)}/5.0`,
      icon: TrendingUp,
      gradient: "from-amber-500 via-orange-600 to-red-600",
      bgGradient: "from-amber-50 via-orange-50 to-red-50",
      accentColor: "text-amber-600",
      iconBg: "bg-gradient-to-br from-amber-500 to-orange-500",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
      {cards.map((card, index) => {
        const IconComponent = card.icon
        return (
          <Card
            key={index}
            className="relative overflow-hidden border-0 shadow-md hover:shadow-lg transition-all duration-300 group cursor-default"
          >
            {/* Background Gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${card.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>

            {/* Content */}
            <div className="relative p-6 h-full flex flex-col">
              {/* Header with Icon */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{card.label}</p>
                  <p className={`text-3xl md:text-4xl font-bold bg-gradient-to-r ${card.gradient} bg-clip-text text-transparent mb-1`}>
                    {card.value}
                  </p>
                  <p className={`text-xs ${card.accentColor} font-medium`}>{card.subtitle}</p>
                </div>
                <div className={`${card.iconBg} p-3 rounded-lg shadow-md group-hover:shadow-lg group-hover:scale-110 transition-all duration-300`}>
                  <IconComponent className="w-5 h-5 text-white" />
                </div>
              </div>

              {/* Bottom accent line */}
              <div className={`mt-auto h-1 w-8 bg-gradient-to-r ${card.gradient} rounded-full`}></div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
