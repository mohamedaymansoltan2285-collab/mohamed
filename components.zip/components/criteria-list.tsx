"use client"

import { useState } from "react"
import { db } from "@/lib/firebase"
import { deleteDoc, doc } from "firebase/firestore"
import { Trash2, Copy, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { Criterion } from "@/types/criteria"
import { DEPARTMENTS } from "@/types/employee"

interface CriteriaListProps {
  criteria: Criterion[]
  onCriteriaChange: () => void
}

export default function CriteriaList({ criteria, onCriteriaChange }: CriteriaListProps) {
  const [copied, setCopied] = useState<string | null>(null)

  const handleDelete = async (id: string) => {
    if (confirm("هل تريد حذف هذا المعيار؟")) {
      try {
        await deleteDoc(doc(db, "criteria", id))
        onCriteriaChange()
      } catch (error) {
        console.error("Error deleting criterion:", error)
      }
    }
  }

  const handleCopy = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const getDepartmentInfo = (deptId: string) => {
    return DEPARTMENTS.find((d) => d.value === deptId)
  }

  if (criteria.length === 0) {
    return (
      <div className="text-center py-12 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg border border-border">
        <div className="text-4xl mb-4">📋</div>
        <p className="text-muted-foreground text-lg font-medium">لم تتم إضافة أي معايير حتى الآن</p>
        <p className="text-muted-foreground/70 mt-2">أضف معايير جديدة لتقييم الموظفين</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {criteria.map((criterion) => (
        <Card key={criterion.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow">
          <div className="bg-gradient-to-r from-indigo-500 to-blue-500 px-6 py-4 text-white">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-white">{criterion.text}</h3>
                <p className="text-indigo-100 text-sm mt-1">
                  تم الإضافة: {new Date(criterion.createdAt).toLocaleDateString("ar-SA")}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopy(criterion.text, criterion.id)}
                  className="text-white hover:bg-white/20"
                >
                  {copied === criterion.id ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          <div className="p-6">
            <div className="mb-6">
              <label className="block text-sm font-semibold text-foreground mb-3">الأقسام المطبقة:</label>
              <div className="flex flex-wrap gap-2">
                {criterion.departments.map((deptId) => {
                  const dept = getDepartmentInfo(deptId)
                  return (
                    <div
                      key={deptId}
                      className="flex items-center gap-2 px-4 py-2 bg-indigo-50 border border-indigo-200 rounded-full text-sm font-medium text-indigo-700"
                    >
                      <span className="text-lg">{dept?.icon}</span>
                      {dept?.label}
                    </div>
                  )
                })}
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDelete(criterion.id)}
                className="flex items-center gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
                حذف
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
