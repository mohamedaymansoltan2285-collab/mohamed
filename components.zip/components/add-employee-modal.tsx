"use client"

import type React from "react"
import { useState } from "react"
import { db } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { X, AlertCircle, CheckCircle, Copy, Check } from "lucide-react"
import { DEPARTMENTS } from "@/types/employee"

interface AddEmployeeModalProps {
  onClose: () => void
  onEmployeeAdded: () => void
}

function generateEmployeeCode(): string {
  const min = 10000000
  const max = 99999999
  return Math.floor(Math.random() * (max - min + 1) + min).toString()
}

export default function AddEmployeeModal({ onClose, onEmployeeAdded }: AddEmployeeModalProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    emergencyPhone: "",
    address: "",
    age: "",
    maritalStatus: "",
    gender: "",
    religion: "",
    category: "",
    department: "تكنولوجيا المعلومات - الفرقة الأولى",
    joinDate: new Date().toISOString().split("T")[0],
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [generatedCode, setGeneratedCode] = useState("")
  const [copied, setCopied] = useState(false)
  const [codeVisible, setCodeVisible] = useState(true)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCopyCode = async () => {
    if (generatedCode) {
      await navigator.clipboard.writeText(generatedCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setLoading(true)

    try {
      const employeeCode = generateEmployeeCode()
      setGeneratedCode(employeeCode)
      setCodeVisible(true)
      setCopied(false)

      const visibilityTimeout = setTimeout(() => {
        setCodeVisible(false)
      }, 120000) // 2 minutes

      const employeeData = {
        ...formData,
        age: formData.age ? Number.parseInt(formData.age) : null,
        status: "active",
        employeeCode: employeeCode,
        role: "employee",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      await addDoc(collection(db, "employees"), employeeData)

      setSuccess(`تم إضافة الموظف بنجاح!`)

      setTimeout(() => {
        setFormData({
          fullName: "",
          email: "",
          phone: "",
          emergencyPhone: "",
          address: "",
          age: "",
          maritalStatus: "",
          gender: "",
          religion: "",
          category: "",
          department: "تكنولوجيا المعلومات - الفرقة الأولى",
          joinDate: new Date().toISOString().split("T")[0],
        })
      }, 1000)

      const closeTimeout = setTimeout(() => {
        setGeneratedCode("")
        onEmployeeAdded()
        onClose()
      }, 120000)

      return () => {
        clearTimeout(visibilityTimeout)
        clearTimeout(closeTimeout)
      }
    } catch (err: any) {
      setError(err?.message || "حدث خطأ في إضافة الموظف")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto backdrop-blur-sm">
      <Card className="w-full max-w-2xl my-8 shadow-2xl border-0">
        <div className="flex items-center justify-between p-6 border-b border-border bg-gradient-to-r from-blue-50 to-indigo-50">
          <h2 className="text-lg font-bold text-foreground">إضافة موظف جديد</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm animate-in fade-in">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 p-4 bg-green-50 border-2 border-green-300 rounded-lg text-green-700 text-sm animate-in fade-in">
              <CheckCircle className="w-5 h-5 flex-shrink-0" />
              <span className="font-semibold">{success}</span>
            </div>
          )}

          {generatedCode && codeVisible && (
            <div className="p-6 bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-50 border-2 border-blue-300 rounded-lg animate-in slide-in-from-top">
              <div className="space-y-3">
                <p className="text-sm text-blue-600 font-semibold">الرقم الكودي الوظيفي الآمن:</p>
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <p className="text-3xl font-bold text-blue-900 text-center tracking-widest font-mono bg-white border-2 border-blue-300 rounded-lg py-3 px-4">
                      {generatedCode}
                    </p>
                  </div>
                  <Button
                    type="button"
                    onClick={handleCopyCode}
                    className={`transition-all duration-300 ${
                      copied ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"
                    }`}
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span className="mr-2">{copied ? "تم النسخ" : "نسخ"}</span>
                  </Button>
                </div>
                <p className="text-xs text-blue-600 text-center">هذا الرقم سيختفي بعد دقيقتين - استخرجه الآن!</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="الاسم الكامل *"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              required
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="البريد الإلكتروني *"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="رقم الهاتف *"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="رقم الطوارئ"
              name="emergencyPhone"
              value={formData.emergencyPhone}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="العمر"
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="العنوان"
              name="address"
              value={formData.address}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <select
              name="department"
              value={formData.department}
              onChange={handleChange}
              disabled={loading}
              className="px-3 py-2 border border-input rounded-md bg-background text-foreground transition-all focus:ring-2 focus:ring-blue-500"
            >
              {DEPARTMENTS.map((dept) => (
                <option key={dept.value} value={dept.value}>
                  {dept.icon} {dept.label}
                </option>
              ))}
            </select>

            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              disabled={loading}
              className="px-3 py-2 border border-input rounded-md bg-background text-foreground transition-all focus:ring-2 focus:ring-blue-500"
            >
              <option value="">النوع</option>
              <option value="ذكر">ذكر</option>
              <option value="أنثى">أنثى</option>
            </select>

            <select
              name="maritalStatus"
              value={formData.maritalStatus}
              onChange={handleChange}
              disabled={loading}
              className="px-3 py-2 border border-input rounded-md bg-background text-foreground transition-all focus:ring-2 focus:ring-blue-500"
            >
              <option value="">الحالة الاجتماعية</option>
              <option value="أعزب">أعزب</option>
              <option value="متزوج">متزوج</option>
              <option value="مطلق">مطلق</option>
              <option value="أرمل">أرمل</option>
            </select>

            <Input
              placeholder="الديانة"
              name="religion"
              value={formData.religion}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              placeholder="الفئة"
              name="category"
              value={formData.category}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />

            <Input
              type="date"
              name="joinDate"
              value={formData.joinDate}
              onChange={handleChange}
              disabled={loading}
              className="placeholder:text-muted-foreground transition-all focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
              className="flex-1 bg-transparent hover:bg-muted"
            >
              إلغاء
            </Button>
            <Button type="submit" disabled={loading} className="flex-1 bg-blue-600 hover:bg-blue-700">
              {loading ? "جاري الحفظ..." : "إضافة"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
