"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { X, Check } from "lucide-react"

interface PersonalDataModalProps {
  isOpen: boolean
  onClose: () => void
  fieldType: string
  currentValue: any
  allEmployees?: any[]
  departments?: any[]
  onSave: (value: any) => void
  isLoading?: boolean
  canEdit?: boolean
}

export default function PersonalDataModal({
  isOpen,
  onClose,
  fieldType,
  currentValue,
  allEmployees = [],
  departments = [],
  onSave,
  isLoading = false,
  canEdit = true,
}: PersonalDataModalProps) {
  const [localValue, setLocalValue] = useState(currentValue)
  const [showSuccess, setShowSuccess] = useState(false)

  const vacationDays = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"]

  const educationLevels = ["مدرسة", "معهد", "جامعة"]

  const departmentOptions = [
    { label: "اسماك", value: "اسماك" },
    { label: "جبن", value: "جبن" },
    { label: "عطارة", value: "عطارة" },
    { label: "لحوم", value: "لحوم" },
    { label: "صالة", value: "صالة" },
    { label: "صالة 2", value: "صالة 2" },
    { label: "صالة 3", value: "صالة 3" },
    { label: "خضروات", value: "خضروات" },
    { label: "فواكهة", value: "فواكهة" },
  ]

  const handleSave = async () => {
    await onSave(localValue)
    setShowSuccess(true)
    setTimeout(() => {
      setShowSuccess(false)
      onClose()
    }, 1500)
  }

  const renderContent = () => {
    if (!canEdit) {
      return (
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg text-sm text-blue-700">يمكن للمدير مشاهدة البيانات فقط</div>
          {renderValueDisplay()}
        </div>
      )
    }

    switch (fieldType) {
      case "favoriteVacationDay":
        return (
          <Select value={localValue || ""} onValueChange={setLocalValue}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="اختر اليوم المفضل" />
            </SelectTrigger>
            <SelectContent>
              {vacationDays.map((day) => (
                <SelectItem key={day} value={day}>
                  {day}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )

      case "favoritePerson":
        return (
          <Select value={localValue || ""} onValueChange={setLocalValue}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="اختر الشخص المفضل" />
            </SelectTrigger>
            <SelectContent>
              {allEmployees
                .filter((emp) => emp.id)
                .map((emp) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.fullName}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        )

      case "favoriteFriends":
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 min-h-12 p-3 bg-gray-50 rounded-lg border">
              {(localValue || []).map((friendId: string) => {
                const friend = allEmployees.find((emp) => emp.id === friendId)
                return (
                  <Badge key={friendId} variant="secondary" className="flex items-center gap-2 px-3 py-1.5">
                    {friend?.fullName}
                    <button
                      onClick={() => setLocalValue((prev: string[]) => prev.filter((id: string) => id !== friendId))}
                      className="hover:text-red-600 transition"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )
              })}
            </div>
            <Select
              onValueChange={(value) => {
                if (!localValue?.includes(value)) {
                  setLocalValue((prev: string[]) => [...(prev || []), value])
                }
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="أضف صديق" />
              </SelectTrigger>
              <SelectContent>
                {allEmployees
                  .filter((emp) => !localValue?.includes(emp.id))
                  .map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.fullName}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        )

      case "suggestions":
      case "personalNotes":
      case "favoriteQuote":
        return (
          <Textarea
            value={localValue || ""}
            onChange={(e) => setLocalValue(e.target.value)}
            placeholder={getPlaceholder(fieldType)}
            className="min-h-24 resize-none"
          />
        )

      case "preferredDepartment":
        return (
          <Select value={localValue || ""} onValueChange={setLocalValue}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="اختر القسم المفضل" />
            </SelectTrigger>
            <SelectContent>
              {departmentOptions.map((dept) => (
                <SelectItem key={dept.value} value={dept.value}>
                  {dept.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )

      case "favoriteChallengeType":
        return (
          <Textarea
            value={localValue || ""}
            onChange={(e) => setLocalValue(e.target.value)}
            placeholder="اكتب نوع التحدي المفضل (مثل: المهام السريعة، المشاريع الكبيرة، إلخ)"
            className="min-h-24 resize-none"
          />
        )

      case "educationLevel":
        return (
          <div className="space-y-3">
            <Select
              value={localValue?.level || ""}
              onValueChange={(level) => setLocalValue({ level, institution: localValue?.institution || "" })}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="اختر المستوى التعليمي" />
              </SelectTrigger>
              <SelectContent>
                {educationLevels.map((level) => (
                  <SelectItem key={level} value={level}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {localValue?.level && (
              <Input
                type="text"
                value={localValue?.institution || ""}
                onChange={(e) => setLocalValue({ level: localValue.level, institution: e.target.value })}
                placeholder="اسم المؤسسة التعليمية"
              />
            )}
          </div>
        )

      default:
        return <Input value={localValue || ""} onChange={(e) => setLocalValue(e.target.value)} />
    }
  }

  const getPlaceholder = (field: string) => {
    const placeholders: Record<string, string> = {
      suggestions: "اكتب اقتراحاتك أو أفكارك الشخصية هنا...",
      personalNotes: "اكتب ملاحظاتك اليومية أو أفكارك حول العمل...",
      favoriteQuote: "اكتب عبارة أو اقتباس يعكس شخصيتك...",
    }
    return placeholders[field] || ""
  }

  const renderValueDisplay = () => {
    if (fieldType === "favoriteFriends" && Array.isArray(localValue)) {
      return (
        <div className="flex flex-wrap gap-2">
          {localValue.map((friendId: string) => {
            const friend = allEmployees.find((emp) => emp.id === friendId)
            return (
              <Badge key={friendId} variant="outline">
                {friend?.fullName}
              </Badge>
            )
          })}
          {!localValue.length && <p className="text-gray-500">لم يتم اختيار أحد</p>}
        </div>
      )
    }

    if (fieldType === "educationLevel" && localValue?.level) {
      return (
        <div className="space-y-2">
          <p className="text-sm">
            <strong>المستوى:</strong> {localValue.level}
          </p>
          {localValue.institution && (
            <p className="text-sm">
              <strong>المؤسسة:</strong> {localValue.institution}
            </p>
          )}
        </div>
      )
    }

    return (
      <p className="text-foreground whitespace-pre-wrap text-sm">
        {localValue || <span className="text-gray-400">لا توجد بيانات</span>}
      </p>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{getFieldLabel(fieldType)}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {showSuccess ? (
            <div className="flex items-center justify-center gap-2 p-4 bg-green-50 text-green-700 rounded-lg animate-fade-in">
              <Check className="w-5 h-5" />
              <span className="font-semibold">تم الحفظ بنجاح</span>
            </div>
          ) : (
            renderContent()
          )}
        </div>

        {!showSuccess && canEdit && (
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              إلغاء
            </Button>
            <Button onClick={handleSave} disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
              {isLoading ? "جاري الحفظ..." : "حفظ"}
            </Button>
          </div>
        )}

        {showSuccess && (
          <div className="flex justify-end">
            <Button onClick={onClose} className="bg-blue-600 hover:bg-blue-700">
              إغلاق
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function getFieldLabel(fieldType: string): string {
  const labels: Record<string, string> = {
    favoriteVacationDay: "اليوم المفضل للأجازة",
    favoritePerson: "الشخص المفضل في العمل",
    favoriteFriends: "الأصدقاء المفضلين",
    suggestions: "اقتراحاتك",
    personalNotes: "الملاحظات الشخصية",
    preferredDepartment: "القسم المفضل",
    favoriteChallengeType: "نوع التحدي المفضل",
    educationLevel: "المستوى التعليمي",
    favoriteQuote: "عبارة مفضلة",
  }
  return labels[fieldType] || fieldType
}
