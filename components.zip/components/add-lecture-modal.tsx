"use client"

import type React from "react"

import { useState } from "react"
import { collection, addDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import type { Lecture } from "@/types/lecture"
import { Plus, Loader2 } from "lucide-react"

interface AddLectureModalProps {
  departmentId: string
  createdBy: string
  onLectureAdded?: (lecture: Lecture) => void
}

export default function AddLectureModal({ departmentId, createdBy, onLectureAdded }: AddLectureModalProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    course: "",
    location: "", // Added location to state
    description: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.title || !formData.course || !formData.location) {
      alert("يرجى ملء جميع الحقول المطلوبة")
      return
    }

    setLoading(true)
    try {
      const finalAttendanceCode = generateRandomCode()
      const now = new Date()

      const lectureData = {
        departmentId,
        title: formData.title,
        course: formData.course,
        location: formData.location, // Added location
        lectureDate: now.toISOString(), // Auto-set date/time
        attendanceCode: finalAttendanceCode,
        description: formData.description,
        createdBy,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      }

      const docRef = await addDoc(collection(db, "lectures"), lectureData)

      console.log("[v0] Lecture created successfully:", docRef.id)

      setFormData({
        title: "",
        course: "",
        location: "", // Reset location
        description: "",
      })
      setOpen(false)

      if (onLectureAdded) {
        onLectureAdded({
          id: docRef.id,
          ...lectureData,
        } as Lecture)
      }
    } catch (error) {
      console.error("[v0] Error creating lecture:", error)
      alert("حدث خطأ في إضافة المحاضرة")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button
        onClick={() => setOpen(true)}
        className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all"
      >
        <Plus className="w-4 h-4 mr-2" />
        إضافة محاضرة جديدة
      </Button>

      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة محاضرة جديدة</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">اسم المحاضرة</label>
            <Input
              placeholder="مثال: محاضرة 1 - مقدمة"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium">اسم المقرر</label>
            <Input
              placeholder="مثال: البرمجة بلغة Python"
              value={formData.course}
              onChange={(e) => setFormData({ ...formData, course: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium">المقر (القاعة/المعمل)</label>
            <Input
              placeholder="مثال: قاعة 101 أو معمل الحاسب"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium">الوصف (اختياري)</label>
            <Textarea
              placeholder="إضافة ملاحظات أو وصف للمحاضرة"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex gap-2 justify-end pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading} className="bg-emerald-500 hover:bg-emerald-600">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  جاري الإضافة...
                </>
              ) : (
                "إضافة المحاضرة"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function generateRandomCode(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase()
}
