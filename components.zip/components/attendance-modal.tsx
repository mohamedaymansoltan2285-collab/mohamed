"use client"

import { useState, useCallback, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { collection, addDoc, query, where, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Lecture, Attendance } from "@/types/lecture"
import { calculateDistance, UNIVERSITY_LOCATION as UNIV_LOC } from "@/types/lecture"
import { MapPin, Code2, Loader2, CheckCircle, AlertCircle } from "lucide-react"

interface AttendanceModalProps {
  lecture: Lecture
  studentId: string
  onClose: () => void
}

type AttendanceStatus = "idle" | "loading" | "success" | "error"

export default function AttendanceModal({ lecture, studentId, onClose }: AttendanceModalProps) {
  const [activeTab, setActiveTab] = useState("location")
  const [codeInput, setCodeInput] = useState("")
  const [status, setStatus] = useState<AttendanceStatus>("idle")
  const [message, setMessage] = useState("")
  const [attendanceId, setAttendanceId] = useState<string | null>(null)

  // Check if already attended
  useEffect(() => {
    const checkExistingAttendance = async () => {
      try {
        const q = query(
          collection(db, "attendance"),
          where("lectureId", "==", lecture.id),
          where("studentId", "==", studentId),
        )
        const snapshot = await getDocs(q)
        if (!snapshot.empty) {
          setStatus("success")
          setMessage("تم تسجيل حضورك بالفعل في هذه المحاضرة")
          setAttendanceId(snapshot.docs[0].id)
        }
      } catch (error) {
        console.error("[v0] Error checking attendance:", error)
      }
    }
    checkExistingAttendance()
  }, [lecture.id, studentId])

  const registerAttendance = useCallback(
    async (method: "geolocation" | "code", data: any) => {
      setStatus("loading")
      try {
        // Get student info
        const q = query(collection(db, "employees"), where("__name__", "==", studentId))
        const studentSnapshot = await getDocs(q)
        const studentData = studentSnapshot.docs[0]?.data()

        const attendanceRecord: Attendance = {
          id: "", // Will be set by Firestore
          lectureId: lecture.id,
          studentId,
          studentName: studentData?.fullName || "Unknown",
          studentImage: studentData?.profileImage || "",
          attendanceMethod: method,
          timestamp: new Date().toISOString(),
          isApproved: true,
          ...data,
        }

        const docRef = await addDoc(collection(db, "attendance"), attendanceRecord)
        setAttendanceId(docRef.id)
        setStatus("success")
        setMessage(`تم تسجيل حضورك في محاضرة ${lecture.title}`)
        console.log("[v0] Attendance registered:", docRef.id)
      } catch (error) {
        console.error("[v0] Error registering attendance:", error)
        setStatus("error")
        setMessage("حدث خطأ في تسجيل الحضور")
      }
    },
    [lecture, studentId],
  )

  const handleGeolocationAttendance = useCallback(async () => {
    setStatus("loading")
    setMessage("")

    if (!navigator.geolocation) {
      setStatus("error")
      setMessage("متصفحك لا يدعم تحديد الموقع")
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        const distance = calculateDistance(latitude, longitude, UNIV_LOC.latitude, UNIV_LOC.longitude)

        console.log("[v0] Distance:", distance, "meters")

        if (distance <= UNIV_LOC.radiusMeters) {
          await registerAttendance("geolocation", {
            latitude,
            longitude,
            distance: Math.round(distance),
          })
        } else {
          setStatus("error")
          setMessage(`أنت بعيد عن الجامعة (${Math.round(distance)} متر). المسافة المسموحة 400 متر فقط`)
        }
      },
      (error) => {
        console.error("[v0] Geolocation error:", error)
        setStatus("error")
        setMessage("تعذر الحصول على موقعك. تأكد من تفعيل خدمات الموقع")
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }, [registerAttendance])

  const handleCodeAttendance = useCallback(async () => {
    if (!codeInput.trim()) {
      setMessage("يرجى إدخال الكود")
      return
    }

    if (codeInput.toUpperCase() === lecture.attendanceCode?.toUpperCase()) {
      await registerAttendance("code", {
        approvedAt: new Date().toISOString(),
      })
      setCodeInput("")
    } else {
      setStatus("error")
      setMessage("الكود غير صحيح")
    }
  }, [codeInput, lecture.attendanceCode, registerAttendance])

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{lecture.title}</DialogTitle>
        </DialogHeader>

        {status === "success" && attendanceId ? (
          <div className="text-center py-6 space-y-4">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto animate-bounce" />
            <p className="text-lg font-semibold text-green-600">{message}</p>
            <Button onClick={onClose} className="w-full bg-green-500 hover:bg-green-600">
              حسناً
            </Button>
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="location" className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span className="hidden sm:inline">الموقع</span>
              </TabsTrigger>
              <TabsTrigger value="code" className="flex items-center gap-2">
                <Code2 className="w-4 h-4" />
                <span className="hidden sm:inline">الكود</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="location" className="space-y-4 mt-6">
              <Card className="bg-blue-50 border-0">
                <CardContent className="p-4 space-y-2">
                  <p className="text-sm text-gray-600">تأكد من:</p>
                  <ul className="text-xs space-y-1 text-gray-600 list-disc list-inside">
                    <li>تفعيل خدمات الموقع على هاتفك</li>
                    <li>وجود إشارة قوية للجي بي إس</li>
                    <li>كونك بالقرب من الجامعة (400 متر كحد أقصى)</li>
                  </ul>
                </CardContent>
              </Card>

              {status === "error" && (
                <Card className="bg-red-50 border-0">
                  <CardContent className="p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-red-700">{message}</p>
                  </CardContent>
                </Card>
              )}

              <Button
                onClick={handleGeolocationAttendance}
                disabled={status === "loading"}
                className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white"
              >
                {status === "loading" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    جاري تحديد الموقع...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4 mr-2" />
                    تحضير باستخدام الموقع
                  </>
                )}
              </Button>
            </TabsContent>

            <TabsContent value="code" className="space-y-4 mt-6">
              <div>
                <label className="text-sm font-medium">أدخل كود التحضير</label>
                <Input
                  placeholder="مثال: ABC123"
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                  disabled={status === "loading"}
                  maxLength={6}
                  className="mt-2 text-center text-lg font-mono tracking-widest"
                />
              </div>

              {status === "error" && (
                <Card className="bg-red-50 border-0">
                  <CardContent className="p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-red-700">{message}</p>
                  </CardContent>
                </Card>
              )}

              <Button
                onClick={handleCodeAttendance}
                disabled={status === "loading" || !codeInput}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
              >
                {status === "loading" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    جاري التحقق...
                  </>
                ) : (
                  <>
                    <Code2 className="w-4 h-4 mr-2" />
                    تحضير باستخدام الكود
                  </>
                )}
              </Button>
            </TabsContent>
          </Tabs>
        )}

        {status !== "success" && (
          <Button variant="outline" onClick={onClose} className="w-full bg-transparent" disabled={status === "loading"}>
            إلغاء
          </Button>
        )}
      </DialogContent>
    </Dialog>
  )
}
