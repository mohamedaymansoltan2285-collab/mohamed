"use client"

import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

interface EmployeeChartProps {
  stats: {
    maleEmployees: number
    femaleEmployees: number
  }
}

export default function EmployeeChart({ stats }: EmployeeChartProps) {
  const data = [
    { name: "الذكور", value: stats.maleEmployees },
    { name: "الإناث", value: stats.femaleEmployees },
  ]

  const COLORS = ["#0071e3", "#ff1744"]

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, value }) => `${name}: ${value}`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  )
}
