"use client"

import { Mail, Github, Linkedin, Twitter, Code2 } from 'lucide-react'
import Image from "next/image"

export default function ProfessionalFooter() {
  return (
    <footer className="bg-gradient-to-b from-slate-900 to-slate-950 text-white border-t border-lime-500/20">
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Top section with logo and description */}
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          {/* Brand section */}
          <div className="md:col-span-2">
            <div className="mb-6">
              <div className="mb-4 relative w-full h-32 rounded-xl overflow-hidden">
                 <Image 
                   src="/images/1213.jpg" 
                   alt="جامعة بني سويف التكنولوجية" 
                   fill
                   className="object-cover opacity-80 hover:opacity-100 transition-opacity"
                 />
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-lime-400 to-blue-400 bg-clip-text text-transparent mb-3">
                جامعة بني سويف التكنولوجية
              </h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                نظام إدارة الحضور المتقدم للطلاب، صُمم بعناية لتحقيق أعلى معايير الكفاءة والتميز الأكاديمي.
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-lime-400 mb-4 uppercase">الروابط السريعة</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/welcome" className="text-gray-300 hover:text-lime-400 transition-colors">
                  الصفحة الرئيسية
                </a>
              </li>
              <li>
                <a href="/login" className="text-gray-300 hover:text-lime-400 transition-colors">
                  تسجيل الدخول
                </a>
              </li>
              <li>
                <a href="/welcome/about" className="text-gray-300 hover:text-lime-400 transition-colors">
                  عن النظام
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-lime-400 mb-4 uppercase">التواصل</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2 text-gray-300">
                <Mail className="w-4 h-4 text-lime-400" />
                <span>info@btu.edu.eg</span>
              </li>
              <li className="text-gray-400 text-xs"> جمهورية مصر العربية </li>
            </ul>
          </div>
        </div>

        {/* Developer section */}
        <div className="border-t border-slate-700 pt-12 mb-12">
          <h4 className="text-sm font-semibold text-lime-400 mb-6 uppercase">مبرمج النظام</h4>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Developer Card */}
            <div className="flex items-center gap-6 p-6 bg-slate-800/50 rounded-2xl hover:bg-slate-800/70 transition-all duration-300 border border-slate-700">
              <div className="relative flex-shrink-0">
                <div className="absolute inset-0 bg-gradient-to-r from-lime-500 to-blue-500 rounded-2xl blur-lg opacity-20"></div>
                <Image
                  src="/images/1214.png"
                  alt="محمد أيمن"
                  width={80}
                  height={80}
                  className="relative w-20 h-20 rounded-xl object-cover border-2 border-lime-500/50"
                />
              </div>
              <div className="flex-1">
                <h5 className="font-bold text-white mb-1">محمد أيمن</h5>
                <p className="text-sm text-gray-300 mb-3">مبرمج ومصمم متخصص</p>
                <div className="flex gap-3">
                  <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors">
                    <Github className="w-4 h-4" />
                  </a>
                  <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors">
                    <Linkedin className="w-4 h-4" />
                  </a>
                  <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors">
                    <Twitter className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>

            {/* Company Info */}
            <div className="p-6 bg-slate-800/50 rounded-2xl border border-slate-700">
              <div className="flex items-center gap-3 mb-4">
                <Code2 className="w-6 h-6 text-lime-400" />
                <h5 className="font-bold text-white">نبذة عن النظام</h5>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">
                نظام متكامل لإدارة الطلاب والمعايير والتقييمات اليومية، يوفر تجربة سهلة وديناميكية لقياس الأداء
                والجودة.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-slate-700 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-400">© 2025 جامعة بني سويف التكنولوجية. جميع الحقوق محفوظة.</p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors text-sm">
              سياسة الخصوصية
            </a>
            <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors text-sm">
              شروط الاستخدام
            </a>
            <a href="#" className="text-gray-400 hover:text-lime-400 transition-colors text-sm">
              تواصل معنا
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}