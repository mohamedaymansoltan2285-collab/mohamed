// utils/forum-utils.ts

/**
 * استخراج الأحرف الأولى من الاسم
 * @param name اسم الموظف كاملاً
 * @returns الأحرف الأولى (مثل: محمد علي -> م ع)
 */
export const getInitials = (name: string): string => {
  if (!name) return ""
  return name
    .split(" ")
    .map((n) => n[0])
    .filter(Boolean) // تصفية أي فراغات قد تنتج عن اسم غير مكتمل
    .join("")
    .toUpperCase()
    .slice(0, 2)
}

/**
 * تنسيق التاريخ من كائن Firestore Timestamp أو Date
 * @param date كائن التاريخ أو Timestamp
 * @returns سلسلة نصية منسقة بالتاريخ والوقت
 */
export const formatDate = (date: any): string => {
  if (!date) return ""
  const d = date.toDate ? date.toDate() : new Date(date)
  // التأكد من أن التاريخ صالح قبل التنسيق
  if (isNaN(d.getTime())) return ""

  return new Intl.DateTimeFormat("ar-EG", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  }).format(d)
}

/**
 * توليد معرّف فريد للتعليق (مماثل لمعرّف Firestore)
 * يعتمد على generateRandomId من Firestore لضمان التفرد
 * في بيئات React/Next.js، يتم استخدام حل يعطي تفردًا عاليًا
 * في هذا السياق، سنستخدم مكتبة مساعدة لإنشاء معرف فريد
 */
import { doc, collection } from "firebase/firestore"
import { db } from "@/lib/firebase" // نفترض أن مسار db صحيح

export const generateCommentId = (): string => {
  // استخدام وظيفة Firestore المضمنة لتوليد معرّف عشوائي جديد
  return doc(collection(db, "forumPosts")).id
}

/**
 * دالة مساعدة لنسخ الرابط
 * تستخدم navigator.clipboard.writeText كخيار أساسي
 * @param textToCopy النص المراد نسخه
 */
export const copyToClipboard = async (textToCopy: string): Promise<boolean> => {
  if (!textToCopy || typeof window === "undefined") return false
  
  // الخيار الأول والأفضل: navigator.clipboard API
  if (navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(textToCopy)
      return true
    } catch (err) {
      console.error("Failed to copy using clipboard API:", err)
      // قد تفشل بسبب عدم وجود HTTPS أو أذونات، ننتقل للخيار الثاني
    }
  }

  // الخيار الثاني: استخدام واجهة document.execCommand القديمة (للتوافق)
  try {
    const tempTextArea = document.createElement("textarea");
    tempTextArea.value = textToCopy;
    tempTextArea.style.position = "absolute";
    tempTextArea.style.left = "-9999px";
    document.body.appendChild(tempTextArea);
    tempTextArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(tempTextArea);
    return successful;
  } catch (err) {
    console.error("Failed to copy using execCommand:", err);
    return false;
  }
}