export interface Testimonial {
  id: string
  employeeId: string
  employeeName: string
  profileImage?: string
  department?: string
  message: string
  rating: number
  createdAt: any
}
