export interface StudentRequest {
  id: string
  studentId: string
  studentName: string
  studentCode: string
  studentDepartment: string
  studentImage?: string
  description: string
  imageUrl?: string
  status: "pending" | "reviewed" | "resolved"
  createdAt: string
  updatedAt?: string
}
