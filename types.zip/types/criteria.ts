export interface Criterion {
  id: string
  text: string
  departments: string[]
  docId?: string
  createdAt: string
  updatedAt: string
}

export interface EmployeeRating {
  id: string
  employeeId: string
  criterionId: string
  departmentId: string
  rating: number // 1-5
  date: string
  timeSlot: "morning" | "evening" // Morning: 10 AM - 3 PM, Evening: 3 PM - 9 PM
  notes?: string
  ratedBy: string
  createdAt: string
  updatedAt: string
}
