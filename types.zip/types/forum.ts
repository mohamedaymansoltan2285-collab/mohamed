// types/forum.ts

import { Timestamp } from "firebase/firestore"

export interface Comment {
  id: string
  employeeName: string
  profileImage?: string
  content: string
  createdAt: Timestamp | Date // يستخدم Timestamp عند الجلب و Date/Timestamp عند الإنشاء
}

export interface Post {
  id: string
  employeeId: string
  // ✅ تم إضافة الخاصية employeeCode لحل مشكلة التوجيه (Routing)
  employeeCode: string
  employeeName: string
  profileImage?: string
  department?: string
  content: string
  likes: string[] // مصفوفة من Employee IDs
  likeCount: number
  comments: Comment[]
  commentCount: number
  shares: number
  createdAt: Timestamp
  updatedAt?: Timestamp
}

export interface Employee {
  id: string
  fullName: string
  employeeCode: string
  profileImage?: string
  department?: string
}

// نفترض أن هذا موجود لديك
export interface Testimonial {
  id: string
  employeeId: string
  employeeName: string
  profileImage?: string
  department?: string
  message: string
  rating: number
  createdAt: Timestamp
}