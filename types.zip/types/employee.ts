export interface Employee {
  id: string
  fullName: string
  uniqueCode: string
  employeeCode: string
  age: number
  email: string
  phone: string
  emergencyPhone?: string
  address?: string
  maritalStatus?: "single" | "married" | "divorced" | "widowed" | "أعزب" | "متزوج" | "مطلق" | "أرمل"
  gender?: "ذكر" | "أنثى" | "male" | "female" | "other"
  religion?: string
  category?: string
  department:
    | "تكنولوجيا المعلومات - الفرقة الأولى"
    | "تكنولوجيا المعلومات - الفرقة الثانية"
    | "تكنولوجيا المعلومات - الفرقة الثالثة"
    | "تكنولوجيا المعلومات - الفرقة الرابعة"
    | "ميكاترونيكس - الفرقة الأولى"
    | "ميكاترونيكس - الفرقة الثانية"
    | "ميكاترونيكس - الفرقة الثالثة"
    | "ميكاترونيكس - الفرقة الرابعة"
    | "أوتوترونيكس - الفرقة الأولى"
    | "أوتوترونيكس - الفرقة الثانية"
    | "أوتوترونيكس - الفرقة الثالثة"
    | "أوتوترونيكس - الفرقة الرابعة"
    | "الطاقة المتجددة - الفرقة الأولى"
    | "الطاقة المتجددة - الفرقة الثانية"
    | "الطاقة المتجددة - الفرقة الثالثة"
    | "الطاقة المتجددة - الفرقة الرابعة"
    | "التحكم في الآلات الصناعية - الفرقة الأولى"
    | "التحكم في الآلات الصناعية - الفرقة الثانية"
    | "التحكم في الآلات الصناعية - الفرقة الثالثة"
    | "التحكم في الآلات الصناعية - الفرقة الرابعة"
    | "التبريد والتكييف - الفرقة الأولى"
    | "التبريد والتكييف - الفرقة الثانية"
    | "التبريد والتكييف - الفرقة الثالثة"
    | "التبريد والتكييف - الفرقة الرابعة"
    | "السكة الحديد - الفرقة الأولى"
    | "السكة الحديد - الفرقة الثانية"
    | "السكة الحديد - الفرقة الثالثة"
    | "السكة الحديد - الفرقة الرابعة"
  joinDate: string
  role: "admin" | "employee"
  status: "active" | "inactive"
  profileImage?: string
  createdAt?: string
  updatedAt?: string
  favoriteVacationDay?: string
  favoritePerson?: string
  favoriteFriends?: string[]
  suggestions?: string
  personalNotes?: string
  preferredDepartment?: string
  favoriteChallengeType?: string
  educationLevel?: string
  educationInstitution?: string
  favoriteQuote?: string
  hasSeenWelcomeModal?: boolean
}

export const DEPARTMENTS = [
  // تكنولوجيا المعلومات ICT
  {
    label: "تكنولوجيا المعلومات - الفرقة الأولى",
    value: "تكنولوجيا المعلومات - الفرقة الأولى",
    icon: "💻",
    color: "from-blue-500 to-cyan-500",
  },
  {
    label: "تكنولوجيا المعلومات - الفرقة الثانية",
    value: "تكنولوجيا المعلومات - الفرقة الثانية",
    icon: "💻",
    color: "from-blue-600 to-cyan-600",
  },
  {
    label: "تكنولوجيا المعلومات - الفرقة الثالثة",
    value: "تكنولوجيا المعلومات - الفرقة الثالثة",
    icon: "💻",
    color: "from-blue-700 to-cyan-700",
  },
  {
    label: "تكنولوجيا المعلومات - الفرقة الرابعة",
    value: "تكنولوجيا المعلومات - الفرقة الرابعة",
    icon: "💻",
    color: "from-blue-800 to-cyan-800",
  },

  // ميكاترونيكس Mechatronics
  {
    label: "ميكاترونيكس - الفرقة الأولى",
    value: "ميكاترونيكس - الفرقة الأولى",
    icon: "🤖",
    color: "from-purple-500 to-violet-500",
  },
  {
    label: "ميكاترونيكس - الفرقة الثانية",
    value: "ميكاترونيكس - الفرقة الثانية",
    icon: "🤖",
    color: "from-purple-600 to-violet-600",
  },
  {
    label: "ميكاترونيكس - الفرقة الثالثة",
    value: "ميكاترونيكس - الفرقة الثالثة",
    icon: "🤖",
    color: "from-purple-700 to-violet-700",
  },
  {
    label: "ميكاترونيكس - الفرقة الرابعة",
    value: "ميكاترونيكس - الفرقة الرابعة",
    icon: "🤖",
    color: "from-purple-800 to-violet-800",
  },

  // أوتوترونيكس Autotronics
  {
    label: "أوتوترونيكس - الفرقة الأولى",
    value: "أوتوترونيكس - الفرقة الأولى",
    icon: "🚗",
    color: "from-orange-500 to-red-500",
  },
  {
    label: "أوتوترونيكس - الفرقة الثانية",
    value: "أوتوترونيكس - الفرقة الثانية",
    icon: "🚗",
    color: "from-orange-600 to-red-600",
  },
  {
    label: "أوتوترونيكس - الفرقة الثالثة",
    value: "أوتوترونيكس - الفرقة الثالثة",
    icon: "🚗",
    color: "from-orange-700 to-red-700",
  },
  {
    label: "أوتوترونيكس - الفرقة الرابعة",
    value: "أوتوترونيكس - الفرقة الرابعة",
    icon: "🚗",
    color: "from-orange-800 to-red-800",
  },

  {
    label: "الطاقة المتجددة - الفرقة الأولى",
    value: "الطاقة المتجددة - الفرقة الأولى",
    icon: "⚡",
    color: "from-green-500 to-emerald-500",
  },
  {
    label: "الطاقة المتجددة - الفرقة الثانية",
    value: "الطاقة المتجددة - الفرقة الثانية",
    icon: "⚡",
    color: "from-green-600 to-emerald-600",
  },
  {
    label: "الطاقة المتجددة - الفرقة الثالثة",
    value: "الطاقة المتجددة - الفرقة الثالثة",
    icon: "⚡",
    color: "from-green-700 to-emerald-700",
  },
  {
    label: "الطاقة المتجددة - الفرقة الرابعة",
    value: "الطاقة المتجددة - الفرقة الرابعة",
    icon: "⚡",
    color: "from-green-800 to-emerald-800",
  },

  {
    label: "التحكم في الآلات الصناعية - الفرقة الأولى",
    value: "التحكم في الآلات الصناعية - الفرقة الأولى",
    icon: "⚙️",
    color: "from-slate-500 to-gray-500",
  },
  {
    label: "التحكم في الآلات الصناعية - الفرقة الثانية",
    value: "التحكم في الآلات الصناعية - الفرقة الثانية",
    icon: "⚙️",
    color: "from-slate-600 to-gray-600",
  },
  {
    label: "التحكم في الآلات الصناعية - الفرقة الثالثة",
    value: "التحكم في الآلات الصناعية - الفرقة الثالثة",
    icon: "⚙️",
    color: "from-slate-700 to-gray-700",
  },
  {
    label: "التحكم في الآلات الصناعية - الفرقة الرابعة",
    value: "التحكم في الآلات الصناعية - الفرقة الرابعة",
    icon: "⚙️",
    color: "from-slate-800 to-gray-800",
  },

  {
    label: "التبريد والتكييف - الفرقة الأولى",
    value: "التبريد والتكييف - الفرقة الأولى",
    icon: "❄️",
    color: "from-sky-500 to-blue-500",
  },
  {
    label: "التبريد والتكييف - الفرقة الثانية",
    value: "التبريد والتكييف - الفرقة الثانية",
    icon: "❄️",
    color: "from-sky-600 to-blue-600",
  },
  {
    label: "التبريد والتكييف - الفرقة الثالثة",
    value: "التبريد والتكييف - الفرقة الثالثة",
    icon: "❄️",
    color: "from-sky-700 to-blue-700",
  },
  {
    label: "التبريد والتكييف - الفرقة الرابعة",
    value: "التبريد والتكييف - الفرقة الرابعة",
    icon: "❄️",
    color: "from-sky-800 to-blue-800",
  },

  {
    label: "السكة الحديد - الفرقة الأولى",
    value: "السكة الحديد - الفرقة الأولى",
    icon: "🚂",
    color: "from-yellow-500 to-amber-500",
  },
  {
    label: "السكة الحديد - الفرقة الثانية",
    value: "السكة الحديد - الفرقة الثانية",
    icon: "🚂",
    color: "from-yellow-600 to-amber-600",
  },
  {
    label: "السكة الحديد - الفرقة الثالثة",
    value: "السكة الحديد - الفرقة الثالثة",
    icon: "🚂",
    color: "from-yellow-700 to-amber-700",
  },
  {
    label: "السكة الحديد - الفرقة الرابعة",
    value: "السكة الحديد - الفرقة الرابعة",
    icon: "🚂",
    color: "from-yellow-800 to-amber-800",
  },
]

export interface AdminUser {
  id: string
  email: string
  role: "admin"
  createdAt: string
}
