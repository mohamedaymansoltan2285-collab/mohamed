export interface Lecture {
  id: string
  departmentId: string // مثل: "تكنولوجيا المعلومات - الفرقة الأولى"
  title: string // اسم المحاضرة
  course: string // اسم المقرر
  location?: string // Added location field
  lectureDate: string // تاريخ المحاضرة (YYYY-MM-DD)
  attendanceCode?: string // كود التحضير البديل (اختياري)
  createdBy: string // معرف الدكتور
  createdAt: string // تاريخ إنشاء المحاضرة
  updatedAt: string
  description?: string
}

export interface Attendance {
  id: string
  lectureId: string
  studentId: string
  studentName: string
  studentImage?: string
  attendanceMethod: "geolocation" | "code" // طريقة التحضير
  timestamp: string // وقت التحضير
  latitude?: number
  longitude?: number
  distance?: number // المسافة من الجامعة
  isApproved: boolean
  approvedAt?: string
}

export interface LectureStats {
  lectureId: string
  totalAttendees: number
  totalStudentsInDepartment: number
  attendancePercentage: number
  attendanceList: Attendance[]
}

// إحداثيات الجامعة
export const UNIVERSITY_LOCATION = {
  latitude: 29.04820147564802,
  longitude: 31.123671288358473,
  radiusMeters: 400, // النطاق المسموح به بالمتر
}

// دالة لحساب المسافة بين نقطتين (Haversine formula)
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3 // نصف قطر الأرض بالمتر
  const φ1 = (lat1 * Math.PI) / 180
  const φ2 = (lat2 * Math.PI) / 180
  const Δφ = ((lat2 - lat1) * Math.PI) / 180
  const Δλ = ((lon2 - lon1) * Math.PI) / 180

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

  return R * c // المسافة بالمتر
}
