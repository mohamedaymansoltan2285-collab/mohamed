import type { Timestamp } from "firebase/firestore"

export interface Post {
  id: string
  title: string
  content: string
  imageUrl?: string
  linkUrl?: string
  createdAt: Timestamp
  createdBy: string
  category: "youth-care" | "student-union" | "women-support"
}

export type PostCategory = "youth-care" | "student-union" | "women-support"

export const POST_CATEGORIES = {
  "youth-care": {
    label: "رعاية الشباب",
    icon: "🎯",
    gradient: "from-blue-500 to-cyan-500",
    color: "blue",
  },
  "student-union": {
    label: "اتحاد الطلاب",
    icon: "👥",
    gradient: "from-purple-500 to-pink-500",
    color: "purple",
  },
  "women-support": {
    label: "وحدة تكافؤ الفرص ودعم المرأة",
    icon: "🌸",
    gradient: "from-rose-500 to-orange-500",
    color: "rose",
  },
}
