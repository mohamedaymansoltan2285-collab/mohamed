export interface GalleryImage {
  id: string
  imageUrl: string
  description?: string
  uploadedAt: string
  uploadedBy?: string
  category?: string
}
